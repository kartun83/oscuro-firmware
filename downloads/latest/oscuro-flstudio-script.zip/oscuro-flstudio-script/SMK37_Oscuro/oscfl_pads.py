# Pad bank B (pads 17-32) for the FL Studio script: eight pad modes, picked with Oct- (or the Shift pad) + a bottom-row
# pad; holding the Shift pad shows the choice lit. Pad bank A stays notes (they play the selected channel).
#
#   1 Steps     the 16 steps of the selected channel in the current pattern (FL's step sequencer); the playing step
#               is white. Tap an empty step: on. Tap a set step and let go: off, unless a knob turned while it was
#               held: K1 velocity, K2 release, K3 fine pitch, K4 pan, K5 mod X, K6 mod Y, K7 shift, K8 note.
#   2 Channels  top row: 8 channels of the rack (select), bottom row: their mute.
#   3 Patterns  16 patterns (jump; an empty pad makes a pattern there).
#   4 Mute, 5 Solo, 6 Arm, 8 Route
#               top row: select 8 mixer inserts of the bank; bottom row: their mute / solo / arm, or Route: whether
#               the selected insert sends to them (tap to route / unroute).
#   7 Perform   FL's performance mode: 8 playlist tracks x 2 blocks; a tap launches, a half-second hold stops the
#               track.
# Shift pad + Left / Right: the page (steps by 16, channels by 8, patterns by 16, performance blocks by 1).
# Oct- + top-row pads: 1 / 2 insert bank, 3 / 4 previous / next pattern, 5 Capture MIDI, 6 Undo, 7 Redo, 8 new pattern.
# Overview: the bottom row is a transport row (oscfl_padfuncs, wired by SETTINGS['pad_map']): a plain press runs its
# function; Oct- / Shift + bottom row still picks the pad mode, the top row keeps the mode's top row.
# Names (CELL_NAME 40-55) tell the keyboard's Oct- hint what a plain press does now (names()).
import oscfl_proto as P
import oscfl_padfuncs as PF

MODES = ['steps', 'chans', 'patterns', 'mute', 'solo', 'arm', 'perf', 'route']
NAMES = {'steps': 'Steps', 'chans': 'Channels', 'patterns': 'Patterns', 'mute': 'Mute', 'solo': 'Solo', 'arm': 'Arm',
         'perf': 'Perform', 'route': 'Route'}
MODE_RGB = {'steps': (40, 127, 40), 'chans': (127, 60, 0), 'patterns': (90, 40, 127), 'mute': (127, 100, 0),
            'solo': (20, 70, 127), 'arm': (127, 10, 10), 'perf': (0, 110, 110), 'route': (110, 110, 110)}
WHITE = (127, 127, 127)
OFF = (0, 0, 0)
HOLD_MS = 500
# (name, FL step parameter id, max): K1-K8 while a step is held (channels.getCurrentStepParam)
STEP_PARAMS = [('Velocity', 1, 127), ('Release', 2, 127), ('Fine', 3, 240), ('Pan', 4, 127), ('Mod X', 5, 127),
               ('Mod Y', 6, 127), ('Shift', 7, None), ('Note', 0, 127)]


def dim(c, f):
    return (c[0] * f, c[1] * f, c[2] * f)


class Pads(object):
    def __init__(self, surface):
        self.s = surface
        self.mode = 'steps'
        self.step_page = 0
        self.chan_first = 0          # first channel of the Channels page (also the Overview's K9-K16)
        self.pat_first = 1           # first pattern of the Patterns page (patterns count from 1)
        self.block = 0               # first performance block
        self.held = None             # a held step: {'step', 'new', 'edited'}
        self.perf_hold = None        # a held performance pad: {'idx', 't', 'track', 'block', 'stopped'}
        self.told_perf = False

    @property
    def fl(self):
        return self.s.fl

    # ---- steps ------------------------------------------------------------------------------------------------

    def steps_len(self):
        n = self.fl.patterns.getPatternLength(self.s.pattern()) * 4
        return n if n > 0 else 16

    def step_pages(self):
        return max(1, (self.steps_len() + 15) // 16)

    def playing_step(self):
        if not self.fl.transport.isPlaying() or self.s.song_mode():
            return -1
        return self.fl.mixer.getSongStepPos() % self.steps_len()

    def step_value(self, ch, step, param):
        return self.fl.channels.getCurrentStepParam(ch, step, param)

    def shift_max(self):
        return max(1, self.s.ppq() // 4)

    # ---- input ------------------------------------------------------------------------------------------------

    def pad(self, idx, value, mod):
        if idx < 16:
            return
        slot, row2 = (idx - 16) & 7, idx >= 24
        if value == 0:
            self.release(idx)
            return
        if row2 and not mod:
            row = self.func_row()
            if row is not None:                             # the Overview's transport row
                if row[slot] is not None:
                    row[slot].run(self.s)
                return
        if mod and row2:                                    # Oct- / Shift + bottom row: pick a mode
            self.pick(MODES[slot])
            return
        if mod:                                             # Oct- / Shift + top row: bank, patterns, edit commands
            self.action(slot)
            return
        m = self.mode
        if m == 'steps':
            self.step_press(idx - 16)
        elif m == 'chans':
            self.chan_press(slot, row2)
        elif m == 'patterns':
            self.fl.patterns.jumpToPattern(self.pat_first + idx - 16)
        elif m == 'perf':
            if self.perf_ok():
                self.perf_hold = {'idx': idx, 't': self.s.clock(), 'track': self.s.offset + 1 + slot,
                                  'block': self.block + (1 if row2 else 0), 'stopped': False}
        else:
            self.track_press(slot, row2)

    def func_row(self):
        """The 8 functions of the bottom row in this view (the Overview), or None: the pads keep their mode."""
        s = self.s
        if s.view == P.MODE_OVERVIEW and s.views():
            return PF.pad_row(s, 'overview')
        return None

    def pick(self, mode):
        self.mode = mode
        self.held = None
        self.perf_hold = None
        what = NAMES[mode]
        if mode == 'steps':
            ch = self.s.channel()
            what += ' of %s' % (self.fl.channels.getChannelName(ch) if ch is not None else 'no channel')
        elif mode == 'perf' and not self.perf_ok():
            what += ' (turn on performance mode)'
        self.s.notify('Pads: %s' % what, 1, 12)

    def action(self, slot):
        s, fl = self.s, self.fl
        if slot in (0, 1):
            s.scroll_bank(-1 if slot == 0 else 1)
        elif slot in (2, 3):
            pat = s.pattern() + (-1 if slot == 2 else 1)
            if 1 <= pat <= fl.patterns.patternMax():
                fl.patterns.jumpToPattern(pat)
        elif slot == 4:
            s.capture()
        elif slot == 5:
            fl.general.undoUp()
        elif slot == 6:
            fl.general.undoDown()
        elif slot == 7:
            s.new_pattern()

    def step_press(self, k):
        ch = self.s.channel()
        step = self.step_page * 16 + k
        if ch is None or step >= self.steps_len():
            return
        c = self.fl.channels
        on = c.getGridBit(ch, step)
        if not on:
            c.setGridBit(ch, step, True)
        self.held = {'idx': 16 + k, 'step': step, 'new': not on, 'edited': False}

    def chan_press(self, slot, row2):
        c = self.fl.channels
        ch = self.chan_first + slot
        if ch >= c.channelCount():
            return
        if row2:
            c.muteChannel(ch)
        else:
            c.selectOneChannel(ch)

    def track_press(self, slot, row2):
        s, m = self.s, self.fl.mixer
        i = s.strip(slot)
        if i is None:
            return
        if not row2:
            m.setTrackNumber(i, s.C('curfxScrollToMakeVisible', 1))
            return
        mode = self.mode
        if mode == 'mute':
            m.muteTrack(i)
        elif mode == 'solo':
            m.soloTrack(i)
        elif mode == 'arm':
            m.armTrack(i)
        elif mode == 'route':
            src = s.sel_insert()
            if src != i:
                m.setRouteTo(src, i, not m.getRouteSendActive(src, i), True)

    def release(self, idx):
        h = self.held
        if h is not None and h['idx'] == idx:
            self.held = None
            ch = self.s.channel()
            if ch is not None and not h['new'] and not h['edited']:
                self.fl.channels.setGridBit(ch, h['step'], False)
            return
        p = self.perf_hold
        if p is not None and p['idx'] == idx:
            self.perf_hold = None
            if not p['stopped']:
                self.fl.playlist.triggerLiveClip(p['track'], p['block'], self.s.C('TLC_MuteOthers', 1))

    def knob(self, k, d):
        """A knob turned while a step is held edits that step. True when it was used."""
        h = self.held
        ch = self.s.channel()
        if h is None or ch is None:
            return False
        name, param, top = STEP_PARAMS[k]
        top = top if top is not None else self.shift_max()
        v = P.clamp(self.step_value(ch, h['step'], param) + d, 0, top)
        self.fl.channels.setStepParameterByIndex(ch, self.s.pattern(), h['step'], param, int(v))
        h['edited'] = True
        return True

    def page(self, direction):
        """Shift pad + Left / Right. True when the pads had a page to move."""
        m, fl = self.mode, self.fl
        if m == 'steps':
            self.step_page = P.clamp(self.step_page + direction, 0, self.step_pages() - 1)
        elif m == 'chans':
            n = fl.channels.channelCount()
            to = self.chan_first + 8 * direction
            if 0 <= to < max(n, 1):
                self.chan_first = to
        elif m == 'patterns':
            to = self.pat_first + 16 * direction
            if 1 <= to <= fl.patterns.patternMax():
                self.pat_first = to
        elif m == 'perf':
            self.block = max(0, self.block + direction)
        else:
            return False
        return True

    def poll(self, now):
        p = self.perf_hold
        if p is not None and not p['stopped'] and now - p['t'] >= HOLD_MS:
            p['stopped'] = True
            self.fl.playlist.triggerLiveClip(p['track'], -1, self.s.C('TLC_MuteOthers', 1))
            self.s.notify('Stopped %s' % self.fl.playlist.getTrackName(p['track']), 0, 8)
        if self.mode == 'steps':
            self.step_page = min(self.step_page, self.step_pages() - 1)

    def perf_ok(self):
        pl = self.fl.playlist
        return not hasattr(pl, 'getPerformanceModeState') or pl.getPerformanceModeState()

    # ---- what the screen shows --------------------------------------------------------------------------------

    def cells(self):
        """K1-K8 while a step is held: [(name, value 0..1, text)] x 8, else None."""
        h = self.held
        ch = self.s.channel()
        if h is None or ch is None:
            return None
        out = []
        for name, param, top in STEP_PARAMS:
            top = top if top is not None else self.shift_max()
            v = self.step_value(ch, h['step'], param)
            if param == 4:
                text = 'C' if v == 64 else ('%dL' % (64 - v) if v < 64 else '%dR' % (v - 64))
            elif param == 3:
                text = '%+d ct' % (v - 120)
            elif param == 0:
                text = note_name(v)
            else:
                text = '%d' % v
            out.append((name, v / float(top), text))
        return out

    def header_tail(self):
        if self.mode == 'steps':
            n = self.steps_len()
            a = self.step_page * 16 + 1
            return ' | Steps %d-%d/%d' % (a, min(a + 15, n), n)
        return ' | %s' % NAMES[self.mode]

    def render(self):
        s = self.s
        if s.shift:                                         # the Shift pad held: the choices
            lights = [((40, 40, 40), P.SOLID)] * 8
            lights += [(dim(MODE_RGB[m], 1 if m == self.mode else 0.2), P.SOLID) for m in MODES]
        else:
            lights = getattr(self, 'lights_' + self.mode, self.lights_tracks)()
            row = self.func_row()
            if row is not None:
                lights = lights[:8] + [PF.light(s, f) for f in row]
        s.link.send('pads', P.pads(16, lights))
        if s.has_pad_bank_b():
            self.render_names()

    # ---- pad names (CELL_NAME 40-55) -----------------------------------------------------------------------------

    def render_names(self):
        L, s = self.s.link, self.s
        for i, (name, color) in enumerate(self.names()):
            name = (name or '')[:10]
            L.send('pl%d' % i, P.cell_name(P.CELL_PAD + 16 + i, 1 if name else 0, color if name else OFF, name))

    def names(self):
        """[(name, rgb)] x 16, top row first: what a plain press does now ('' = nothing)."""
        out = getattr(self, 'names_' + self.mode, self.names_tracks)()
        row = self.func_row()
        if row is not None:
            out = out[:8] + [(f.label, f.rgb) if f else ('', OFF) for f in row]
        return out

    def names_steps(self):
        ch = self.s.channel()
        n = self.steps_len()
        col = rgb(self.fl.channels.getChannelColor(ch)) if ch is not None else OFF
        out = []
        for k in range(16):
            step = self.step_page * 16 + k
            out.append((str(step + 1), col) if ch is not None and step < n else ('', OFF))
        return out

    def names_chans(self):
        c = self.fl.channels
        n = c.channelCount()
        top, bottom = [], []
        for slot in range(8):
            ch = self.chan_first + slot
            if ch >= n:
                top.append(('', OFF))
                bottom.append(('', OFF))
            else:
                top.append((c.getChannelName(ch), rgb(c.getChannelColor(ch))))
                bottom.append(('Mute', MODE_RGB['mute']))
        return top + bottom

    def names_patterns(self):
        p = self.fl.patterns
        out = []
        for k in range(16):
            i = self.pat_first + k
            if i > p.patternMax():
                out.append(('', OFF))
            elif not p.isPatternDefault(i):
                out.append((p.getPatternName(i) or 'Pattern %d' % i, rgb(p.getPatternColor(i))))
            else:
                out.append(('New', (30, 30, 30)))
        return out

    def names_perf(self):
        pl = self.fl.playlist
        out = []
        if not self.perf_ok():
            return [('', OFF)] * 16
        for row in range(2):
            for slot in range(8):
                t = self.s.offset + 1 + slot
                if t > pl.trackCount():
                    out.append(('', OFF))
                else:
                    out.append((pl.getTrackName(t), rgb(pl.getTrackColor(t))))
        return out

    def names_tracks(self):
        s, m = self.s, self.fl.mixer
        top, bottom = [], []
        for slot in range(8):
            i = s.strip(slot)
            if i is None:
                top.append(('', OFF))
                bottom.append(('', OFF))
            else:
                top.append((m.getTrackName(i), rgb(m.getTrackColor(i))))
                bottom.append((NAMES[self.mode], MODE_RGB[self.mode]))
        return top + bottom

    def lights_steps(self):
        ch = self.s.channel()
        if ch is None:
            return [(OFF, P.SOLID)] * 16
        c = self.fl.channels
        col = rgb(c.getChannelColor(ch))
        n, play = self.steps_len(), self.playing_step()
        out = []
        for k in range(16):
            step = self.step_page * 16 + k
            if step >= n:
                out.append((OFF, P.SOLID))
            elif step == play:
                out.append((WHITE, P.SOLID))
            elif c.getGridBit(ch, step):
                out.append((col, P.SOLID))
            else:
                out.append((dim(col, 0.06) if k % 4 else dim(col, 0.15), P.SOLID))   # beats a little brighter
        return out

    def lights_chans(self):
        c = self.fl.channels
        n, sel = c.channelCount(), self.s.channel()
        top, bottom = [], []
        for slot in range(8):
            ch = self.chan_first + slot
            if ch >= n:
                top.append((OFF, P.SOLID))
                bottom.append((OFF, P.SOLID))
                continue
            top.append((dim(rgb(c.getChannelColor(ch)), 1 if ch == sel else 0.25), P.SOLID))
            bottom.append((dim(MODE_RGB['mute'], 1 if c.isChannelMuted(ch) else 0.12), P.SOLID))
        return top + bottom

    def lights_patterns(self):
        p = self.fl.patterns
        cur = self.s.pattern()
        out = []
        for k in range(16):
            i = self.pat_first + k
            if i > p.patternMax():
                out.append((OFF, P.SOLID))
            elif i == cur:
                out.append((rgb(p.getPatternColor(i)), P.SOLID))
            elif not p.isPatternDefault(i):
                out.append((dim(rgb(p.getPatternColor(i)), 0.25), P.SOLID))
            else:
                out.append(((6, 6, 6), P.SOLID))
        return out

    def lights_perf(self):
        pl = self.fl.playlist
        if not self.perf_ok():
            return [(OFF, P.SOLID)] * 16
        simple = self.s.C('LB_Status_Simple', 1)
        out = []
        for row in range(2):
            b = self.block + row
            for slot in range(8):
                t = self.s.offset + 1 + slot
                if t > pl.trackCount():
                    out.append((OFF, P.SOLID))
                    continue
                st = pl.getLiveBlockStatus(t, b, simple)
                col = rgb(pl.getLiveBlockColor(t, b))
                if st & 4:
                    out.append((col, P.PULSE))              # scheduled, not playing yet
                elif st & 2:
                    out.append((col, P.SOLID))              # playing
                elif st & 1:
                    out.append((dim(col, 0.25), P.SOLID))   # a clip is there
                else:
                    out.append((OFF, P.SOLID))
        return out

    def lights_tracks(self):
        s, m = self.s, self.fl.mixer
        ss = s.selected_slot()
        src = s.sel_insert()
        top, bottom = [], []
        base = MODE_RGB[self.mode]
        for slot in range(8):
            i = s.strip(slot)
            if i is None:
                top.append((OFF, P.SOLID))
                bottom.append((OFF, P.SOLID))
                continue
            top.append((dim(rgb(m.getTrackColor(i)), 1 if slot == ss else 0.25), P.SOLID))
            if self.mode == 'mute':
                on = m.isTrackMuted(i)
            elif self.mode == 'solo':
                on = m.isTrackSolo(i)
            elif self.mode == 'arm':
                on = m.isTrackArmed(i)
            else:
                on = i != src and m.getRouteSendActive(src, i)
            bottom.append((OFF if (self.mode == 'route' and i == src) else dim(base, 1 if on else 0.12), P.SOLID))
        return top + bottom


def rgb(color):
    c = int(color or 0) & 0xFFFFFF
    return (round(((c >> 16) & 255) * 127 / 255.0), round(((c >> 8) & 255) * 127 / 255.0), round((c & 255) * 127 / 255.0))


NOTES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']


def note_name(n):
    return '%s%d' % (NOTES[n % 12], n // 12 - 1)     # FL: 60 = C5 in its own naming; MIDI naming here (60 = C4)
