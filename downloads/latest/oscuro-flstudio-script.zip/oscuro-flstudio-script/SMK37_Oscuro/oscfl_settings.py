# Settings of the SMK-37 Oscuro script for FL Studio (FL has no settings panel for scripts): edit, save, then
# reload the script (Options > MIDI settings: select the controller and press "Update MIDI scripts", or restart FL).
SETTINGS = {
    'seq_views': True,      # SEQ cycles the screen views (False: the keyboard's own sequencer keeps SEQ)
    'soft_takeover': True,  # faders pick up the value (False: the value jumps to the fader)
    'accent': 'fl',         # 'fl': the script's green accent on the keyboard's screen; 'off': the keyboard's own
    'fine': False,          # 256 knob steps per range instead of 128 (Oct- or the Shift pad always gives 1024)
    'flush_budget': 300,    # bytes sent to the keyboard per pass (its MIDI input is small; a flood says "Host lost")
    'follow_window': True,  # FL's mixer window gaining the focus opens the Mixer view; another FL window (channel rack,
                            # playlist, piano roll, plugin) taking it leaves the Mixer view for Device
    # What the bottom row of pad bank B does per view (a plain press; Oct- / Shift + bottom row still picks the pad mode).
    # Names: Stop, Play, Rec, Song, Loop rec, Metro, Countdown, Step edit, Marker <, Marker >, Marker +, Undo, Redo,
    # Capture, Tap. '' = a dark pad. A view that is not listed keeps its own pads; an unknown name is a dark pad (logged).
    'pad_map': {'overview': ['Stop', 'Play', 'Rec', 'Song', 'Loop rec', 'Metro', 'Marker <', 'Marker >']},
}
