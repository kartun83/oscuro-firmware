# The SMK-37 under Oscuro firmware as an FL Studio surface (docs/design/2026-11-26-daw-flstudio.md).
#
# Views (SEQ tap cycles Device -> Mixer -> Overview; SEQ hold opens the presets of the device, Oct- + hold SEQ FL's
# browser):
#   Device    K1-K8 the plugin's parameters in banks of 8 (the focused effect, else the selected channel's
#             instrument); K9-K16 the selected channel (volume, pan, its mixer insert) and that insert (volume, pan,
#             stereo separation), the master volume. Left/Right bank, Oct- + Left/Right the next plugin (instrument,
#             then the effects of the channel's insert).
#   Mixer     8 insert strips; K1-K8 pan, K9-K16 stereo separation; Left/Right move the 4-fader window (then the bank).
#   Overview  tempo, position, pattern, song/pattern mode, switches; K1-K8 tempo / pattern / position / master
#             volume / master pan / snap / channel / insert, K9-K16 the volumes of 8 channels of the rack.
#   Browser   presets of the plugin (hold SEQ) or FL's browser (Oct- + hold SEQ).
#   The Mixer view follows FL: the selected insert's bank / fader half, and (follow_window) FL's focused window.
# Always: faders 1-4 = the window's 4 insert volumes (soft takeover), Fader Bank B = selected channel volume / pan and
# its insert's volume / pan; pad bank B in one of 8 pad modes (oscfl_pads); SEQ PLAY play/pause (Oct-: stop),
# SEQ REC record (Oct-: song / pattern mode), Oct- + SEQ metronome, Oct- + K8 tempo, TAP tempo.
#
# FL Studio's modules come in one object ('fl': mixer, channels, patterns, playlist, transport, general, ui, plugins,
# midi), so the tests pass fakes. The session is an OscLink, the clock returns ms.
import oscfl_proto as P
from oscfl_pads import Pads

VIEWS = [P.MODE_DEVICE, P.MODE_MIXER, P.MODE_OVERVIEW]
TITLES = {P.MODE_DEVICE: 'Device', P.MODE_MIXER: 'Mixer', P.MODE_OVERVIEW: 'Overview', P.MODE_BROWSER: 'Browser'}
ACCENT_FL = (70, 127, 50)      # step-button green: the script's fixed accent (setting accent='fl')
SEQ_HOLD_MS = 500
TEMPO_MIN, TEMPO_MAX = 10.0, 522.0     # FL Studio's tempo range
PARAM_SCAN = 1024              # parameters looked at per plugin (VSTs report 4240: 4096 + 128 CC + 16 aftertouch)
LIST_BROWSER, LIST_PRESETS = 1, 3
CAPTURE_S = 60                 # Capture MIDI: the last minute of played notes (general.dumpScoreLog)
FX_SLOTS = 10
OTHER_WINDOWS = (('widChannelRack', 1), ('widPlaylist', 2), ('widPianoRoll', 3), ('widPlugin', 5),
                 ('widPluginEffect', 6), ('widPluginGenerator', 7))     # follow_window: windows that leave the Mixer view

DEFAULT_PREFS = {
    'seq_views': True,      # SEQ cycles the screen views (False: the firmware's sequencer keeps SEQ)
    'soft_takeover': True,  # faders pick up the value (False: jump)
    'accent': 'fl',         # 'fl': the script's green accent; 'off': the keyboard's own
    'fine': False,          # 256 knob steps per range instead of 128 (a modifier always gives 1024)
    'follow_window': True,  # the Mixer view follows FL's focused window (mixer focused: Mixer; another window: Device)
}


def rgb7(color):
    """FL colour (int, 0x--RRGGBB as utils.ColorToRGB reads it) -> 0..127 triplet."""
    c = int(color or 0) & 0xFFFFFF
    return (round(((c >> 16) & 255) * 127 / 255.0), round(((c >> 8) & 255) * 127 / 255.0), round((c & 255) * 127 / 255.0))


def dim(c, f):
    return (c[0] * f, c[1] * f, c[2] * f)


def clamp01(v):
    return P.clamp(v, 0.0, 1.0)


class Param(object):
    """One knob target: get() / set() in 0..1, text() for the screen, bipolar for the arc."""

    def __init__(self, name, get, set_, text, bipolar=False, step=None):
        self.name, self.get, self.set, self.text, self.bipolar = name, get, set_, text, bipolar
        self.step = step            # detents -> value for stepped targets (None: continuous 0..1)


class OscSurface(object):
    def __init__(self, fl, link, prefs=None, clock=None, log=None):
        self.fl = fl
        self.link = link
        self.prefs = dict(DEFAULT_PREFS)
        self.prefs.update(prefs or {})
        self.clock = clock
        self.log = log or (lambda s: None)
        self.view = P.MODE_DEVICE
        self.prev_view = P.MODE_DEVICE
        self.shift = False           # the Shift pad is down (CONTROL class 4)
        self.window = 0              # first strip of the fader window: 0 or 4
        self.offset = 0              # first insert of the bank of 8 (0 = the first insert track)
        self.seq_down = 0
        self.seq_oct = False
        self.seq_used = False
        self.fader = [{'pos': -1.0, 'picked': False} for _ in range(8)]
        self.fader_toast = None
        self.bank = 0
        self.target_key = None       # what the device target followed last (to reset the bank)
        self.pin = None              # a plugin picked with Oct- + Left/Right: (index, slot, follow key)
        self.browse = None
        self.preset_at = {}          # (index, slot, name) -> the preset index the script last loaded
        self.param_cache = {}        # (index, slot, name, count) -> [(param index, name)]
        self.dims = {'pads': 16, 'pad_banks': 2, 'knobs': 8, 'knob_banks': 2, 'faders': 4, 'fader_banks': 2,
                     'shift_pad': 0}
        self.sel_last = None         # the mixer insert selected at the last render (follow_selection)
        self.focus = None            # (mixer window focused, another window focused) at the last poll; None: not seen yet
        self.pad_warned = set()      # unknown pad function names already logged
        self.pads = Pads(self)
        link.on_session = self.start

    # ---- session ----------------------------------------------------------------------------------------------

    def start(self, info=None):
        """A new session: claim what this unit has (HELLO_ACK says; the SMK-37 Elite and Pro report the same)."""
        L, B = self.link, P.BTN
        if info:
            for k in self.dims:
                if k in info:
                    self.dims[k] = info[k]
        d = self.dims
        knobs = d['knobs'] * max(d['knob_banks'], 1)
        faders = d['faders'] * max(d['fader_banks'], 1)
        buttons = (1 << B.LEFT) | (1 << B.RIGHT) | (1 << B.SEQ_PLAY) | (1 << B.SEQ_REC)
        if self.prefs['seq_views']:
            buttons |= 1 << B.SEQ
        L.raw(P.claim(P.RES_KNOB, (1 << min(knobs, 16)) - 1))
        L.raw(P.claim(P.RES_FADER, (1 << min(faders, 8)) - 1))
        if self.has_pad_bank_b():
            L.raw(P.claim(P.RES_PAD, 0xFFFF0000))           # pad bank B; bank A stays notes / Harmony
        L.raw(P.claim(P.RES_BUTTON, buttons))
        L.raw(P.scale(0, 0, 0, ''))                         # FL has no project scale: the keyboard keeps its own
        if self.prefs['accent'] == 'off' and L.has(P.CAP_ACCENT):
            L.raw(P.accent((0, 0, 0)))
        for f in self.fader:
            f['picked'] = False
        self.sel_last = None
        self.render()

    def has_pad_bank_b(self):
        return self.dims['pads'] * self.dims['pad_banks'] >= 32

    def views(self):
        return self.link.has(P.CAP_VIEWS)

    def notify(self, text, priority=1, timeout=12):
        if self.link.has(P.CAP_NOTIFY):
            self.link.raw(P.notify(priority, timeout, text))
        else:
            self.hint(text)

    def hint(self, text):
        try:
            self.fl.ui.setHintMsg(text)
        except Exception:  # noqa: BLE001 - the hint bar is a nicety
            pass

    def has(self, module, name):
        return hasattr(getattr(self.fl, module), name)

    def C(self, name, default):
        return getattr(self.fl.midi, name, default)

    # ---- FL helpers -------------------------------------------------------------------------------------------

    def first_insert(self):
        return self.fl.mixer.getTrackInfo(self.C('TN_FirstIns', 1))

    def insert_count(self):
        m = self.fl.mixer
        return m.getTrackInfo(self.C('TN_LastIns', 2)) - self.first_insert() + 1

    def strip(self, slot):
        """Mixer track index of bank slot 0-7, or None past the last insert."""
        if not 0 <= slot < 8 or self.offset + slot >= self.insert_count():
            return None
        return self.first_insert() + self.offset + slot

    def sel_insert(self):
        return self.fl.mixer.trackNumber()

    def selected_slot(self):
        i = self.sel_insert() - self.first_insert() - self.offset
        return i if 0 <= i < 8 else -1

    def channel(self):
        """The selected channel (group index), or None in an empty rack."""
        c = self.fl.channels
        if c.channelCount() == 0:
            return None
        i = c.selectedChannel(True)
        return i if i >= 0 else None

    def pattern(self):
        return self.fl.patterns.patternNumber()

    def ppq(self):
        return self.fl.general.getRecPPQ() or 96

    def beats_per_bar(self):
        return max(1, self.fl.general.getRecPPB() // self.ppq())

    def tempo(self):
        t = float(self.fl.mixer.getCurrentTempo())
        return t / 1000.0 if t > 1000 else t                # some versions answer BPM x 1000

    def set_tempo(self, bpm):
        g = self.fl.general
        bpm = P.clamp(bpm, TEMPO_MIN, TEMPO_MAX)
        g.processRECEvent(self.C('REC_Tempo', 0x4000 * 2 ** 16 + 5), int(round(bpm * 1000)),
                          self.C('REC_Control', 973) | self.C('REC_UpdateControl', 16))
        return bpm

    def song_ticks(self):
        return self.fl.transport.getSongPos(self.C('SONGLENGTH_ABSTICKS', 2))

    def move_song(self, beats):
        t = self.fl.transport
        mode = self.C('SONGLENGTH_ABSTICKS', 2)
        t.setSongPos(max(0, int(self.song_ticks() + beats * self.ppq())), mode)

    def song_mode(self):
        return self.fl.transport.getLoopMode() == 1

    # ---- the device target: a plugin on the channel rack or in a mixer slot -------------------------------------

    def follow_key(self):
        """What FL has in focus: a focused effect window, else the selected channel."""
        fl = self.fl
        if self.has('mixer', 'getActiveEffectIndex') and fl.ui.getFocused(self.C('widPluginEffect', 6)):
            fx = fl.mixer.getActiveEffectIndex()
            if fx is not None:
                return ('fx', fx[0], fx[1])
        return ('ch', self.channel(), -1)

    def targets(self):
        """The plugins Oct- + Left/Right steps through: the channel's instrument, then its insert's effects."""
        fl, out = self.fl, []
        ch = self.channel()
        if ch is not None:
            if fl.plugins.isValid(ch, -1):
                out.append((ch, -1))
            ins = fl.channels.getTargetFxTrack(ch)
            for s in range(FX_SLOTS):
                if fl.plugins.isValid(ins, s):
                    out.append((ins, s))
        return out

    def target(self):
        """(index, slot) of the plugin K1-K8 edit, or None. slot -1 = the channel rack (index = channel)."""
        key = self.follow_key()
        if key != self.target_key:
            self.target_key = key
            self.pin = None
            self.bank = 0
        if self.pin is not None:
            return self.pin
        if key[0] == 'fx':
            return (key[1], key[2])
        if key[1] is not None and self.fl.plugins.isValid(key[1], -1):
            return (key[1], -1)
        return None

    def target_name(self, t):
        if t is None:
            return ''
        return self.fl.plugins.getPluginName(t[0], t[1], True) or self.fl.plugins.getPluginName(t[0], t[1])

    def params(self, t):
        """The plugin's named parameters (cached per plugin): [(param index, name)]."""
        if t is None:
            return []
        pl = self.fl.plugins
        n = pl.getParamCount(t[0], t[1])
        key = (t[0], t[1], self.target_name(t), n)
        got = self.param_cache.get(key)
        if got is None:
            got = []
            for i in range(min(n, PARAM_SCAN)):
                name = pl.getParamName(i, t[0], t[1])
                if name and name.strip():
                    got.append((i, name.strip()))
            self.param_cache = {key: got}                   # one plugin cached: switching back re-reads it
        return got

    def bank_count(self, t):
        return (len(self.params(t)) + 7) // 8

    def plugin_param(self, t, k):
        ps = self.params(t)
        if not ps:
            return None
        self.bank = P.clamp(self.bank, 0, (len(ps) - 1) // 8)
        j = self.bank * 8 + k
        if j >= len(ps):
            return None
        pi, name = ps[j]
        pl = self.fl.plugins

        def text():
            s = pl.getParamValueString(pi, t[0], t[1])
            return s if s else '%d%%' % round(pl.getParamValue(pi, t[0], t[1]) * 100)
        return Param(name, lambda: pl.getParamValue(pi, t[0], t[1]),
                     lambda v: pl.setParamValue(v, pi, t[0], t[1]), text)

    # ---- mixer and channel parameters --------------------------------------------------------------------------

    def vol_param(self, i, name=None):
        m = self.fl.mixer
        return Param(name or m.getTrackName(i), lambda: m.getTrackVolume(i), lambda v: m.setTrackVolume(i, v),
                     lambda: '%.1f dB' % m.getTrackVolume(i, 1))

    def pan_param(self, i, name='Pan'):
        m = self.fl.mixer
        return Param(name, lambda: (m.getTrackPan(i) + 1) / 2.0, lambda v: m.setTrackPan(i, v * 2 - 1),
                     lambda: pan_text(m.getTrackPan(i)), True)

    def sep_param(self, i, name='Sep'):
        m = self.fl.mixer
        if not self.has('mixer', 'getTrackStereoSep'):
            return None
        return Param(name, lambda: (m.getTrackStereoSep(i) + 1) / 2.0, lambda v: m.setTrackStereoSep(i, v * 2 - 1),
                     lambda: '%d%%' % round(m.getTrackStereoSep(i) * 100), True)

    def chan_vol(self, ch, name='Ch Vol'):
        c = self.fl.channels
        return Param(name, lambda: c.getChannelVolume(ch), lambda v: c.setChannelVolume(ch, v),
                     lambda: '%.1f dB' % c.getChannelVolume(ch, True))

    def chan_pan(self, ch):
        c = self.fl.channels
        return Param('Ch Pan', lambda: (c.getChannelPan(ch) + 1) / 2.0, lambda v: c.setChannelPan(ch, v * 2 - 1),
                     lambda: pan_text(c.getChannelPan(ch)), True)

    def chan_insert(self, ch):
        """The channel's mixer insert (routing from the keyboard): one insert a detent."""
        c, m = self.fl.channels, self.fl.mixer
        last = m.getTrackInfo(self.C('TN_LastIns', 2))

        def text():
            i = c.getTargetFxTrack(ch)
            return 'Master' if i == 0 else m.getTrackName(i)
        return Param('Insert', lambda: c.getTargetFxTrack(ch) / float(max(last, 1)), None, text,
                     step=lambda d: c.setTargetFxTrack(ch, int(P.clamp(c.getTargetFxTrack(ch) + d, 0, last))))

    def device_bank_b(self, k):
        """K9-K16 in the Device view: channel Vol / Pan / Insert, the insert's Vol / Pan / Sep, Master."""
        ch = self.channel()
        if ch is None:
            return None
        ins = self.fl.channels.getTargetFxTrack(ch)
        if k == 0:
            return self.chan_vol(ch)
        if k == 1:
            return self.chan_pan(ch)
        if k == 2:
            return self.chan_insert(ch)
        if k == 3:
            return self.vol_param(ins, 'Ins Vol')
        if k == 4:
            return self.pan_param(ins, 'Ins Pan')
        if k == 5:
            return self.sep_param(ins, 'Ins Sep')
        if k == 6:
            return self.vol_param(0, 'Master')
        return None

    # ---- input ------------------------------------------------------------------------------------------------

    def control(self, m):
        oct_ = (m['mods'] & P.MOD_OCT) != 0
        mod = oct_ or (m['mods'] & P.MOD_SHIFT) != 0
        cls = m['cls']
        if cls == P.RES_KNOB:
            self.knob(m['index'], m['value'], oct_, mod)
        elif cls == P.RES_FADER:
            self.fader_move(m['index'], m['value'] / 16383.0)
        elif cls == P.RES_PAD:
            self.pads.pad(m['index'], m['value'], mod or self.shift)
        elif cls == P.RES_BUTTON:
            self.button(m['index'], m['value'] != 0, oct_)
        elif cls == P.RES_MOD:
            self.shift = m['value'] != 0

    def tempo_tap(self, x100):
        self.set_tempo(x100 / 100.0)

    def command(self, cid):
        fl = self.fl
        if cid == P.CMD_UNDO:
            fl.general.undoUp()
        elif cid == P.CMD_REDO:
            fl.general.undoDown()
        elif cid == P.CMD_METRONOME:
            self.global_transport('FPT_Metronome', 110)
        elif cid == P.CMD_LOOP:
            self.global_transport('FPT_LoopRecord', 113)
            self.notify('Loop recording %s' % ('on' if fl.ui.isLoopRecEnabled() else 'off'))
        elif cid in (P.CMD_PUNCH_IN, P.CMD_PUNCH_OUT):
            self.notify('FL Studio has no punch in / out')
        elif cid == P.CMD_CAPTURE:
            self.capture()
        elif cid == P.CMD_DUPLICATE:
            self.clone_pattern()
        elif cid == P.CMD_NEW_CLIP:
            self.new_pattern()
        elif cid == P.CMD_QUANTIZE:
            ch = self.channel()
            if ch is not None:
                fl.channels.quickQuantize(ch)
                self.notify('Quantized %s' % fl.channels.getChannelName(ch))

    def global_transport(self, name, default):
        self.fl.transport.globalTransport(self.C(name, default), 1)

    def capture(self):
        if self.has('general', 'dumpScoreLog'):
            self.fl.general.dumpScoreLog(CAPTURE_S, False)
            self.notify('Capture: last notes into %s' % self.fl.patterns.getPatternName(self.pattern()))
        else:
            self.notify('Capture needs a newer FL Studio')

    def clone_pattern(self):
        if self.has('patterns', 'clonePattern'):
            self.fl.patterns.clonePattern()
            self.notify('Pattern cloned')
        else:
            self.notify('Clone needs a newer FL Studio')

    def new_pattern(self):
        self.fl.patterns.findFirstNextEmptyPat(self.C('FFNEP_DontPromptName', 2))
        self.notify('New pattern %s' % self.fl.patterns.getPatternName(self.pattern()))

    def step(self, p, d, fine):
        """Detents -> a value step: 128 per range (256 with the 'fine' setting), 1024 with a modifier."""
        if p is None:
            return
        if p.step is not None:
            p.step(d)
            return
        div = 1024.0 if fine else (256.0 if self.prefs['fine'] else 128.0)
        p.set(clamp01(p.get() + d / div))

    def knob(self, idx, d, oct_, fine):
        bank_b, k = idx >= 8, idx & 7
        if oct_ and k == 7:                                 # Oct- + K8: tempo, 1 BPM a detent (0.1 with the Shift pad)
            bpm = self.set_tempo(self.tempo() + d * (0.1 if self.shift else 1.0))
            self.notify('Tempo %.2f' % bpm, 1, 8)
            return
        if not bank_b and self.pads.knob(k, d):            # a held step: its velocity, pan, ...
            return
        v = self.view
        if v == P.MODE_DEVICE:
            self.step(self.device_bank_b(k) if bank_b else self.plugin_param(self.target(), k), d, fine)
        elif v == P.MODE_MIXER:
            i = self.strip(k)
            if i is not None:
                self.step(self.sep_param(i) if bank_b else self.pan_param(i), d, fine)
        elif v == P.MODE_OVERVIEW:
            if bank_b:
                ch = self.pads.chan_first + k
                if ch < self.fl.channels.channelCount():
                    self.step(self.chan_vol(ch), d, fine)
            else:
                self.overview_knob(k, d, fine)
        elif v == P.MODE_BROWSER:
            self.list_knob(k, d)

    def overview_knob(self, k, d, fine):
        fl = self.fl
        if k == 0:
            self.set_tempo(self.tempo() + d * (0.1 if fine else 1.0))
        elif k == 1:
            fl.patterns.jumpToPattern(int(P.clamp(self.pattern() + d, 1, fl.patterns.patternMax())))
        elif k == 2:
            self.move_song(d * (1 if fine else self.beats_per_bar()))
        elif k == 3:
            self.step(self.vol_param(0, 'Master'), d, fine)
        elif k == 4:
            self.step(self.pan_param(0, 'Mst Pan'), d, fine)
        elif k == 5:
            fl.ui.snapMode(1 if d > 0 else -1)
        elif k == 6:
            n = fl.channels.channelCount()
            ch = self.channel()
            if n and ch is not None:
                fl.channels.selectOneChannel(int(P.clamp(ch + d, 0, n - 1)))
        elif k == 7:
            last = fl.mixer.getTrackInfo(self.C('TN_LastIns', 2))
            fl.mixer.setTrackNumber(int(P.clamp(self.sel_insert() + d, 0, last)), self.C('curfxScrollToMakeVisible', 1))

    def button(self, bid, down, oct_):
        B, t = P.BTN, self.fl.transport
        if bid == B.SEQ:
            if down:
                self.seq_down = self.clock() or 1
                self.seq_oct = oct_
                self.seq_used = False
            else:
                if self.seq_down and not self.seq_used:
                    if self.seq_oct:                        # Oct- + SEQ tap: the metronome (a hold browses)
                        self.global_transport('FPT_Metronome', 110)
                    else:
                        self.cycle_view()
                self.seq_down = 0
            return
        if not down:
            return
        if bid == B.SEQ_PLAY:
            if oct_:
                t.stop()
            else:
                t.start()                                   # play / pause
        elif bid == B.SEQ_REC:
            if oct_:
                t.setLoopMode()                             # song <-> pattern
                self.notify('Song mode' if self.song_mode() else 'Pattern mode')
            else:
                t.record()
        elif bid in (B.LEFT, B.RIGHT):
            self.nav(1 if bid == B.RIGHT else -1, oct_)

    def poll(self, now):
        """Every ~100 ms: a held SEQ becomes the browser; a fader whose target moved without it needs pick-up again."""
        if self.seq_down and not self.seq_used and now - self.seq_down >= SEQ_HOLD_MS:
            self.seq_used = True
            self.open_browser(self.seq_oct)
        self.pads.poll(now)
        self.follow_window()
        for i in range(8):
            f = self.fader[i]
            p = self.fader_target(i)
            if p is not None and f['picked'] and f['pos'] >= 0 and abs(f['pos'] - p.get()) > 0.02 and \
                    not (self.fader_toast and self.fader_toast['i'] == i and now < self.fader_toast['until']):
                f['picked'] = False

    def follow_window(self):
        """Setting 'follow_window': FL's mixer window gaining the focus opens the Mixer view; another window (channel
        rack, playlist, piano roll, plugin) taking it while the Mixer view shows goes back to Device. Edges only (the
        first observation just records the state), never while the Browser view is open."""
        if not self.prefs.get('follow_window', True) or not self.views():
            return
        ui = self.fl.ui
        mixer = bool(ui.getFocused(self.C('widMixer', 0)))
        other = any(ui.getFocused(self.C(n, d)) for n, d in OTHER_WINDOWS)
        was, self.focus = self.focus, (mixer, other)
        if was is None or self.view == P.MODE_BROWSER:
            return
        if mixer and not was[0]:
            self.set_view(P.MODE_MIXER)
        elif other and not was[1] and not mixer and self.view == P.MODE_MIXER:
            self.set_view(P.MODE_DEVICE)

    def follow_selection(self):
        """The mixer window follows the insert selected in FL (mouse, a pad, anything): the bank of 8 holding it, and
        the 4-fader half it sits in (those faders need pick-up again). Only a change of the selected insert moves
        anything, so Left / Right paging sticks until the selection changes. Master and 'current' do not move it."""
        sel = self.sel_insert()
        if sel == self.sel_last:
            return
        self.sel_last = sel
        i = sel - self.first_insert()
        if not 0 <= i < self.insert_count():
            return
        self.offset = i // 8 * 8
        w = 4 if i % 8 >= 4 else 0
        if w != self.window:
            self.window = w
            for k in range(4):
                self.fader[k]['picked'] = False

    def cycle_view(self):
        if self.view == P.MODE_BROWSER:
            self.close_list()
            return
        i = VIEWS.index(self.view) if self.view in VIEWS else -1
        self.set_view(VIEWS[(i + 1) % len(VIEWS)])

    def set_view(self, v):
        if v == self.view:
            return
        if v == P.MODE_BROWSER:
            self.prev_view = self.view
        self.view = v

    def nav(self, direction, oct_):
        if self.shift and self.pads.page(direction):        # Shift pad + Left / Right: the pads' page
            return
        v = self.view
        if v == P.MODE_DEVICE:
            if oct_:
                ts = self.targets()
                cur = self.target()
                i = ts.index(cur) if cur in ts else -1
                j = i + direction
                if ts and 0 <= j < len(ts):
                    self.pin = ts[j]
                    self.bank = 0
                    self.notify('Plugin: %s' % self.target_name(ts[j]), 1, 10)
            else:
                n = self.bank_count(self.target())
                self.bank = P.clamp(self.bank + direction, 0, max(n - 1, 0))
        elif v == P.MODE_MIXER:
            n = self.insert_count()
            if oct_:
                self.scroll_bank(direction)
            elif direction > 0 and self.window == 0:
                self.window = 4
            elif direction < 0 and self.window == 4:
                self.window = 0
            elif direction > 0 and self.offset + 8 < n:
                self.offset += 8
                self.window = 0
            elif direction < 0 and self.offset > 0:
                self.offset = max(0, self.offset - 8)
                self.window = 4
            for i in range(4):
                self.fader[i]['picked'] = False
        elif v == P.MODE_OVERVIEW:
            self.move_song(direction * self.beats_per_bar() * (4 if oct_ else 1))
        elif v == P.MODE_BROWSER:
            if direction > 0:
                self.list_confirm()
            else:
                self.list_back()

    def scroll_bank(self, direction):
        to = self.offset + 8 * direction
        if 0 <= to < max(self.insert_count(), 1):
            self.offset = to
            for i in range(4):
                self.fader[i]['picked'] = False

    # ---- lists: plugin presets and FL's browser (v1 LIST in the Browser view) ---------------------------------

    def open_browser(self, whole):
        t = self.target()
        pl = self.fl.plugins
        if not whole and t is not None:
            n = pl.getPresetCount(t[0], t[1]) if self.has('plugins', 'getPresetCount') else 0
            if n > 0:
                key = (t[0], t[1], self.target_name(t))
                cur = self.preset_at.get(key, 0)
                self.browse = {'mode': 'presets', 'target': t, 'key': key, 'count': n, 'cursor': cur,
                               'title': self.target_name(t)}
                self.set_view(P.MODE_BROWSER)
                return
            self.notify('No presets for %s: FL browser' % self.target_name(t))
        if not self.has('ui', 'navigateBrowser'):
            self.notify('Browsing needs a newer FL Studio')
            return
        ui = self.fl.ui
        ui.showWindow(self.C('widBrowser', 4))
        ui.setFocused(self.C('widBrowser', 4))
        self.browse = {'mode': 'fl', 'rows': [ui.getFocusedNodeCaption() or ''], 'cursor': 0, 'title': 'FL Browser'}
        self.set_view(P.MODE_BROWSER)

    def preset_name(self, b, i):
        t = b['target']
        return self.fl.plugins.getName(t[0], t[1], self.C('FPN_Preset', 6), i) or 'Preset %d' % (i + 1)

    def list_knob(self, k, d):
        b = self.browse
        if b is None or k > 1:
            return
        step = d * (8 if k == 1 else 1)
        if b['mode'] == 'presets':
            b['cursor'] = P.clamp(b['cursor'] + step, 0, b['count'] - 1)
            return
        ui = self.fl.ui                                     # FL's browser: move its own cursor, remember the names
        for _ in range(abs(step)):
            name = ui.navigateBrowser(41 if step > 0 else 40, False) or ui.getFocusedNodeCaption() or ''
            if step > 0:
                b['cursor'] += 1
                if b['cursor'] >= len(b['rows']):
                    b['rows'].append(name)
                else:
                    b['rows'][b['cursor']] = name
            elif b['cursor'] > 0:
                b['cursor'] -= 1
                b['rows'][b['cursor']] = name
            else:
                b['rows'].insert(0, name)

    def is_folder(self):
        return self.fl.ui.getFocusedNodeFileType() <= -100

    def list_confirm(self):
        b = self.browse
        if b is None:
            return
        if b['mode'] == 'presets':
            t, pl = b['target'], self.fl.plugins
            cur = self.preset_at.get(b['key'], 0)
            for _ in range(abs(b['cursor'] - cur)):         # FL loads presets one step at a time
                if b['cursor'] > cur:
                    pl.nextPreset(t[0], t[1])
                else:
                    pl.prevPreset(t[0], t[1])
            self.preset_at[b['key']] = b['cursor']
            self.notify('Loaded %s' % self.preset_name(b, b['cursor']))
            self.close_list()
            return
        ui = self.fl.ui
        if self.is_folder():
            ui.navigateBrowser(41, True)                    # shift: open the folder
            b['rows'] = [ui.getFocusedNodeCaption() or '']
            b['cursor'] = 0
            return
        if self.shift:
            ui.previewBrowserMenuItem()
            return
        ui.enter()                                          # what Enter does in FL's browser: load into the channel
        self.notify('Loaded %s' % (ui.getFocusedNodeCaption() or ''))
        self.close_list()

    def list_back(self):
        b = self.browse
        if b is not None and b['mode'] == 'fl' and self.shift:
            self.fl.ui.previewBrowserMenuItem()
            return
        self.close_list()

    def close_list(self):
        self.browse = None
        self.view = self.prev_view if self.prev_view != P.MODE_BROWSER else P.MODE_DEVICE

    # ---- faders: soft takeover --------------------------------------------------------------------------------

    def fader_target(self, i):
        if i < 4:
            s = self.strip(self.window + i)
            return self.vol_param(s) if s is not None else None
        ch = self.channel()
        if ch is None:
            return None
        ins = self.fl.channels.getTargetFxTrack(ch)
        return [self.chan_vol(ch), self.chan_pan(ch), self.vol_param(ins, 'Ins Vol'), self.pan_param(ins, 'Ins Pan')][i - 4]

    def fader_move(self, i, pos):
        if i > 7:
            return
        f, p = self.fader[i], self.fader_target(i)
        if p is None:
            return
        v = p.get()
        crossed = f['pos'] >= 0 and (f['pos'] - v) * (pos - v) <= 0
        if not self.prefs['soft_takeover'] or f['picked'] or abs(pos - v) < 0.02 or crossed:
            f['picked'] = True
            p.set(clamp01(pos))
        f['pos'] = pos
        self.fader_toast = {'i': i, 'until': self.clock() + 1200}

    # ---- render: the whole state; OscLink sends only what changed ---------------------------------------------

    def render(self):
        if self.link.state != 'up':
            return
        L = self.link
        views = self.views()
        self.follow_selection()
        L.send('mode', P.mode(self.view if views else P.MODE_DEVICE, TITLES[self.view]))
        self.render_transport()
        self.render_tracks()
        self.render_cells()
        if self.has_pad_bank_b():
            self.pads.render()
        self.render_buttons()
        if L.has(P.CAP_HEADER):
            L.send('header', self.header())
        if L.has(P.CAP_TABS):
            L.send('tabs', self.tabs())
        self.render_toast(views)
        if L.has(P.CAP_ACCENT) and self.prefs['accent'] != 'off':
            L.send('accent', P.accent(ACCENT_FL))          # once per session (the link drops repeats)
        if views and self.view == P.MODE_BROWSER:
            self.render_list()

    def render_toast(self, views):
        ft, L = self.fader_toast, self.link
        if not (ft and self.clock() < ft['until'] and not (views and self.view == P.MODE_MIXER) and L.has(P.CAP_NOTIFY)):
            return
        p = self.fader_target(ft['i'])
        if p is None:
            return
        txt = p.text()
        f = self.fader[ft['i']]
        if self.prefs['soft_takeover'] and not f['picked']:
            txt += '  (move up)' if f['pos'] < p.get() else '  (move down)'
        L.send('ftoast', P.notify(0, 12, '%s: %s' % (p.name, txt)))

    def render_transport(self):
        fl, f = self.fl, 0
        if fl.transport.isPlaying():
            f |= P.TR_PLAYING
        if fl.transport.isRecording():
            f |= P.TR_RECORDING
        if fl.ui.isLoopRecEnabled():
            f |= P.TR_LOOP
        if fl.ui.isMetronomeEnabled():
            f |= P.TR_METRONOME
        if fl.ui.isPrecountEnabled():
            f |= P.TR_COUNT_IN
        self.link.send('transport', P.transport(f, self.tempo() * 100))

    def render_position(self):
        """Position and time signature (the caller's 10 Hz timer). FL reports beats per bar, not the denominator."""
        L = self.link
        if not L.has(P.CAP_PROJECT):
            return
        ppq, bpb = self.ppq(), self.beats_per_bar()
        ticks = max(0, int(self.song_ticks()))
        bar, in_bar = divmod(ticks, ppq * bpb)
        beat, in_beat = divmod(in_bar, ppq)
        six = in_beat * 4 // ppq
        if self.song_mode():
            name = 'Song'
        else:
            name = 'Pat: %s' % self.fl.patterns.getPatternName(self.pattern())
        L.send('project', P.project(bar + 1, beat + 1, six + 1, bpb, 4, name))

    def render_meters(self):
        if self.view == P.MODE_MIXER and self.link.has(P.CAP_METERS):
            m, lv = self.fl.mixer, []
            for i in range(8):
                s = self.strip(i)
                lv.append(min(m.getTrackPeaks(s, self.C('PEAK_LR', 2)), 1.0) * 127 if s is not None else 0)
            self.link.send('meters', P.meters(0, lv))

    def track_flags(self, i):
        if i is None:
            return 0
        m = self.fl.mixer
        f = P.TRK_EXISTS
        if m.isTrackMuted(i):
            f |= P.TRK_MUTE
        if m.isTrackSolo(i):
            f |= P.TRK_SOLO
        if m.isTrackArmed(i):
            f |= P.TRK_ARMED
        return f

    def render_tracks(self):
        m = self.fl.mixer
        ss = self.selected_slot()
        for slot in range(8):
            i = self.strip(slot)
            f = self.track_flags(i)
            if f and slot == ss:
                f |= P.TRK_SELECTED
            self.link.send('trk%d' % slot, P.track(slot, f, rgb7(m.getTrackColor(i)) if i is not None else None,
                                                   m.getTrackName(i) if i is not None else ''))
        ch = self.channel()                                 # slot 8: the selected channel (what the keys play)
        if ch is None:
            self.link.send('trk8', P.track(8, 0, None, ''))
        else:
            c = self.fl.channels
            f = P.TRK_EXISTS | P.TRK_SELECTED
            if c.isChannelMuted(ch):
                f |= P.TRK_MUTE
            if c.isChannelSolo(ch):
                f |= P.TRK_SOLO
            self.link.send('trk8', P.track(8, f, rgb7(c.getChannelColor(ch)), c.getChannelName(ch)))

    def param_cell(self, target, p):
        """A parameter as a cell; a slot without one is disabled (v1) or blank (v0). FL exposes no modulation, so
        the modulation marker is never used."""
        L, v1 = self.link, self.link.has(P.CAP_CELL_V1)
        if p is None:
            L.send('cn%d' % target, P.cell_name(target, P.CELL_DISABLED if v1 else 0, None, ''))
            L.send('cv%d' % target, P.cell_value(target, 0, ''))
            return
        L.send('cn%d' % target, P.cell_name(target, P.CELL_BAR_BI if p.bipolar else P.CELL_BAR_UNI, None, p.name))
        L.send('cv%d' % target, P.cell_value(target, clamp01(p.get()) * 16383, p.text()))

    def text_cell(self, target, name, value01=0.0, text=''):
        L, v1 = self.link, self.link.has(P.CAP_CELL_V1)
        L.send('cn%d' % target, P.cell_name(target, P.CELL_BAR_UNI if name else (P.CELL_DISABLED if v1 else 0), None, name or ''))
        L.send('cv%d' % target, P.cell_value(target, clamp01(value01) * 16383, text or ''))

    def render_cells(self):
        v, fl = self.view, self.fl
        step = self.pads.cells()                            # a held step: K1-K8 are its parameters
        if v == P.MODE_DEVICE:
            t = self.target()
            for i in range(8):
                if step is not None:
                    self.text_cell(i, *step[i])
                else:
                    self.param_cell(i, self.plugin_param(t, i))
                self.param_cell(8 + i, self.device_bank_b(i))
        elif v == P.MODE_MIXER:
            for i in range(8):
                s = self.strip(i)
                self.param_cell(i, self.pan_param(s) if s is not None else None)
                self.param_cell(8 + i, self.sep_param(s) if s is not None else None)
        elif v == P.MODE_OVERVIEW:
            pat = self.pattern()
            tempo = self.tempo()
            self.text_cell(0, 'Tempo', (tempo - TEMPO_MIN) / (TEMPO_MAX - TEMPO_MIN), '%.2f' % tempo)
            self.text_cell(1, 'Pattern', pat / float(max(fl.patterns.patternMax(), 1)), fl.patterns.getPatternName(pat))
            self.text_cell(2, 'Position', 0, fl.transport.getSongPosHint())
            self.param_cell(3, self.vol_param(0, 'Master'))
            self.param_cell(4, self.pan_param(0, 'Mst Pan'))
            self.text_cell(5, 'Snap', 0, snap_text(fl.ui.getSnapMode()))
            ch = self.channel()
            self.text_cell(6, 'Channel', 0, fl.channels.getChannelName(ch) if ch is not None else '')
            self.text_cell(7, 'Insert', 0, fl.mixer.getTrackName(self.sel_insert()))
            n = fl.channels.channelCount()
            for i in range(8):
                c = self.pads.chan_first + i
                self.param_cell(8 + i, self.chan_vol(c, fl.channels.getChannelName(c)) if c < n else None)
        elif v == P.MODE_BROWSER:
            for i in range(16):
                self.text_cell(i, ['Scroll', 'Page'][i] if i < 2 else '', 0, '')
        if v != P.MODE_DEVICE and step is not None:         # a held step outside the Device view: K1-K8 still edit it
            for i in range(8):
                self.text_cell(i, *step[i])
        # faders: cells 16-23 are the 8 strips' volumes (the Mixer view draws them); the window's 4 are named F1-F4,
        # with ^ / v while a fader waits for pick-up (move it that way)
        for i in range(8):
            s = self.strip(i)
            name = ''
            p = self.vol_param(s) if s is not None else None
            if p is not None and self.window <= i < self.window + 4:
                f = self.fader[i - self.window]
                name = 'F%d' % (i - self.window + 1)
                if self.prefs['soft_takeover'] and not f['picked'] and f['pos'] >= 0:
                    name += '^' if f['pos'] < p.get() else 'v'
            self.link.send('cn%d' % (16 + i), P.cell_name(16 + i, 0, None, name))
            self.link.send('cv%d' % (16 + i), P.cell_value(16 + i, clamp01(p.get()) * 16383 if p else 0,
                                                           p.text() if p else ''))

    def header(self):
        v = self.view
        if v == P.MODE_DEVICE:
            t = self.target()
            if t is None:
                ch = self.channel()
                return P.header(self.fl.channels.getChannelName(ch) if ch is not None else 'No channel', 'no plugin')
            n = self.bank_count(t)
            if not n:
                return P.header(self.target_name(t), 'no parameters')
            self.bank = P.clamp(self.bank, 0, n - 1)
            where = ' Fx%d' % (t[1] + 1) if t[1] >= 0 else ''            # an effect: its mixer slot
            return P.header(self.target_name(t), '%d/%d%s%s' % (self.bank + 1, n, where, self.pads.header_tail()))
        if v == P.MODE_MIXER:
            return P.header('Mixer', 'Inserts %d-%d' % (self.offset + 1, self.offset + 8))
        if v == P.MODE_OVERVIEW:
            return P.header('Overview', 'Song' if self.song_mode() else 'Pattern')
        return P.header('Browser', self.browse['title'] if self.browse else '')

    def tabs(self):
        """The Device view's page line: the parameter banks either side of the current one, named by their parameter
        numbers ('1-8', '9-16', ...; the last one ends at the parameter count). Empty in the other views, with no
        plugin or parameters, and while a step is held (K1-K8 then edit the step)."""
        empty = P.tabs(0, 0, '', '', '')
        if self.view != P.MODE_DEVICE or self.pads.held is not None:
            return empty
        t = self.target()
        n = self.bank_count(t)
        if not n:
            return empty
        total = len(self.params(t))
        b = P.clamp(self.bank, 0, n - 1)

        def name(k):
            lo, hi = k * 8 + 1, min(k * 8 + 8, total)
            return '%d' % lo if lo == hi else '%d-%d' % (lo, hi)
        return P.tabs(b, n, name(b - 1) if b > 0 else '', name(b), name(b + 1) if b + 1 < n else '')

    def render_list(self):
        b = self.browse
        if b is None:
            return
        if b['mode'] == 'presets':
            total, cursor = b['count'], b['cursor']
            self.link.send('list', P.list_(LIST_PRESETS, total, cursor, b['title']))
            first = cursor // 8 * 8
            cur = self.preset_at.get(b['key'], 0)
            for r in range(8):
                i = first + r
                if i < total:
                    text = self.preset_name(b, i) + (' *' if i == cur else '')
                    self.link.send('row%d' % r, P.list_row(r, i, P.ROW_SELECTED if i == cursor else 0, None, text))
                else:
                    self.link.send('row%d' % r, P.list_row(r, i, 0, None, ''))
            return
        rows, cursor = b['rows'], b['cursor']               # FL's browser: the names seen so far around the cursor
        self.link.send('list', P.list_(LIST_BROWSER, len(rows), cursor, b['title']))
        first = cursor // 8 * 8
        for r in range(8):
            i = first + r
            text = rows[i] if i < len(rows) else ''
            self.link.send('row%d' % r, P.list_row(r, i, P.ROW_SELECTED if i == cursor else 0, None, text))

    def render_buttons(self):
        t, B, L = self.fl.transport, P.BTN, self.link
        L.send('bl%d' % B.SEQ_PLAY, P.button_led(B.SEQ_PLAY, 1 if t.isPlaying() else 0))
        L.send('bl%d' % B.SEQ_REC, P.button_led(B.SEQ_REC, 1 if t.isRecording() else 0))
        if self.prefs['seq_views']:
            L.send('bl%d' % B.SEQ, P.button_led(B.SEQ, 0 if self.view == P.MODE_DEVICE else 1))
        L.send('bl%d' % B.LEFT, P.button_led(B.LEFT, 1))
        L.send('bl%d' % B.RIGHT, P.button_led(B.RIGHT, 1))


def pan_text(v):
    p = int(round(v * 100))
    return 'C' if p == 0 else ('%dL' % -p if p < 0 else '%dR' % p)


SNAPS = {0: 'Line', 1: 'Cell', 3: 'None', 4: '1/6 step', 5: '1/4 step', 6: '1/3 step', 7: '1/2 step', 8: 'Step',
         9: '1/6 beat', 10: '1/4 beat', 11: '1/3 beat', 12: '1/2 beat', 13: 'Beat', 14: 'Bar', 15: '1/4 bar',
         16: '1/3 bar', 17: '1/2 bar'}          # midi.Snap_* (FL's own list; 14 is both Snap_Bar and Snap_SixthBar)


def snap_text(v):
    return SNAPS.get(v, '%d' % v)
