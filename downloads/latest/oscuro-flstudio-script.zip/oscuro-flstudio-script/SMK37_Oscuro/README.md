# SMK-37 Oscuro: FL Studio MIDI script

For an M-Vave **SMK-37 Elite or SMK-37 Pro** running **Oscuro firmware** with the DAW protocol. Both boards run the same Oscuro firmware and show the same MIDI ports, so the script treats them alike; the keyboard tells the script how many pads, knobs and faders it has. The DAW and DAW BT builds draw the Mixer, Overview and Browser screens; the other Oscuro builds get the knob names, values and pad lights.

On **M-Vave's own firmware** keep using M-Vave's FL script. If this one is picked for a keyboard on stock firmware, FL's hint bar says so, naming the Pro or the Elite, and the script does nothing else.

Status: tested against a fake FL API built from Image-Line's API stubs (79 surface tests), against the Live and Bitwig scripts' protocol code (7 parity tests), and against the firmware's protocol decoder (839 messages; `make check-flstudio` in the repository root). Every FL function it calls exists in FL Studio 2026 (26.1.6), and the `midi` constants match FL 2026's own `midi.py`. **Not yet run in FL Studio with a keyboard.** Design: `docs/design/2026-11-26-daw-flstudio.md`; test plan: `docs/test-specs/DAW4_daw_flstudio.md`.

## Install

1. Written for a current FL Studio (checked against FL Studio 2026 and Image-Line's API stubs, which go up to API version 36). Older versions lose what they lack: cloning patterns and following a focused effect window need API 25, the browser API 22, performance mode state API 21.
2. Copy this folder (`SMK37_Oscuro`, without `tests/`) into FL's **Settings/Hardware** folder: `Documents/Image-Line/FL Studio/Settings/Hardware/` (macOS and Windows; the user data folder FL shows under *Options → File settings*). The `.py` files must sit directly in `Hardware/SMK37_Oscuro/`.
3. Start FL Studio: *Options → MIDI settings*. In **Input**, select the keyboard's DAW port (with *USB Ports: One* on the keyboard, **SMK-37 Oscuro USB**; with *Split*, its third port; over Bluetooth **SMK-37 Oscuro BLE**), enable it, choose **SMK-37 Oscuro** as the *Controller type* and give it a **Port** number, e.g. 10. In **Output**, select the same port and give it the **same port number**: that is how the script reaches the keyboard's screen and lights.
4. With *Split*, enable the Keys and Pads ports as *(generic controller)* inputs: they play the selected channel.

FL picks the script for the Oscuro port names by itself (`# supportedDevices`); on Windows, check the name FL shows and pick the script by hand if it did not.

Settings (FL has no settings panel for scripts): edit `oscfl_settings.py`, save, and reload the script (*MIDI settings → Update MIDI scripts*, or restart FL): SEQ button (screen views or the keyboard's sequencer), fader soft takeover, accent (the script's green or the keyboard's own), knob steps, `follow_window` (the Mixer view follows FL's focused window), `pad_map` (the Overview's transport row; names: Stop, Play, Rec, Song, Loop rec, Metro, Countdown, Step edit, Marker <, Marker >, Marker +, Undo, Redo, Capture, Tap; `''` is a dark pad, an unknown name is a dark pad and one line in FL's *Script output*), `flush_budget` (bytes sent to the keyboard per pass).

## Using it

| Control | Device view | Mixer view | Overview | Browser |
|---|---|---|---|---|
| K1–K8 | the plugin's parameters, 8 a bank: the focused effect window, else the selected channel's instrument | pan of 8 inserts | tempo, pattern, position, master volume, master pan, snap, channel, insert | K1 scroll, K2 by 8 |
| K9–K16 (Knob Bank B) | the selected channel's volume, pan and mixer insert (routing); that insert's volume, pan, stereo separation; master volume | stereo separation of the 8 inserts | volumes of 8 channels of the rack | — |
| Left / Right | bank | move the 4-fader window (then the bank) | one bar back / forward | back / load or open |
| Oct- + Left / Right | previous / next plugin: the channel's instrument, then the effects of its insert | insert bank by 8 | 4 bars | — |

Everywhere:

- **SEQ** tap: Device → Mixer → Overview. **Hold SEQ**: the presets of the plugin (Right loads one). **Oct- + hold SEQ**: FL's browser (Right opens a folder or loads the item into the selected channel; Shift pad + Right or Left previews). **Oct- + SEQ** tap: metronome.
- **Faders 1–4**: volumes of the 4 inserts in the window (F1–F4 on the Mixer screen). **Fader Bank B**: the selected channel's volume and pan, its insert's volume and pan. Soft takeover: a fader does nothing until it reaches the value (`F2^` = move up).
- **Pad bank B**: 8 pad modes, picked with **Oct- + a bottom pad** (hold the Shift pad to see them lit): 1 **Steps** (16 steps of the selected channel in the current pattern; the playing step is white), 2 **Channels** (top row selects 8 channels, bottom row mutes them), 3 **Patterns** (16 patterns; an empty pad makes one), 4 **Mute**, 5 **Solo**, 6 **Arm** (top row selects 8 mixer inserts, bottom row their mute / solo / arm), 7 **Perform** (performance mode: 8 playlist tracks × 2 blocks; tap launches, hold half a second stops the track), 8 **Route** (bottom row: does the selected insert send to these; tap to route). **Shift pad + Left / Right** turns the page. **Oct- + top pad** 1 / 2 insert bank, 3 / 4 previous / next pattern, 5 Capture MIDI (the last minute of played notes into the pattern), 6 Undo, 7 Redo, 8 new pattern. Pad bank A stays notes: it plays the selected channel.
- **Steps**: tap an empty step to set it; tap a set step and let go to clear it. Hold a step and turn **K1 velocity, K2 release, K3 fine pitch, K4 pan, K5 mod X, K6 mod Y, K7 shift, K8 note**: the step stays set.
- **Page line (TABS)**: in the Device view the screen's page line shows the plugin's parameter banks, named by parameter number (**1-8**, **9-16**, ...; the last one ends at the parameter count, e.g. **17-21**). It is empty in the other views, with no plugin, and while a step is held. Needs firmware 0.90.8.
- **Pad names**: hold **Oct-** with *Settings > Display > Hints* on and the keyboard lists what a plain press of each of the 16 pads of bank B does now (steps: the step number; channels, inserts and patterns: their names in their colours, the bottom row Mute / Solo / Arm / Route; the Overview: the transport functions). Needs firmware 0.90.8.
- **Overview transport row**: in the Overview the bottom row of pad bank B is the transport, a plain press runs it: **Stop, Play, Rec, Song, Loop rec, Metro, Marker <, Marker >** (the switches are bright while on, dim otherwise; markers need FL's `arrangement` module). **Oct- / Shift pad + a bottom pad** still picks the pad mode; the top row keeps the current mode's top row (in Steps that is steps 1-8 of the page). Which function sits on which pad is `pad_map` in `oscfl_settings.py`.
- **The Mixer follows FL**: select an insert in FL (mouse, a pad, anything) and the Mixer view shows its bank of 8 and the fader half (those faders need pick-up again). Left / Right paging sticks until the selection changes. With `follow_window` (default on), FL's mixer window gaining the focus opens the Mixer view; another FL window (channel rack, playlist, piano roll, plugin) taking the focus leaves it for Device.
- **SEQ PLAY** play / pause (Oct-: stop). **SEQ REC** record (Oct-: song / pattern mode). **Oct- + K8** tempo (0.1 BPM with the Shift pad). TAP taps FL's tempo.
- Globe, PATCH (Harmony Helper), ARP, SCALE, CHORD, Note Repeat, the octave and bank buttons stay the keyboard's; while one of its pages is open, the knobs and Left / Right belong to it.

What FL Studio does not offer, so the script does not either: modulation markers on the knobs, a project scale (the keyboard keeps its own), punch in / out, group tracks, a list of browser items (the screen shows the names the cursor has passed), a "current preset" (the script counts the presets it loaded; see the test plan).

## Files

`device_SMK37_Oscuro.py` (what FL calls), `oscfl_proto.py` (the protocol, `docs/DAW_PROTOCOL.md`), `oscfl_link.py` (session), `oscfl_surface.py` (views, knobs, faders, transport, browser), `oscfl_pads.py` (the 8 pad modes, pad names), `oscfl_padfuncs.py` (the transport functions of the Overview's bottom row), `oscfl_settings.py`. Module names start with `oscfl_` because FL may share modules between scripts. Tests: `tests/` (`python3 tests/test_surface.py`, `python3 tests/test_parity.py`; `gen_vectors.py` + `vectors.c` check every message against the firmware decoder).
