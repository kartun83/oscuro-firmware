# name=SMK-37 Oscuro
# supportedDevices=SMK-37 Oscuro USB,SMK-37 Oscuro USB DAW,SMK-37 Oscuro BLE,SMK-37 Oscuro BLE Bluetooth
#
# FL Studio MIDI controller script for an M-Vave SMK-37 Elite or SMK-37 Pro running Oscuro firmware (the DAW and DAW BT
# builds draw the Mixer, Overview and Browser screens; the other Oscuro builds get knob names, values and pad lights).
# Both boards run the same firmware and show the same port names; the HELLO_ACK says how many pads, knobs and faders
# the unit has. On M-Vave's own firmware this script does nothing but say so in FL's hint bar.
#
# This file is FL's glue only (the callbacks FL calls); oscfl_link (session), oscfl_surface (views) and oscfl_pads
# (pad bank B) do the work and run in the offline tests without FL. Design: docs/design/2026-11-26-daw-flstudio.md.
import time

import channels
import device
import general
import midi
import mixer
import patterns
import playlist
import plugins
import transport
import ui

try:
    import arrangement                                  # markers; without the module: no marker pads
except ImportError:  # pragma: no cover
    arrangement = None

import oscfl_proto as P
import oscfl_settings
from oscfl_link import OscLink
from oscfl_surface import OscSurface

NOT_FOUND_MS = 3000
IDLE_MS = 100
STOCK_NAMES = ('SMK-37 Pro', 'SMK37 Pro', 'SMK-37Pro', 'SMK-37 Elite', 'SMK37 Elite')


class FL(object):
    """FL Studio's modules in one object (the tests build the same object from fakes)."""
    mixer, channels, patterns, playlist, transport = mixer, channels, patterns, playlist, transport
    general, ui, plugins, midi, device = general, ui, plugins, midi, device
    if arrangement is not None:
        arrangement = arrangement


class Script(object):
    def __init__(self, fl, clock=None):
        self.fl = fl
        self.clock = clock or (lambda: int(time.time() * 1000))
        self.errors = set()
        self.told = False
        self.last_idle = -IDLE_MS
        settings = oscfl_settings.SETTINGS
        self.link = OscLink(self.send, 'FL Studio', settings.get('flush_budget', 300))
        self.surface = OscSurface(fl, self.link, settings, self.clock, self.log)

    # ---- FL callbacks -----------------------------------------------------------------------------------------

    def on_init(self):
        d = self.fl.device
        if hasattr(d, 'setHasMeters'):
            d.setHasMeters()                                # FL then calls OnUpdateMeters
        if not d.isAssigned():
            self.hint('SMK-37 Oscuro: set the output port number to the input\'s (MIDI settings)')
        self.link.hello(self.clock())

    def on_deinit(self):
        self.link.bye()

    def on_sysex(self, event):
        now = self.clock()
        m = self.link.rx(list(bytearray(event.sysex)), now)
        if m is None:
            return
        event.handled = True
        cmd = m['cmd']
        try:
            if cmd == P.CONTROL:
                self.surface.control(m)
            elif cmd == P.TEMPO_TAP:
                self.surface.tempo_tap(m['tempo_x100'])
            elif cmd == P.COMMAND:
                self.surface.command(m['id'])
        except Exception as e:  # noqa: BLE001 - one bad event must not stop the script
            self.error('while handling %r' % (m,), e)
        self.render_pass()

    def on_idle(self):
        now = self.clock()
        if now - self.last_idle < IDLE_MS:
            return
        self.last_idle = now
        self.link.tick(now)
        if self.link.state == 'hello' and not self.told and now - self.link.first_hello >= NOT_FOUND_MS:
            self.told = True
            self.hint(self.not_found_text())
        try:
            self.surface.poll(now)
            self.surface.render_position()
        except Exception as e:  # noqa: BLE001 - logged once; FL keeps calling
            self.error('idle', e)
        self.render_pass()

    def on_refresh(self, flags):
        """FL calls this for every change, often many times a second. The 100 ms idle pass renders everything (the
        link sends only what changed), so a change made with the mouse reaches the keyboard within 100 ms; rendering
        here as well would only repeat that work."""

    def on_full_refresh(self):
        if self.link.state == 'up':
            self.link.sent = {}                             # send everything again
        self.render_pass()

    def on_project_load(self, status):
        if status == 100 and self.link.state == 'up':       # 100: the project finished loading
            self.surface.offset = 0
            self.surface.bank = 0
            self.surface.sel_last = None                    # the selection is followed again
            self.link.sent = {}
            self.render_pass()

    def on_meters(self):
        try:
            self.surface.render_meters()
        except Exception as e:  # noqa: BLE001
            self.error('meters', e)
        self.link.flush(self.clock())

    # ---- helpers ----------------------------------------------------------------------------------------------

    def not_found_text(self):
        name = ''
        try:
            name = self.fl.device.getName() or ''
        except Exception:  # noqa: BLE001 - older FL: no getName
            pass
        if 'Oscuro' not in name and any(s.lower() in name.lower() for s in STOCK_NAMES):
            board = 'SMK-37 Pro' if 'pro' in name.lower() else 'SMK-37 Elite'
            return 'SMK-37 Oscuro: this %s runs M-Vave firmware. Install Oscuro or use M-Vave\'s script' % board
        return 'SMK-37 Oscuro: Oscuro firmware not found on this port (use the DAW port)'

    def render_pass(self):
        try:
            self.surface.render()
        except Exception as e:  # noqa: BLE001 - what was queued still goes out
            self.error('render', e)
        self.link.flush(self.clock())

    def error(self, where, e):
        """Print an error once per kind (FL's idle callback would otherwise repeat it ten times a second)."""
        key = '%s %s' % (where.split(' ')[0], type(e).__name__)
        if key not in self.errors:
            self.errors.add(key)
            self.log('SMK-37 Oscuro: %r %s' % (e, where))

    def send(self, m):
        self.fl.device.midiOutSysex(bytes(bytearray(m)))

    def hint(self, text):
        try:
            self.fl.ui.setHintMsg(text)
        except Exception:  # noqa: BLE001
            pass
        self.log(text)

    def log(self, s):
        print(s)                                            # FL's Script output window


script = Script(FL)


def OnInit():
    script.on_init()


def OnDeInit():
    script.on_deinit()


def OnSysEx(event):
    script.on_sysex(event)


def OnIdle():
    script.on_idle()


def OnRefresh(flags):
    script.on_refresh(flags)


def OnDoFullRefresh():
    script.on_full_refresh()


def OnProjectLoad(status):
    script.on_project_load(status)


def OnUpdateMeters():
    script.on_meters()


def OnUpdateBeatIndicator(value):
    script.surface.render_position()
    script.link.flush(script.clock())
