# Pad functions of the FL Studio script (the twin of host/bitwig/SMK37-Oscuro/oscuro_pads.js): what the bottom row of pad
# bank B does in a view when a plain press (no Oct- / Shift) runs a function. The firmware knows nothing about this: a
# pad press arrives as CONTROL, the script lights the pad (PADS) and names it (CELL_NAME 40-55) for the keyboard's Oct-
# hint. The wiring is oscfl_settings.SETTINGS['pad_map'].
#
# A function: label (the pad's name, 10 characters at most), rgb (0..127), run(surface) on a press, lit(surface) true
# while its switch is on (a lit pad is bright, an unlit one dim; None: never lit). Colours follow the manual: green
# play, white stop, red record, amber loop / song, cyan metronome, magenta markers, blue undo / redo.
import oscfl_proto as P

DIM = 0.18
CONTEXTS = ('overview',)
DEFAULTS = {'overview': ['Stop', 'Play', 'Rec', 'Song', 'Loop rec', 'Metro', 'Marker <', 'Marker >']}


class Func(object):
    def __init__(self, label, rgb, run, lit=None):
        self.label, self.rgb, self.run, self.lit = label, rgb, run, lit


def _gt(name, default):
    return lambda s: s.global_transport(name, default)


def _marker_jump(delta):
    def run(s):
        a = getattr(s.fl, 'arrangement', None)
        if a is None:
            s.notify('Markers need a newer FL Studio')
        else:
            a.jumpToMarker(delta, False)
    return run


def _marker_add(s):
    a = getattr(s.fl, 'arrangement', None)
    if a is None:
        s.notify('Markers need a newer FL Studio')
    else:
        a.addAutoTimeMarker(a.currentTime(False), 'Marker')


def _tap(s):
    s.global_transport('FPT_TapTempo', 106)


FUNCS = {
    'Stop': Func('Stop', (100, 100, 100), lambda s: s.fl.transport.stop()),
    'Play': Func('Play', (20, 120, 40), lambda s: s.fl.transport.start(), lambda s: s.fl.transport.isPlaying()),
    'Rec': Func('Rec', (127, 10, 10), lambda s: s.fl.transport.record(), lambda s: s.fl.transport.isRecording()),
    'Song': Func('Song', (127, 80, 0), lambda s: s.fl.transport.setLoopMode(), lambda s: s.song_mode()),
    'Loop rec': Func('Loop rec', (127, 80, 0), _gt('FPT_LoopRecord', 113), lambda s: s.fl.ui.isLoopRecEnabled()),
    'Metro': Func('Metro', (0, 110, 120), _gt('FPT_Metronome', 110), lambda s: s.fl.ui.isMetronomeEnabled()),
    'Countdown': Func('Countdown', (0, 110, 120), _gt('FPT_CountDown', 115), lambda s: s.fl.ui.isPrecountEnabled()),
    'Step edit': Func('Step edit', (40, 127, 40), _gt('FPT_StepEdit', 114), lambda s: s.fl.ui.getStepEditMode()),
    'Marker <': Func('Marker <', (90, 40, 120), _marker_jump(-1)),
    'Marker >': Func('Marker >', (90, 40, 120), _marker_jump(1)),
    'Marker +': Func('Marker +', (120, 30, 110), _marker_add),
    'Undo': Func('Undo', (30, 60, 127), lambda s: s.fl.general.undoUp()),
    'Redo': Func('Redo', (30, 60, 127), lambda s: s.fl.general.undoDown()),
    'Capture': Func('Capture', (127, 50, 20), lambda s: s.capture()),
    'Tap': Func('Tap', (60, 60, 127), _tap),
}


def pad_row(surface, ctx):
    """The 8 functions of a context's bottom row (None = a dark pad), or None when that view keeps its own pads.
    An unknown name is a dark pad, logged once."""
    pm = surface.prefs.get('pad_map')
    if pm is None:
        pm = DEFAULTS
    names = pm.get(ctx) if isinstance(pm, dict) else None
    if not isinstance(names, (list, tuple)):
        return None
    row = []
    for i in range(8):
        n = names[i] if i < len(names) else ''
        f = FUNCS.get(n) if n else None
        if n and f is None and n not in surface.pad_warned:
            surface.pad_warned.add(n)
            surface.log('SMK-37 Oscuro: pad function "%s" in oscfl_settings.py is unknown (ignored)' % n)
        row.append(f)
    return row


def light(surface, f):
    """((r, g, b), anim) of a function's pad."""
    if f is None:
        return ((0, 0, 0), P.SOLID)
    on = bool(f.lit(surface)) if f.lit else False
    k = 1 if on else DIM
    return ((f.rgb[0] * k, f.rgb[1] * k, f.rgb[2] * k), P.SOLID)
