# Oscuro DAW protocol v1 codec for the FL Studio script (docs/DAW_PROTOCOL.md; firmware/core/midi/ks_dawproto.c is the
# reference, host/ableton/SMK37_Oscuro/oscuro_proto.py and host/bitwig/SMK37-Oscuro/oscuro_proto.js its twins: the
# offline tests check that all three build the same bytes). Pure functions, no FL Studio API.
#
# Framing: F0 7D 4B 53 01 <cmd> <payload> F7. u14 = low 7 bits first; str = length + printable ASCII.
#
# FL Studio's embedded Python may come without 'unicodedata'; the fallback table below then strips the common accents
# the same way NFD does (anything else becomes '?', as in the other scripts).
try:
    import unicodedata
except ImportError:  # pragma: no cover - exercised by the tests through _ascii_no_ud
    unicodedata = None

HDR = [0x7D, 0x4B, 0x53, 0x01]
VERSION = 1

# host -> device
HELLO, PING, BYE, CLAIM = 0x01, 0x03, 0x05, 0x10
PAD, PADS, BUTTON_LED = 0x20, 0x21, 0x22
CELL_NAME, CELL_VALUE, TRACK, CELL_MOD = 0x30, 0x31, 0x32, 0x33
TRANSPORT, SCALE, PROJECT, METERS = 0x40, 0x41, 0x42, 0x44
NOTIFY, MODE, SET_ACCENT, HEADER, LIST, LIST_ROW, TABS = 0x50, 0x60, 0x61, 0x62, 0x63, 0x64, 0x65
# device -> host
HELLO_ACK, CONTROL, TEMPO_TAP, SCALE_CHANGED, COMMAND = 0x02, 0x70, 0x71, 0x72, 0x73

# host kinds (HELLO): 0 other, 1 Bitwig, 2 Ableton, 3 Reaper. FL Studio has no id of its own yet (design note:
# a protocol change would add 4), so it says 'other' with the name "FL Studio".
KIND_OTHER, KIND_BITWIG, KIND_ABLETON = 0, 1, 2
KIND_FL = KIND_OTHER

# resource classes
RES_PAD, RES_KNOB, RES_FADER, RES_BUTTON, RES_MOD = 0, 1, 2, 3, 4
MOD_SHIFT, MOD_OCT = 0x01, 0x02

# cells
CELL_KNOB, CELL_FADER, CELL_PAD = 0, 16, 24
CELL_HAS_COLOR, CELL_BAR_UNI, CELL_BAR_BI, CELL_DISABLED, CELL_SHOW_MOD = 0x01, 0x02, 0x04, 0x08, 0x10

# TRACK flags
TRK_EXISTS, TRK_SELECTED, TRK_MUTE, TRK_SOLO, TRK_ARMED = 1, 2, 4, 8, 16
TRK_GROUP, TRK_IN_GROUP = 32, 64

# TRANSPORT flags
TR_PLAYING, TR_RECORDING, TR_LOOP, TR_PUNCH_IN, TR_PUNCH_OUT = 1, 2, 4, 8, 16
TR_METRONOME, TR_AUTOMATION, TR_OVERDUB, TR_COUNT_IN = 32, 64, 128, 256

# MODE ids
MODE_SESSION, MODE_DEVICE, MODE_MIXER, MODE_OVERVIEW, MODE_BROWSER = 1, 3, 4, 6, 7

# pad animation (bits 0-1), period (bits 2-3)
SOLID, PULSE, BLINK = 0, 1, 2

# LIST_ROW flags
ROW_COLOR, ROW_SELECTED = 1, 2

# HELLO_ACK caps
CAP_RGB_PADS = 1 << 0
CAP_DISPLAY = 1 << 1
CAP_SCALE_SYNC = 1 << 3
CAP_NOTIFY = 1 << 4
CAP_SHIFT_PAD = 1 << 6
CAP_ACCENT = 1 << 7
CAP_HEADER = 1 << 8
CAP_VIEWS = 1 << 9
CAP_CELL_V1 = 1 << 10
CAP_METERS = 1 << 11
CAP_LISTS = 1 << 12
CAP_PROJECT = 1 << 13
CAP_OCT_MOD = 1 << 14
CAP_TABS = 1 << 15


class BTN(object):
    """ks_button_t order (firmware/core/control/ks_event.h)."""
    KNOB_BANK, FADER_BANK, LEFT, RIGHT, OCT_DOWN, OCT_UP = 0, 1, 2, 3, 4, 5
    ARP, NOTE_REPEAT, SCALE, CHORD, GLOBE, BT = 6, 7, 8, 9, 10, 11
    PATCH, PARA, FX, SEQ, SEQ_PLAY, SEQ_REC = 12, 13, 14, 15, 16, 17


# COMMAND ids (device -> host)
CMD_UNDO, CMD_REDO, CMD_DUPLICATE, CMD_QUANTIZE, CMD_METRONOME = 1, 2, 3, 4, 5
CMD_LOOP, CMD_PUNCH_IN, CMD_PUNCH_OUT, CMD_NEW_CLIP, CMD_CAPTURE = 6, 7, 8, 9, 10

NAME_LEN, NOTIFY_LEN = 24, 48


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def _round(v):
    # Math.round of the JS twin (halves go up), so both scripts send the same bytes
    import math
    return int(math.floor(v + 0.5))


def u7(v):
    return clamp(_round(v), 0, 127) & 0x7F


def u14(v):
    v = clamp(_round(v), 0, 16383)
    return [v & 0x7F, (v >> 7) & 0x7F]


def rgb(c):
    c = c or (0, 0, 0)
    return [u7(c[0]), u7(c[1]), u7(c[2])]


_SUBST = {0x2013: 0x2D, 0x2014: 0x2D, 0x2018: 0x27, 0x2019: 0x27, 0x00B0: 0x2A}


_ACCENTS = {}
for _base, _chars in (('A', u'\u00c0\u00c1\u00c2\u00c3\u00c4\u00c5'), ('a', u'\u00e0\u00e1\u00e2\u00e3\u00e4\u00e5'),
                      ('C', u'\u00c7'), ('c', u'\u00e7'), ('E', u'\u00c8\u00c9\u00ca\u00cb'), ('e', u'\u00e8\u00e9\u00ea\u00eb'),
                      ('I', u'\u00cc\u00cd\u00ce\u00cf'), ('i', u'\u00ec\u00ed\u00ee\u00ef'), ('N', u'\u00d1'), ('n', u'\u00f1'),
                      ('O', u'\u00d2\u00d3\u00d4\u00d5\u00d6'), ('o', u'\u00f2\u00f3\u00f4\u00f5\u00f6'),
                      ('U', u'\u00d9\u00da\u00db\u00dc'), ('u', u'\u00f9\u00fa\u00fb\u00fc'), ('Y', u'\u00dd'),
                      ('y', u'\u00fd\u00ff')):
    for _ch in _chars:
        _ACCENTS[_ch] = _base


def _strip_marks(s, ud):
    if ud is not None:
        return u''.join(ch for ch in ud.normalize('NFD', s) if not (0x300 <= ord(ch) <= 0x36F))
    return u''.join(_ACCENTS.get(ch, ch) for ch in s if not (0x300 <= ord(ch) <= 0x36F))


def ascii_bytes(s, limit, ud=None):
    """Printable ASCII only: common accents lose their marks, anything else becomes '?' (the device does the same).
    'ud' is for the tests: False forces the fallback table used when FL's Python has no unicodedata."""
    if s is None:
        s = ''
    if not isinstance(s, type(u'')):
        try:
            s = s.decode('utf-8')
        except (AttributeError, UnicodeDecodeError):
            s = u'%s' % (s,)
    s = _strip_marks(s, None if ud is False else unicodedata)
    out = []
    for ch in s:
        if len(out) >= limit:
            break
        c = _SUBST.get(ord(ch), ord(ch))
        out.append(c if 0x20 <= c <= 0x7E else 0x3F)
    return out


def string(s, limit=NAME_LEN):
    b = ascii_bytes(s, limit)
    return [len(b)] + b


def msg(cmd, payload=None):
    """A complete message as a list of bytes (with F0 / F7)."""
    return [0xF0] + HDR + [cmd] + list(payload or []) + [0xF7]


def to_hex(b):
    return ''.join('%02X' % x for x in b)


# ---- host -> device -------------------------------------------------------------------------------------------

def hello(kind, name):
    return msg(HELLO, [VERSION, kind] + string(name))


def ping():
    return msg(PING)


def bye():
    return msg(BYE)


def claim(cls, mask):
    return msg(CLAIM, [cls] + [(mask >> (7 * i)) & 0x7F for i in range(5)])


def pads(first, lights):
    """lights: [(rgb, anim)]; at most 16 per message."""
    p = [first, len(lights)]
    for c, anim in lights:
        p += rgb(c) + [anim & 0x7F]
    return msg(PADS, p)


def button_led(button, state):
    return msg(BUTTON_LED, [button, state & 3])


def cell_name(target, flags, color, name):
    return msg(CELL_NAME, [target, flags & 0x7F] + rgb(color) + string(name))


def cell_value(target, value14, text):
    return msg(CELL_VALUE, [target] + u14(value14) + string(text))


def cell_mod(target, value14):
    return msg(CELL_MOD, [target] + u14(value14))


def track(slot, flags, color, name):
    return msg(TRACK, [slot, flags & 0x7F] + rgb(color) + string(name))


def transport(flags, tempo_x100):
    t = clamp(_round(tempo_x100), 0, 2097151)
    return msg(TRANSPORT, u14(flags) + [t & 0x7F, (t >> 7) & 0x7F, (t >> 14) & 0x7F])


def scale(flags, root, mask, name):
    return msg(SCALE, [flags & 0x7F, root % 12] + u14(mask & 0xFFF) + string(name))


def project(bar, beat, sixteenth, num, den, name):
    return msg(PROJECT, u14(bar) + [u7(beat), u7(sixteenth), u7(num), u7(den)] + string(name))


def meters(first, levels):
    return msg(METERS, [first, len(levels)] + [u7(v) for v in levels])


def notify(priority, timeout_100ms, text):
    return msg(NOTIFY, [priority, u7(timeout_100ms)] + string(text, NOTIFY_LEN))


def mode(m, title):
    return msg(MODE, [m] + string(title))


def accent(color):
    return msg(SET_ACCENT, rgb(color))


def header(left, right):
    return msg(HEADER, string(left) + string(right))


def tabs(index, count, prev, cur, nxt):
    """The Device view's page line (v1, caps bit 15): the pages either side of the current one, '' where there is none;
    index is 0-based of count. count 0 clears the line."""
    return msg(TABS, [u7(index), u7(count)] + string(prev) + string(cur) + string(nxt))


def list_(list_id, total, selected, title):
    return msg(LIST, [list_id] + u14(total) + u14(selected) + string(title))


def list_row(row, index, flags, color, text):
    return msg(LIST_ROW, [row] + u14(index) + [flags & 0x7F] + rgb(color) + string(text))


# ---- device -> host -------------------------------------------------------------------------------------------

def decode(data):
    """A SysEx from the device (with or without F0 / F7) as a dict, or None if it is not ours."""
    b = list(data)
    if b and b[0] == 0xF0:
        b = b[1:]
    if b and b[-1] == 0xF7:
        b = b[:-1]
    if len(b) < 5 or b[:4] != HDR:
        return None
    cmd, p = b[4], b[5:]

    def w(i):
        return p[i] | (p[i + 1] << 7)

    if cmd == HELLO_ACK:
        if len(p) < 15:
            return None
        caps = w(4) + (w(15) << 14 if len(p) >= 17 else 0)
        return {'cmd': cmd, 'ver': p[0], 'fw': (p[1], p[2], p[3]), 'caps': caps, 'pads': p[6], 'pad_banks': p[7],
                'knobs': p[8], 'knob_banks': p[9], 'faders': p[10], 'fader_banks': p[11],
                'width': p[12] * 8, 'height': p[13] * 8, 'shift_pad': p[14]}
    if cmd == CONTROL:
        if len(p) < 6:
            return None
        raw = w(2)
        value = (raw - 16384 if raw >= 8192 else raw) if p[0] == RES_KNOB else raw
        return {'cmd': cmd, 'cls': p[0], 'index': p[1], 'value': value, 'extra': p[4], 'mods': p[5]}
    if cmd == TEMPO_TAP:
        if len(p) < 3:
            return None
        return {'cmd': cmd, 'tempo_x100': p[0] | (p[1] << 7) | (p[2] << 14)}
    if cmd == SCALE_CHANGED:
        if len(p) < 5:
            return None
        return {'cmd': cmd, 'flags': p[0], 'root': p[1], 'mask': w(2), 'scale_id': p[4]}
    if cmd == COMMAND:
        if len(p) < 1:
            return None
        return {'cmd': cmd, 'id': p[0]}
    return {'cmd': cmd}
