Oscuro Retrowave 0.89

oscuro-installer.html   open it in Chrome or Edge, connect the keyboard, follow the prompts (works from this folder, no website needed)
oscuro-0.89.2-retrowave-app.bin   the app file: choose it in the installer
oscuro-0.89.2-retrowave.fwsc   the complete image: Install the complete image needs no M-Vave file
banks/                  the showcase banks: .syx are Virus TI singles, .oscbank are Oscuro banks with their own FX rack

Everything is checked before it is written, and M-Vave's own firmware can be put back from the same installer.
