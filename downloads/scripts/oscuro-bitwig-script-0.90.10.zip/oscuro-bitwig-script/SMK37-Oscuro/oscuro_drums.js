// Drum pads and the 16-step sequencer on pad bank B (docs/design/2026-11-25-daw-device-integration.md, items 2-3).
//
// Active in the Device view when the selected device is a Drum Machine, or (when the selected device has no switches
// for device pads) when the track's first instrument is one. Two pages:
//   pads   top row = 8 drum pads of the window (from C1), lit in their colour, the lane bright; a tap selects the pad,
//          a hold (half a second) opens its steps. Bottom row = mute of those pads (solo when the track sub-mode is
//          solo). Oct- + Left / Right moves the window by 8; plain Left / Right stay the remote pages.
//   steps  both rows = 16 sixteenths of the lane in the launcher clip shown in the editor (a 1-bar clip is made in the
//          track's slot when there is none). Press an empty step: a note; press a note and let go: removed, unless a
//          knob turned while it was held: K1 velocity, K2 length, K3 chance, K4 repeats, K5 occurrence, K6 recurrence,
//          K7 timbre, K8 pressure. Left / Right: the 16-step page; Oct- + Left / Right: the previous / next drum pad;
//          Shift pad + Left: back to the pads.
//
// The same steps page also serves a key lane of any instrument track (source 'keys'): Shift pad + Right in the Device
// view opens it for the key in this.key (C3 at first, kept for the session); Oct- + Left / Right moves the key by a
// semitone; Shift pad + Left closes it. OscSurface.padMode says 'keys' while it is open.
//
// bw.drumDevice / bw.drumPads (8) / bw.stepClip (128 x 1 grid, never scrolled in time) are made in SMK37-Oscuro.control.js.
// The grid is as wide as a clip can be, so a step's x is its absolute position (step page * 16 + i), the same as the
// numbers playingStep() reports; only the key is scrolled (the lane).

var OSC_STEP = 0.25, OSC_STEPS = 16, OSC_MAX_STEPS = 128, OSC_DRUM_HOLD_MS = 500, OSC_FIRST_NOTE = 36, OSC_FIRST_KEY = 60;
var OSC_PENDING_MS = 2000;
// NoteOccurrence in the order K5 steps through it (the API's constant names; the first is "always", i.e. off)
var OSC_OCCURRENCES = ['ALWAYS', 'FIRST', 'NOT_FIRST', 'PREV', 'NOT_PREV', 'PREV_CHANNEL', 'NOT_PREV_CHANNEL', 'PREV_KEY',
                       'NOT_PREV_KEY', 'FILL', 'NOT_FILL'];
var OSC_OCCURRENCE_TEXT = ['Always', 'First', 'Not first', 'Prev', 'Not prev', 'Prev chan', 'No prev chan', 'Prev key',
                           'Not prev key', 'Fill', 'Not fill'];
var OSC_NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];

function oscNoteName(n) { return OSC_NOTE_NAMES[n % 12] + (Math.floor(n / 12) - 2); }

function OscDrums(surface) {
    this.s = surface;
    this.bw = surface.bw;
    this.source = 'drum';       // 'drum' (a drum pad's lane) or 'keys' (a key of the selected track)
    this.page = 'pads';
    this.base = OSC_FIRST_NOTE;
    this.lane = OSC_FIRST_NOTE;
    this.key = OSC_FIRST_KEY;   // the key lane's note, kept between visits
    this.keyTrack = -1;         // position of the track the key lane was opened on
    this.stepPage = 0;
    this.hold = null;           // a top pad held on the pads page: {idx, t, opened}
    this.held = null;           // a step held: {idx, x, had, edited}
    this.pending = null;        // a step to set once the new clip exists: {x, t}
    this.steps = [];            // x -> true where a note starts (from the clip's note step observer)
    this.scrolled = '';
}

// Is a drum device in play? (the precedence over device pads is OscSurface.padMode's)
OscDrums.prototype.selected = function () { return this.bw.cursorDevice.hasDrumPads().get(); };
OscDrums.prototype.onTrack = function () { return this.bw.drumDevice.exists().get() && this.bw.drumDevice.hasDrumPads().get(); };

OscDrums.prototype.reset = function () { this.page = 'pads'; this.hold = null; this.held = null; };

// ---- key lanes ---------------------------------------------------------------------------------------------------

OscDrums.prototype.keysOpen = function () { return this.source === 'keys'; };

// The steps page for a key of the selected track (position = the cursor track's, to close when the track changes).
OscDrums.prototype.openKeys = function (trackPos) {
    this.source = 'keys';
    this.keyTrack = trackPos;
    this.page = 'steps';
    this.stepPage = 0;
    this.hold = null; this.held = null; this.pending = null;
    this.scrolled = '';
};

OscDrums.prototype.closeKeys = function () {
    this.source = 'drum';
    this.reset();
    this.pending = null;
    this.scrolled = '';
};

// The key (MIDI note) the steps are about.
OscDrums.prototype.laneNow = function () { return this.source === 'keys' ? this.key : this.lane; };

// Keep Bitwig's windows where we look: the pad bank at the base, the clip grid at the lane and step page.
OscDrums.prototype.sync = function () {
    var bw = this.bw;
    if (this.source === 'drum' && bw.drumPads.scrollPosition().get() !== this.base) bw.drumPads.scrollPosition().set(this.base);
    var key = String(this.laneNow());
    if (key !== this.scrolled) {
        this.scrolled = key;
        this.steps = [];
        bw.stepClip.scrollToKey(this.laneNow());             // the time axis is never scrolled (see the top)
    }
};

OscDrums.prototype.onStep = function (step) {            // NoteStep from the observer; x is absolute, y is always 0 (one key)
    this.steps[step.x()] = String(step.state()) === 'NoteOn';
};

OscDrums.prototype.totalSteps = function () {
    var c = this.bw.stepClip;
    return c.exists().get() ? Math.max(1, Math.min(OSC_MAX_STEPS, Math.round(c.getLoopLength().get() / OSC_STEP))) : OSC_STEPS;
};

OscDrums.prototype.press = function (idx) {
    var bw = this.bw, i = idx - 16;
    if (this.page === 'pads') {
        var n = this.base + (i & 7);
        if (n > 127) return;
        var pad = bw.drumPads.getItemAt(i & 7);
        if (i < 8) {
            pad.selectInEditor();
            this.lane = n;
            this.hold = { idx: idx, t: this.s.clock(), opened: false };
        } else if (this.s.sub === 'solo') {
            pad.solo().toggle();
        } else {
            pad.mute().toggle();
        }
        return;
    }
    var x = this.stepPage * OSC_STEPS + i;
    if (!bw.stepClip.exists().get()) {                     // no clip in the editor: make a 1-bar one, set the step after
        var slot = bw.cursorTrack.clipLauncherSlotBank().getItemAt(0);
        slot.createEmptyClip(4);
        slot.select();
        slot.showInEditor();
        this.pending = { x: x, t: this.s.clock() };
        return;
    }
    if (x >= this.totalSteps()) return;
    var had = !!this.steps[x];
    if (!had) bw.stepClip.setStep(x, 0, 100, OSC_STEP);
    this.held = { idx: idx, x: x, had: had, edited: false };
};

OscDrums.prototype.release = function (idx) {
    if (this.hold && this.hold.idx === idx) { this.hold = null; return true; }
    var h = this.held;
    if (h && h.idx === idx) {
        this.held = null;
        if (h.had && !h.edited) this.bw.stepClip.clearStep(h.x, 0);
        return true;
    }
    return false;
};

OscDrums.prototype.poll = function (now) {
    var h = this.hold;
    if (h && !h.opened && now - h.t >= OSC_DRUM_HOLD_MS) {
        h.opened = true;
        this.page = 'steps';
        this.stepPage = 0;
    }
    var p = this.pending;
    if (p && this.bw.stepClip.exists().get()) {
        this.bw.stepClip.setStep(p.x, 0, 100, OSC_STEP);
        this.pending = null;
    } else if (p && now - p.t >= OSC_PENDING_MS) {            // the clip never showed up (no slot selected?): give up
        this.pending = null;
        this.s.notify(30, 'No clip to write to: select a slot');
    }
};

// Left / Right on drum pages; false leaves them to the remote pages.
OscDrums.prototype.nav = function (dir, oct) {
    if (this.page === 'pads') {
        if (!oct) return false;
        this.base = Math.max(0, Math.min(120, this.base + 8 * dir));
        return true;
    }
    if (this.s.shift && dir < 0) {
        if (this.source === 'keys') this.closeKeys(); else this.reset();
        return true;
    }
    if (oct && this.source === 'keys') {
        this.key = Math.max(0, Math.min(127, this.key + dir));
        this.held = null;
        return true;
    }
    if (oct) {
        this.lane = Math.max(0, Math.min(127, this.lane + dir));
        if (this.lane < this.base || this.lane >= this.base + 8) this.base = Math.max(0, Math.min(120, this.lane - this.lane % 8));
        this.bw.drumPads.scrollPosition().set(this.base);
        this.bw.drumPads.getItemAt(this.lane - this.base).selectInEditor();
        return true;
    }
    var pages = Math.max(1, Math.ceil(this.totalSteps() / OSC_STEPS));
    this.stepPage = Math.max(0, Math.min(pages - 1, this.stepPage + dir));
    return true;
};

// The NoteOccurrence constant for a name (the API's enum classes are globals in the script, like CursorDeviceFollowMode).
function oscOccurrence(name) { return NoteOccurrence[name]; }

function oscClamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

// Where K5 stands: the index into OSC_OCCURRENCES (0 = off), and K6's: 0 = off, else the cycles (2..8).
function oscOccIndex(n) { return n.isOccurrenceEnabled() ? Math.max(0, OSC_OCCURRENCES.indexOf(String(n.occurrence()))) : 0; }
function oscRecurrence(n) { return n.isRecurrenceEnabled() && n.recurrenceLength() >= 2 ? n.recurrenceLength() : 0; }

// Is this step a note Bitwig has reported? A step just set from here is not, for a moment.
OscDrums.prototype.noteOn = function (x) { return String(this.bw.stepClip.getStep(0, x, 0).state()) === 'NoteOn'; };

// K1-K8 edit the held step; false when no step is held (the knobs stay the device's). A turn on a step that is not a
// reported note yet is swallowed (nothing to edit, and it must not count as an edit: the release would keep a note
// that was only just set).
OscDrums.prototype.knob = function (k, d, fine) {
    var h = this.held;
    if (this.page !== 'steps' || !h) return false;
    if (!this.noteOn(h.x)) return true;
    var n = this.bw.stepClip.getStep(0, h.x, 0), dir = d > 0 ? 1 : -1;
    switch (k) {
    case 0: n.setVelocity(oscClamp(n.velocity() + d * (fine ? 1 : 2) / 127, 1 / 127, 1)); break;
    case 1: n.setDuration(Math.max(OSC_STEP / 4, n.duration() + d * (fine ? OSC_STEP / 4 : OSC_STEP))); break;
    case 2: n.setIsChanceEnabled(true); n.setChance(oscClamp(n.chance() + d * (fine ? 0.01 : 0.05), 0, 1)); break;
    case 3: n.setIsRepeatEnabled(true); n.setRepeatCount(oscClamp(n.repeatCount() + (d > 0 ? 1 : -1), 0, 64)); break;
    case 4: {                                               // one entry of the list per detent; the first is "always" = off
        var o = oscClamp(oscOccIndex(n) + dir, 0, OSC_OCCURRENCES.length - 1);
        n.setOccurrence(oscOccurrence(OSC_OCCURRENCES[o]));
        n.setIsOccurrenceEnabled(o > 0);
        break;
    }
    case 5: {                                               // off, 2..8 cycles; plays on the first cycle only
        var r = oscRecurrence(n), to = dir > 0 ? (r === 0 ? 2 : Math.min(8, r + 1)) : (r <= 2 ? 0 : r - 1);
        if (to) n.setRecurrence(to, 1);
        n.setIsRecurrenceEnabled(to > 0);
        break;
    }
    case 6: n.setTimbre(oscClamp(n.timbre() + d * (fine ? 0.01 : 0.05), -1, 1)); break;
    case 7: n.setPressure(oscClamp(n.pressure() + d * (fine ? 0.01 : 0.05), 0, 1)); break;
    }
    h.edited = true;
    return true;
};

OscDrums.prototype.lights = function () {
    var bw = this.bw, out = [], i, p;
    if (this.page === 'pads') {
        for (i = 0; i < 8; i++) {
            p = bw.drumPads.getItemAt(i);
            if (this.base + i > 127) out.push({ rgb: [0, 0, 0], anim: OSC.SOLID });
            else if (p.exists().get()) out.push({ rgb: oscScale(oscRgb7(p.color()), this.base + i === this.lane ? 1 : 0.3), anim: OSC.SOLID });
            else out.push({ rgb: this.base + i === this.lane ? [30, 30, 30] : [6, 6, 6], anim: OSC.SOLID });
        }
        var solo = this.s.sub === 'solo';
        for (i = 0; i < 8; i++) {
            p = bw.drumPads.getItemAt(i);
            if (!p.exists().get()) out.push({ rgb: [0, 0, 0], anim: OSC.SOLID });
            else if (solo) out.push({ rgb: oscScale(OSC_SUB_RGB.solo, p.solo().get() ? 1 : 0.12), anim: OSC.SOLID });
            else out.push({ rgb: oscScale(OSC_SUB_RGB.mute, p.mute().get() ? 1 : 0.12), anim: OSC.SOLID });
        }
        return out;
    }
    var li = this.lane - this.base, col = this.source === 'keys' ? oscRgb7(bw.cursorTrack.color())
        : li >= 0 && li < 8 && bw.drumPads.getItemAt(li).exists().get() ? oscRgb7(bw.drumPads.getItemAt(li).color()) : OSC_ACCENT;
    var total = this.totalSteps(), first = this.stepPage * OSC_STEPS, playing = bw.stepClip.playingStep().get();
    for (i = 0; i < OSC_STEPS; i++) {
        if (first + i >= total) out.push({ rgb: [0, 0, 0], anim: OSC.SOLID });
        else if (first + i === playing) out.push({ rgb: [100, 100, 100], anim: OSC.SOLID });
        else if (this.steps[first + i]) out.push({ rgb: col, anim: OSC.SOLID });
        else out.push({ rgb: [10, 10, 10], anim: OSC.SOLID });
    }
    return out;
};

OscDrums.prototype.header = function (pageText) {
    var bw = this.bw;
    if (this.page === 'pads')
        return OscEnc.header(bw.drumDevice.name().get(), oscNoteName(this.base) + '-' + oscNoteName(this.base + 7) + ' | ' + pageText);
    var li = this.lane - this.base, name = this.source === 'drum' && li >= 0 && li < 8 ? bw.drumPads.getItemAt(li).name().get() : '';
    var total = this.totalSteps(), first = this.stepPage * OSC_STEPS;
    return OscEnc.header(name || oscNoteName(this.laneNow()), 'Steps ' + (first + 1) + '-' + Math.min(first + OSC_STEPS, total) + '/' + total);
};

// [[name, 0..1, text]] for K1-K8 while a step is held, else null.
OscDrums.prototype.cells = function () {
    var h = this.held;
    if (this.page !== 'steps' || !h) return null;
    if (!this.noteOn(h.x))                                  // set a moment ago, not reported yet: the names, no values
        return [['Velocity', 0, ''], ['Length', 0, ''], ['Chance', 0, ''], ['Repeats', 0, ''],
                ['Occurrence', 0, ''], ['Recurrence', 0, ''], ['Timbre', 0, ''], ['Pressure', 0, '']];
    var n = this.bw.stepClip.getStep(0, h.x, 0), o = oscOccIndex(n), r = oscRecurrence(n);
    return [['Velocity', n.velocity(), String(Math.round(n.velocity() * 127))],
            ['Length', Math.min(1, n.duration() / (OSC_STEPS * OSC_STEP)), (n.duration() / OSC_STEP).toFixed(2) + ' st'],
            ['Chance', n.chance(), Math.round(n.chance() * 100) + ' %'],
            ['Repeats', Math.min(1, n.repeatCount() / 16), String(n.repeatCount())],
            ['Occurrence', o / (OSC_OCCURRENCES.length - 1), OSC_OCCURRENCE_TEXT[o]],
            ['Recurrence', r / 8, r ? '1st of ' + r : 'Off'],
            ['Timbre', (n.timbre() + 1) / 2, (n.timbre() >= 0 ? '+' : '') + n.timbre().toFixed(2)],
            ['Pressure', n.pressure(), Math.round(n.pressure() * 100) + ' %']];
};

if (typeof module !== 'undefined')
    module.exports = { OscDrums: OscDrums };
