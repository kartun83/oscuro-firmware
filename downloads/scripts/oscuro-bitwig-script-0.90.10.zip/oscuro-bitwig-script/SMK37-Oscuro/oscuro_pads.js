// Pad functions (SMK-37 Oscuro, Bitwig): what the pads of bank B do per view. The firmware knows nothing about this: a
// pad press arrives as CONTROL, the script lights the pad (PADS) and names it (CELL_NAME, target 24 + pad), and the
// keyboard shows the names while Oct- is held (Settings > Display > Hints). Edit oscuro_pads.config.js to change the
// wiring; this file holds the functions it can name.
//
// A function: label (the pad's name on the keyboard, 10 characters at most), rgb (0..127), run(bw, surface) on a press,
// lit(bw) true while its switch is on (a lit pad is bright, an unlit one dim). Colours follow the manual: green play,
// white stop, red record, amber loop, cyan metronome, magenta cues, violet navigation.
var OSC_PAD_FUNCS = {
    'Stop': { label: 'Stop', rgb: [100, 100, 100], run: function (bw) { bw.transport.stop(); }, lit: function () { return false; } },
    'Play': { label: 'Play', rgb: [20, 120, 40], run: function (bw) { bw.transport.play(); }, lit: function (bw) { return bw.transport.isPlaying().get(); } },
    'Rec': { label: 'Rec', rgb: [127, 10, 10], run: function (bw) { bw.transport.record(); }, lit: function (bw) { return bw.transport.isArrangerRecordEnabled().get(); } },
    'Loop': { label: 'Loop', rgb: [127, 80, 0], run: function (bw) { bw.transport.isArrangerLoopEnabled().toggle(); }, lit: function (bw) { return bw.transport.isArrangerLoopEnabled().get(); } },
    'Metro': { label: 'Metro', rgb: [0, 110, 120], run: function (bw) { bw.transport.isMetronomeEnabled().toggle(); }, lit: function (bw) { return bw.transport.isMetronomeEnabled().get(); } },
    'Punch in': { label: 'Punch in', rgb: [127, 80, 0], run: function (bw) { bw.transport.isPunchInEnabled().toggle(); }, lit: function (bw) { return bw.transport.isPunchInEnabled().get(); } },
    'Punch out': { label: 'Punch out', rgb: [127, 80, 0], run: function (bw) { bw.transport.isPunchOutEnabled().toggle(); }, lit: function (bw) { return bw.transport.isPunchOutEnabled().get(); } },
    'Overdub': { label: 'Overdub', rgb: [127, 10, 10], run: function (bw) { bw.transport.isArrangerOverdubEnabled().toggle(); }, lit: function (bw) { return bw.transport.isArrangerOverdubEnabled().get(); } },
    'Tap': { label: 'Tap', rgb: [60, 60, 127], run: function (bw) { bw.transport.tapTempo(); }, lit: function () { return false; } },
    'Cue <': { label: 'Cue <', rgb: [90, 40, 120], run: function (bw) { bw.transport.jumpToPreviousCueMarker(); }, lit: function () { return false; } },
    'Cue >': { label: 'Cue >', rgb: [90, 40, 120], run: function (bw) { bw.transport.jumpToNextCueMarker(); }, lit: function () { return false; } },
    'Cue +': { label: 'Cue +', rgb: [120, 30, 110], run: function (bw, s) {
        if (typeof bw.transport.addCueMarkerAtPlaybackPosition === 'function') bw.transport.addCueMarkerAtPlaybackPosition();
        else s.notify(3, 'This Bitwig cannot add a cue marker from a script');
    }, lit: function () { return false; } },
    'Undo': { label: 'Undo', rgb: [30, 60, 127], run: function (bw) { bw.application.undo(); }, lit: function () { return false; } },
    'Redo': { label: 'Redo', rgb: [30, 60, 127], run: function (bw) { bw.application.redo(); }, lit: function () { return false; } }
};

// The names a context's row 2 uses when oscuro_pads.config.js says nothing.
var OSC_PAD_DEFAULTS = { overview: ['Stop', 'Play', 'Rec', 'Loop', 'Metro', 'Cue <', 'Cue >', 'Cue +'] };

// The 8 functions of a context's bottom row, or null (that view keeps its own pads). An unknown name is a dark pad,
// reported once in the script console.
var oscPadWarned = {};
function oscPadRow(ctx) {
    var map = (typeof OSC_PAD_MAP !== 'undefined' && OSC_PAD_MAP && OSC_PAD_MAP[ctx]) || OSC_PAD_DEFAULTS[ctx];
    if (!map || map.length === undefined) return null;
    var row = [];
    for (var i = 0; i < 8; i++) {
        var f = map[i] && OSC_PAD_FUNCS[map[i]];
        if (map[i] && !f && !oscPadWarned[map[i]]) {
            oscPadWarned[map[i]] = true;
            host.errorln('SMK-37 Oscuro: pad function "' + map[i] + '" in oscuro_pads.config.js is unknown (ignored)');
        }
        row.push(f || null);
    }
    return row;
}
