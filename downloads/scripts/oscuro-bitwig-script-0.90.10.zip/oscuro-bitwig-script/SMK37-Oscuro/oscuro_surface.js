// The SMK-37 under Oscuro firmware as a Bitwig surface (docs/design/2026-11-25-daw-v1-bitwig.md).
//
// Views (SEQ tap cycles, SEQ hold opens the browser):
//   Device    K1-K8 the cursor device's remote page, K9-K16 (Knob Bank B) the track's remote page;
//             Left/Right page, Oct- + Left/Right previous/next device.
//   Mixer     8 track strips; K1-K8 pan, K9-K16 send 1; Left/Right move the 4-fader window (then the bank).
//   Overview  tempo, position, switches; K1-K8 project remotes, K9-K16 tempo / shuffle / click / loop / position / master.
//   Browser   K1 results, K2 category, K3 creator, K4 file type; Right confirm, Left cancel.
// Always: faders 1-4 = the window's 4 volumes (soft takeover), Fader Bank B = selected track volume / pan / send 1 / send 2;
// pad bank B row 1 selects tracks, row 2 = mute / solo / arm / stop / launch (Oct- or Shift + row-2 pad 1-5 picks);
// in the Device view, when the device has two-state parameters on its page or the next, the pads toggle those instead
// (device pads: row 1 this page, row 2 the next, lit in the accent);
// SEQ PLAY play/stop (Oct-: stop and back to the start), SEQ REC record (Oct-: launcher overdub), Oct- + SEQ metronome,
// Oct- + K8 tempo. The firmware keeps Globe, PATCH (Harmony), ARP, SCALE, CHORD, Note Repeat, octave and bank buttons.
//
// 'bw' holds the Bitwig objects (made in SMK37-Oscuro.control.js); 'link' is an OscLink; 'clock' returns ms.

var OSC_VIEWS = [OSC.MODE_DEVICE, OSC.MODE_MIXER, OSC.MODE_OVERVIEW];
var OSC_SUBS = ['mute', 'solo', 'arm', 'stop', 'launch'];
var OSC_SUB_RGB = { mute: [127, 100, 0], solo: [20, 70, 127], arm: [127, 10, 10], stop: [110, 110, 110], launch: [20, 127, 40] };
var OSC_ACCENT = [127, 72, 0];                  // Bitwig orange
var OSC_TOUCH_MS = 500;                         // a knob is "touched" until this long without movement
var OSC_SEQ_HOLD_MS = 500;

function OscSurface(bw, link, prefs, clock) {
    this.bw = bw;
    this.link = link;
    this.prefs = prefs;          // { seqViews, showMod, softTakeover, accent, fine }
    this.clock = clock;
    this.view = OSC.MODE_DEVICE;
    this.prevView = OSC.MODE_DEVICE;
    this.browseIdx = null; this.browseJump = -1; this.browseDir = 0;   // the Browser's cursor: counted position, where the window was put, last direction
    this.sub = 'mute';
    this.shift = false;          // the Shift pad is down (CONTROL class 4)
    this.window = 0;             // first strip of the fader window: 0 or 4
    this.scrollAsked = -1; this.cursorAbs = -1;   // followCursor: the position the bank was asked to show, the selected track last seen
    this.seqDown = 0;            // when SEQ went down (0 = up)
    this.seqOct = false;
    this.seqUsed = false;
    this.touch = {};             // key -> {param, until}
    this.fader = [];             // physical fader 0..7 -> {pos, picked}
    for (var i = 0; i < 8; i++) this.fader.push({ pos: -1, picked: false });
    this.meter = [0, 0, 0, 0, 0, 0, 0, 0];
    this.lastPos = '';
    this.pmodeLast = null;       // the pad mode shown last pass (to tell the player once when it changes)
    this.drums = new OscDrums(this);
    this.fast = [];              // [{k, until}] cells sent at once after a knob turn (the rest waits for the 100 ms timer)
    var self = this;
    link.onSession = function () { self.start(); };
}

// ---- session ---------------------------------------------------------------------------------------------------

OscSurface.prototype.start = function () {
    var L = this.link, B = OSC.BTN;
    var buttons = (1 << B.LEFT) | (1 << B.RIGHT) | (1 << B.SEQ_PLAY) | (1 << B.SEQ_REC) | (this.prefs.seqViews ? (1 << B.SEQ) : 0);
    L.raw(OscEnc.claim(OSC.RES_KNOB, 0xFFFF));
    L.raw(OscEnc.claim(OSC.RES_FADER, 0xFF));
    L.raw(OscEnc.claim(OSC.RES_PAD, 0xFFFF0000));           // pad bank B; bank A stays notes / Harmony
    L.raw(OscEnc.claim(OSC.RES_BUTTON, buttons));
    L.raw(OscEnc.scale(0, 0, 0, ''));                       // Bitwig has no project scale: the device sends its own
    if (this.prefs.accent === 'off' && L.has(OSC.CAP_ACCENT))
        L.raw(OscEnc.accent([0, 0, 0]));                    // back to the player's own accent
    for (var i = 0; i < 8; i++) this.fader[i].picked = false;
    this.render();                                          // the timer sends it, a budget at a time
};

OscSurface.prototype.views = function () { return this.link.has(OSC.CAP_VIEWS); };

// ---- input -----------------------------------------------------------------------------------------------------

OscSurface.prototype.control = function (m) {
    var oct = (m.mods & OSC.MOD_OCT) !== 0;
    var mod = oct || (m.mods & OSC.MOD_SHIFT) !== 0;
    switch (m.cls) {
    case OSC.RES_KNOB: this.fast.push({ k: 'cv' + m.index, until: this.clock() + 300 }); this.knob(m.index, m.value, m.extra, oct, mod); break;
    case OSC.RES_FADER: this.faderMove(m.index, m.value / 16383); break;
    case OSC.RES_PAD: if (m.value > 0) this.pad(m.index, mod); else this.drums.release(m.index); break;
    case OSC.RES_BUTTON: this.button(m.index, m.value !== 0, oct); break;
    case OSC.RES_MOD: this.shift = m.value !== 0; break;
    }
};

OscSurface.prototype.tempoTap = function (x100) { this.bw.transport.tempo().value().setRaw(x100 / 100); };

// detents -> a normalised step: 128 steps per range, 1024 with a modifier (fine). 'key' names the control for touch.
OscSurface.prototype.step = function (param, detents, fine, key) {
    param.inc(detents, fine ? 1024 : (this.prefs.fine ? 256 : 128));
    this.touchParam(param, key);
};

OscSurface.prototype.touchParam = function (param, key) {
    var t = this.touch[key];
    if (!t) {
        param.touch(true);
        t = this.touch[key] = { param: param };
    }
    t.until = this.clock() + OSC_TOUCH_MS;
};

OscSurface.prototype.untouch = function (now) {
    for (var k in this.touch)
        if (now >= this.touch[k].until) {
            this.touch[k].param.touch(false);
            delete this.touch[k];
        }
};

OscSurface.prototype.knob = function (idx, d, speed, oct, fine) {
    var bw = this.bw, bankB = idx >= 8, k = idx & 7;
    if (oct && k === 7) {                                   // Oct- + K8: tempo, 1 BPM a detent (0.1 with the Shift pad)
        var t = bw.transport.tempo().value();
        t.setRaw(Math.max(20, Math.min(666, t.getRaw() + d * (this.shift ? 0.1 : 1))));
        if (this.link.has(OSC.CAP_NOTIFY))
            this.link.raw(OscEnc.notify(1, 8, 'Tempo ' + t.getRaw().toFixed(2)));
        return;
    }
    switch (this.view) {
    case OSC.MODE_DEVICE:
        if (!bankB && this.stepMode() && this.drums.knob(k, d, fine)) break;
        this.step(bankB ? bw.trackRemotes.getParameter(k) : bw.remotes.getParameter(k), d, fine, 'k' + idx);
        break;
    case OSC.MODE_MIXER: {
        var tr = bw.trackBank.getItemAt(k);
        var p = bankB ? tr.sendBank().getItemAt(0) : tr.pan();
        this.step(p, d, fine, 'm' + idx);
        break;
    }
    case OSC.MODE_OVERVIEW:
        if (!bankB)
            this.step(bw.projectRemotes.getParameter(k), d, fine, 'o' + idx);
        else
            this.overviewKnob(k, d, fine);
        break;
    case OSC.MODE_BROWSER:
        this.browserKnob(k, d);
        break;
    }
};

OscSurface.prototype.overviewKnob = function (k, d, fine) {
    var bw = this.bw, tr = bw.transport;
    switch (k) {
    case 0: { var t = tr.tempo().value(); t.setRaw(Math.max(20, Math.min(666, t.getRaw() + d * (fine ? 0.1 : 1)))); break; }
    case 1: this.step(bw.groove.getShuffleAmount(), d, fine, 'shuffle'); break;
    case 2: tr.metronomeVolume().inc(d, fine ? 1024 : 128); break;
    case 3: tr.arrangerLoopStart().inc(d * (fine ? 1 : this.barBeats())); break;
    case 4: tr.arrangerLoopDuration().inc(d * (fine ? 1 : this.barBeats())); break;
    case 5: tr.incPosition(d * (fine ? 1 : this.barBeats()), true); break;
    case 7: this.step(bw.masterTrack.volume(), d, fine, 'master'); break;
    }
};

OscSurface.prototype.barBeats = function () {
    var ts = this.bw.transport.timeSignature();
    var num = ts.numerator().get(), den = ts.denominator().get();
    return den ? num * 4 / den : 4;
};

OscSurface.prototype.browserKnob = function (k, d) {
    var b = this.bw.browser, n = Math.abs(d), i;
    var col = [null, b.categoryColumn(), b.creatorColumn(), b.fileTypeColumn()][k];
    if (k === 0) {
        this.browseDir = d > 0 ? 1 : -1;
        if (this.browseIdx !== null)                         // counted here; Bitwig stops at the ends
            this.browseIdx = Math.max(0, this.browseIdx + d);
        for (i = 0; i < n; i++) d > 0 ? b.selectNextFile() : b.selectPreviousFile();
    } else if (col) {
        var cur = this.bw.browserCursors[k];
        this.browseIdx = null;                               // a filter changes the list: where the cursor is, is unknown
        for (i = 0; i < n; i++) d > 0 ? cur.selectNext() : cur.selectPrevious();
    }
};

OscSurface.prototype.button = function (id, down, oct) {
    var B = OSC.BTN, bw = this.bw, tr = bw.transport;
    if (id === B.SEQ) {
        if (down) {
            this.seqDown = this.clock() || 1;
            this.seqOct = oct;
            this.seqUsed = false;
        } else {                                            // a tap acts on release, so a hold can open the browser
            if (this.seqDown && !this.seqUsed) {
                if (this.seqOct) tr.isMetronomeEnabled().toggle();   // Oct- + SEQ tap: the metronome
                else this.cycleView();
            }
            this.seqDown = 0;
        }
        return;
    }
    if (!down)
        return;
    switch (id) {
    case B.SEQ_PLAY:
        if (oct) {
            tr.stop();
            tr.setPosition(0);
        } else {
            tr.togglePlay();
        }
        break;
    case B.SEQ_REC:
        if (oct) tr.isClipLauncherOverdubEnabled().toggle();
        else tr.record();
        break;
    case B.LEFT:
    case B.RIGHT:
        this.nav(id === B.RIGHT ? 1 : -1, oct);
        break;
    }
};

// Called every ~100 ms: a held SEQ becomes the browser.
OscSurface.prototype.poll = function (now) {
    if (this.seqDown && !this.seqUsed && now - this.seqDown >= OSC_SEQ_HOLD_MS) {
        this.seqUsed = true;
        this.openBrowser(this.seqOct);
    }
    this.drums.poll(now);
    this.untouch(now);
};

OscSurface.prototype.panelChanged = function (name) {
    var last = this.panel;
    this.panel = name;
    if (last === undefined || last === name || !this.views() || this.view === OSC.MODE_BROWSER)   // the first report is only the start state
        return;
    if (name === 'MIX') this.setView(OSC.MODE_MIXER);
    else if (this.view === OSC.MODE_MIXER) this.setView(OSC.MODE_DEVICE);
};

OscSurface.prototype.cycleView = function () {
    if (this.view === OSC.MODE_BROWSER) {
        this.bw.browser.cancel();
        this.setView(this.prevView);
        return;
    }
    var i = OSC_VIEWS.indexOf(this.view);
    this.setView(OSC_VIEWS[(i + 1) % OSC_VIEWS.length]);
};

OscSurface.prototype.setView = function (v) {
    if (v === this.view)
        return;
    if (v === OSC.MODE_BROWSER) {
        this.prevView = this.view;
        this.browseIdx = null; this.browseJump = -1; this.browseDir = 0;
    }
    this.view = v;
};

OscSurface.prototype.openBrowser = function (insertAfter) {
    var dev = this.bw.cursorDevice;
    if (insertAfter || !dev.exists().get())
        dev.afterDeviceInsertionPoint().browse();
    else
        dev.replaceDeviceInsertionPoint().browse();
    this.setView(OSC.MODE_BROWSER);
};

OscSurface.prototype.nav = function (dir, oct) {
    var bw = this.bw;
    switch (this.view) {
    case OSC.MODE_DEVICE:
        var pm = this.padMode();
        if ((pm === 'drum' || pm === 'keys') && this.drums.nav(dir, oct)) break;
        if (pm === null && this.shift && dir > 0 && !oct && bw.cursorTrack.canHoldNoteData().get()) {   // Shift pad + Right: a key lane
            this.drums.openKeys(bw.cursorTrack.position().get());
            break;
        }
        if (oct) dir > 0 ? bw.cursorDevice.selectNext() : bw.cursorDevice.selectPrevious();
        else dir > 0 ? bw.remotes.selectNextPage(true) : bw.remotes.selectPreviousPage(true);
        break;
    case OSC.MODE_MIXER:
        if (oct) { dir > 0 ? bw.trackBank.scrollPageForwards() : bw.trackBank.scrollPageBackwards(); }
        else if (dir > 0 && this.window === 0) this.window = 4;
        else if (dir < 0 && this.window === 4) this.window = 0;
        else if (dir > 0 && bw.trackBank.canScrollForwards().get()) { bw.trackBank.scrollPageForwards(); this.window = 0; }
        else if (dir < 0 && bw.trackBank.canScrollBackwards().get()) { bw.trackBank.scrollPageBackwards(); this.window = 4; }
        for (var i = 0; i < 4; i++) this.fader[i].picked = false;
        break;
    case OSC.MODE_OVERVIEW:
        bw.transport.incPosition(dir * this.barBeats() * (oct ? 4 : 1), true);
        break;
    case OSC.MODE_BROWSER:
        if (dir > 0) bw.browser.commit(); else bw.browser.cancel();
        this.setView(this.prevView);
        break;
    }
};

// ---- faders: soft takeover --------------------------------------------------------------------------------------

OscSurface.prototype.faderTarget = function (i) {
    var bw = this.bw;
    if (i < 4)
        return bw.trackBank.getItemAt(this.window + i).volume();
    var t = bw.cursorTrack;
    return [t.volume(), t.pan(), t.sendBank().getItemAt(0), t.sendBank().getItemAt(1)][i - 4];
};

OscSurface.prototype.faderMove = function (i, pos) {
    if (i > 7) return;
    var f = this.fader[i], p = this.faderTarget(i), v = p.value().get();
    var crossed = f.pos >= 0 && (f.pos - v) * (pos - v) <= 0;
    if (!this.prefs.softTakeover || f.picked || Math.abs(pos - v) < 0.02 || crossed) {
        f.picked = true;
        p.value().set(pos);
        this.touchParam(p, 'f' + i);
    }
    f.pos = pos;
    this.faderToast = { i: i, until: this.clock() + 1200 };   // outside the Mixer view a short "Track: -4.8 dB"
};

// The DAW moved a fader's target (automation, mouse): pick-up is needed again unless the fader sits there.
OscSurface.prototype.faderValueChanged = function (i, v) {
    var f = this.fader[i];
    if (f.picked && f.pos >= 0 && Math.abs(f.pos - v) > 0.02 && !this.touch['f' + i])
        f.picked = false;
};

// ---- pads (bank B: indices 16-31) -------------------------------------------------------------------------------

// ---- device pads: the two-state parameters of the current remote page (row 1) and the next one (row 2) -------------

function oscIsSwitch(p) { return p.exists().get() && p.discreteValueCount().get() === 2; }

// The 16 parameters (null where a slot is not a switch), or null when the pads stay track pads.
OscSurface.prototype.devicePads = function () {
    var bw = this.bw;
    if (this.view !== OSC.MODE_DEVICE || !bw.cursorDevice.exists().get()) return null;
    var r = bw.remotes, pr = bw.padRemotes, n = r.pageCount().get(), cur = r.selectedPageIndex().get();
    var next = cur + 1 < n && pr.selectedPageIndex().get() === cur + 1, ps = [], any = false;
    for (var i = 0; i < 16; i++) {
        var p = i < 8 ? r.getParameter(i) : next ? pr.getParameter(i - 8) : null;
        p = p && oscIsSwitch(p) ? p : null;
        if (p) any = true;
        ps.push(p);
    }
    return any ? ps : null;
};

// What pad bank B is in the Device view: 'drum' (a selected Drum Machine), 'keys' (a key lane's steps, opened with
// Shift pad + Right on the track it was opened on), 'device' (device pads), 'drum' (a Drum Machine as the track's first
// instrument), or null (track pads; always outside the Device view).
OscSurface.prototype.padMode = function () {
    if (this.view !== OSC.MODE_DEVICE) return null;
    if (this.bw.cursorDevice.exists().get() && this.drums.selected()) return 'drum';
    if (this.drums.keysOpen() && this.bw.cursorTrack.position().get() === this.drums.keyTrack) return 'keys';
    if (this.devicePads()) return 'device';
    return this.drums.onTrack() ? 'drum' : null;
};

// Keep the pad page cursor one page after the knobs' page (Bitwig applies it on its next update).
OscSurface.prototype.syncPadPage = function () {
    var r = this.bw.remotes, pr = this.bw.padRemotes, want = r.selectedPageIndex().get() + 1;
    if (want < r.pageCount().get() && pr.selectedPageIndex().get() !== want)
        pr.selectedPageIndex().set(want);
};

// Do the pads show steps (a drum lane or a key lane)?
OscSurface.prototype.stepMode = function () { var m = this.padMode(); return m === 'drum' || m === 'keys'; };

// Mod wheel drift (DAW1 Bluetooth run: CC 1 flipping 125 / 126 about once a second with the wheel left alone). A
// flip is a one-step change back to the value two messages ago (A, B, A); a move of more than 2 starts over, so a hand
// on the wheel never counts. 8 flips within 30 s: one notice per session that suggests the wheel calibration.
OSC.WHEEL_FLIPS = 8; OSC.WHEEL_WINDOW_MS = 30000;
OscSurface.prototype.modWheel = function (v) {
    var w = this.wheel || (this.wheel = { last: -1, prev: -1, flips: 0, since: 0, warned: false }), t = this.clock();
    var d = w.last < 0 ? 0 : v - w.last;
    if (d > 2 || d < -2) { w.flips = 0; w.since = 0; }
    else if ((d === 1 || d === -1) && v === w.prev) {
        if (!w.flips || t - w.since > OSC.WHEEL_WINDOW_MS) { w.flips = 0; w.since = t; }
        w.flips++;
    }
    w.prev = w.last; w.last = v;
    if (w.flips >= OSC.WHEEL_FLIPS && !w.warned && this.link.has(OSC.CAP_NOTIFY)) {
        w.warned = true;
        this.notify(50, 'Mod wheel ' + Math.min(v, w.prev) + '/' + Math.max(v, w.prev) + ' jitters: calibrate Wheels');   // 5 s; 48 chars max
    }
};

// A notice on the keyboard's screen (when it can show them): 'secs' seconds.
OscSurface.prototype.notify = function (secs, text) {
    if (this.link.has(OSC.CAP_NOTIFY)) this.link.raw(OscEnc.notify(1, secs, text));
};

OscSurface.prototype.pad = function (idx, mod) {
    if (idx < 16) return;
    var bw = this.bw, slot = (idx - 16) & 7, row2 = idx >= 24;
    var tr = bw.trackBank.getItemAt(slot);
    var prow = row2 && !mod ? this.padRow() : null;         // a view with host-defined bottom-row pads (oscuro_pads.js)
    if (prow) {
        if (prow[slot]) prow[slot].run(bw, this);
        return;
    }
    if (mod && row2) {
        if (slot < OSC_SUBS.length) this.sub = OSC_SUBS[slot];
        return;
    }
    if (mod) {                                              // Oct- / Shift + row 1: bank and scene moves
        if (slot === 0) bw.trackBank.scrollPageBackwards();
        else if (slot === 1) bw.trackBank.scrollPageForwards();
        else if (slot === 2) bw.trackBank.sceneBank().scrollBackwards();
        else if (slot === 3) bw.trackBank.sceneBank().scrollForwards();
        else if (slot === 7) bw.trackBank.sceneBank().getItemAt(0).launch();
        return;
    }
    var mode = this.padMode();
    if (mode === 'drum' || mode === 'keys') { this.drums.press(idx); return; }
    var dp = mode === 'device' ? this.devicePads() : null;
    if (dp) {                                               // device pads: toggle the switch (a dark pad does nothing)
        var p = dp[idx - 16];
        if (p) {
            p.value().set(p.value().get() >= 0.5 ? 0 : 1);
            this.touchParam(p, 'p' + (idx - 16));
        }
        return;
    }
    if (!tr.exists().get()) return;
    if (!row2) { bw.cursorTrack.selectChannel(tr); return; }
    switch (this.sub) {
    case 'mute': tr.mute().toggle(); break;
    case 'solo': tr.solo().toggle(); break;
    case 'arm': tr.arm().toggle(); break;
    case 'stop': tr.stop(); break;
    case 'launch': tr.clipLauncherSlotBank().getItemAt(0).launch(); break;
    }
};

// ---- render: the whole state; OscLink sends only what changed ---------------------------------------------------

function oscRgb7(c) {                                       // Bitwig ColorValue -> 0..127 triplet
    return [Math.round(c.red() * 127), Math.round(c.green() * 127), Math.round(c.blue() * 127)];
}

function oscScale(rgb, f) { return [rgb[0] * f, rgb[1] * f, rgb[2] * f]; }

OscSurface.prototype.render = function () {
    var L = this.link;
    if (L.state !== 'up') return;
    var bw = this.bw, views = this.views();
    this.followCursor();
    // the mode (only v1 devices draw the Mixer, Overview and Browser screens; v0 ones keep knob cells)
    var titles = {}; titles[OSC.MODE_DEVICE] = 'Device'; titles[OSC.MODE_MIXER] = 'Mixer';
    titles[OSC.MODE_OVERVIEW] = 'Overview'; titles[OSC.MODE_BROWSER] = 'Browser';
    L.send('mode', OscEnc.mode(views ? this.view : OSC.MODE_DEVICE, titles[this.view]));
    this.renderTransport();
    this.renderTracks();
    this.renderCells();
    this.renderPads();
    this.renderButtons();
    if (L.has(OSC.CAP_HEADER))
        L.send('header', this.header());
    if (L.has(OSC.CAP_TABS))
        L.send('tabs', this.tabs());
    var ft = this.faderToast;
    if (ft && this.clock() < ft.until && !(views && this.view === OSC.MODE_MIXER) && L.has(OSC.CAP_NOTIFY)) {
        var who = ft.i < 4 ? bw.trackBank.getItemAt(this.window + ft.i).name().get()
                           : bw.cursorTrack.name().get() + ' ' + ['Vol', 'Pan', 'Send 1', 'Send 2'][ft.i - 4];
        var txt = this.faderTarget(ft.i).displayedValue().get();
        var f = this.fader[ft.i];
        if (this.prefs.softTakeover && !f.picked)
            txt += f.pos < this.faderTarget(ft.i).value().get() ? '  (move up)' : '  (move down)';
        L.send('ftoast', OscEnc.notify(0, 12, who + ': ' + txt));
    }
    if (L.has(OSC.CAP_ACCENT) && this.prefs.accent !== 'off')
        L.send('accent', OscEnc.accent(OSC_ACCENT));        // once per session (the link drops repeats)
    if (views && this.view === OSC.MODE_BROWSER)
        this.renderBrowser();
};

OscSurface.prototype.renderTransport = function () {
    var tr = this.bw.transport, f = 0;
    if (tr.isPlaying().get()) f |= OSC.TR_PLAYING;
    if (tr.isArrangerRecordEnabled().get()) f |= OSC.TR_RECORDING;
    if (tr.isArrangerLoopEnabled().get()) f |= OSC.TR_LOOP;
    if (tr.isPunchInEnabled().get()) f |= OSC.TR_PUNCH_IN;
    if (tr.isPunchOutEnabled().get()) f |= OSC.TR_PUNCH_OUT;
    if (tr.isMetronomeEnabled().get()) f |= OSC.TR_METRONOME;
    if (tr.isArrangerAutomationWriteEnabled().get()) f |= OSC.TR_AUTOMATION;
    if (tr.isClipLauncherOverdubEnabled().get() || tr.isArrangerOverdubEnabled().get()) f |= OSC.TR_OVERDUB;
    this.link.send('transport', OscEnc.transport(f, tr.tempo().value().getRaw() * 100));
};

// Position and time signature, at most 10 Hz (the caller's timer).
OscSurface.prototype.renderPosition = function () {
    var L = this.link;
    if (!L.has(OSC.CAP_PROJECT)) return;
    var tr = this.bw.transport, ts = tr.timeSignature();
    var num = ts.numerator().get() || 4, den = ts.denominator().get() || 4;
    var beatLen = 4 / den, pos = Math.max(0, tr.getPosition().get());
    var barLen = num * beatLen, bar = Math.floor(pos / barLen + 1e-9);
    var inBar = pos - bar * barLen, beat = Math.floor(inBar / beatLen + 1e-9);
    var six = Math.floor((inBar - beat * beatLen) / 0.25 + 1e-9);
    L.send('project', OscEnc.project(bar + 1, beat + 1, six + 1, num, den, this.bw.application.projectName().get()));
};

OscSurface.prototype.renderMeters = function () {
    if (this.view === OSC.MODE_MIXER && this.link.has(OSC.CAP_METERS))
        this.link.send('meters', OscEnc.meters(0, this.meter));
};

// The mixer window follows the track selected in Bitwig (a mouse click, a pad, the track list): the bank scrolls to show
// it, and the 4-fader half is the one it sits in. Only a change of the selected track moves the half, so paging the
// window with Left / Right sticks until the selection changes.
OscSurface.prototype.followCursor = function () {
    var bw = this.bw, c = bw.cursorTrack;
    if (!c.exists().get()) return;
    var ss = this.selectedSlot();
    if (ss < 0) {
        var p = c.position().get();
        if (p !== this.scrollAsked) {                       // once per position: Bitwig applies the scroll a little later
            this.scrollAsked = p;
            bw.trackBank.scrollIntoView(p);
        }
        return;
    }
    this.scrollAsked = -1;
    var abs = bw.trackBank.scrollPosition().get() + ss;
    if (abs === this.cursorAbs) return;
    this.cursorAbs = abs;
    var w = ss >= 4 ? 4 : 0;
    if (w !== this.window) {
        this.window = w;
        for (var i = 0; i < 4; i++) this.fader[i].picked = false;
    }
};

// Which strip of the bank is the cursor track (-1: none of them).
OscSurface.prototype.selectedSlot = function () {
    var bw = this.bw;
    for (var i = 0; bw.trackIsCursor && i < 8; i++)
        if (bw.trackIsCursor[i].get()) return i;
    var p = bw.cursorTrack.position().get() - bw.trackBank.scrollPosition().get();
    return bw.cursorTrack.exists().get() && p >= 0 && p < 8 ? p : -1;
};

OscSurface.prototype.trackFlags = function (t, parent) {
    var f = 0;
    if (!t.exists().get()) return 0;
    f |= OSC.TRK_EXISTS;
    if (t.mute().get()) f |= OSC.TRK_MUTE;
    if (t.solo().get()) f |= OSC.TRK_SOLO;
    if (t.arm().get()) f |= OSC.TRK_ARMED;
    if (t.isGroup().get()) f |= OSC.TRK_GROUP;
    if (parent && parent.exists().get() && parent.isGroup().get()) f |= OSC.TRK_IN_GROUP;
    return f;
};

OscSurface.prototype.renderTracks = function () {
    var bw = this.bw, sel = bw.cursorTrack.name().get(), ss = this.selectedSlot();
    for (var i = 0; i < 8; i++) {
        var t = bw.trackBank.getItemAt(i), f = this.trackFlags(t, bw.trackParents && bw.trackParents[i]);
        if (f && i === ss) f |= OSC.TRK_SELECTED;
        this.link.send('trk' + i, OscEnc.track(i, f, f ? oscRgb7(t.color()) : [0, 0, 0], f ? t.name().get() : ''));
    }
    var c = bw.cursorTrack, cf = this.trackFlags(c, bw.cursorParent) | (c.exists().get() ? OSC.TRK_SELECTED : 0);
    this.link.send('trk8', OscEnc.track(8, cf, oscRgb7(c.color()), sel));
};

// A remote / mixer parameter as a cell; a slot without a parameter is disabled (v1) or blank (v0).
OscSurface.prototype.paramCell = function (target, p, bipolar) {
    var L = this.link, v1 = L.has(OSC.CAP_CELL_V1);
    if (!p || !p.exists().get()) {
        L.send('cn' + target, OscEnc.cellName(target, v1 ? OSC.CELL_DISABLED : 0, null, ''));
        L.send('cv' + target, OscEnc.cellValue(target, 0, ''));
        return;
    }
    var flags = (bipolar ? OSC.CELL_BAR_BI : OSC.CELL_BAR_UNI) | (v1 && this.prefs.showMod ? OSC.CELL_SHOW_MOD : 0);
    L.send('cn' + target, OscEnc.cellName(target, flags, null, p.name().get()));
    L.send('cv' + target, OscEnc.cellValue(target, p.value().get() * 16383, p.displayedValue().get()));
    if (v1 && this.prefs.showMod)
        L.sendMod('cm' + target, target, p.modulatedValue().get() * 16383);
};

// A fixed cell (Overview bank B, browser).
OscSurface.prototype.textCell = function (target, name, value01, text) {
    var L = this.link, v1 = L.has(OSC.CAP_CELL_V1);
    L.send('cn' + target, OscEnc.cellName(target, name ? OSC.CELL_BAR_UNI : (v1 ? OSC.CELL_DISABLED : 0), null, name || ''));
    L.send('cv' + target, OscEnc.cellValue(target, (value01 || 0) * 16383, text || ''));
};

OscSurface.prototype.renderCells = function () {
    var bw = this.bw, i, tr = bw.transport;
    switch (this.view) {
    case OSC.MODE_DEVICE: {
        var stepCells = this.stepMode() ? this.drums.cells() : null;
        for (i = 0; i < 8; i++) {
            if (stepCells && i < stepCells.length) this.textCell(i, stepCells[i][0], stepCells[i][1], stepCells[i][2]);
            else this.paramCell(i, bw.remotes.getParameter(i), false);
            this.paramCell(8 + i, bw.trackRemotes.getParameter(i), false);
        }
        break;
    }
    case OSC.MODE_MIXER:
        for (i = 0; i < 8; i++) {
            var t = bw.trackBank.getItemAt(i);
            this.paramCell(i, t.exists().get() ? t.pan() : null, true);
            this.paramCell(8 + i, t.exists().get() ? t.sendBank().getItemAt(0) : null, false);
        }
        break;
    case OSC.MODE_OVERVIEW: {
        for (i = 0; i < 8; i++)
            this.paramCell(i, bw.projectRemotes.getParameter(i), false);
        var t0 = tr.tempo().value().getRaw();
        this.textCell(8, 'Tempo', (t0 - 20) / 646, t0.toFixed(2));
        var sh = bw.groove.getShuffleAmount();
        this.textCell(9, 'Shuffle', sh.value().get(), sh.displayedValue().get());
        this.textCell(10, 'Click', tr.metronomeVolume().get(), Math.round(tr.metronomeVolume().get() * 100) + ' %');
        this.textCell(11, 'Loop at', 0, tr.arrangerLoopStart().getFormatted());
        this.textCell(12, 'Loop len', 0, tr.arrangerLoopDuration().getFormatted());
        this.textCell(13, 'Position', 0, tr.getPosition().getFormatted());
        this.textCell(14, '', 0, '');
        var mv = bw.masterTrack.volume();
        this.textCell(15, 'Master', mv.value().get(), mv.displayedValue().get());
        break;
    }
    case OSC.MODE_BROWSER: {
        var names = ['Result', 'Category', 'Creator', 'Type'];
        for (i = 0; i < 16; i++)
            this.textCell(i, i < 4 ? names[i] : '', 0, i < 4 ? bw.browserCursors[i].name().get() : '');
        break;
    }
    }
    // faders: cells 16-23 are the 8 strips' volumes (the Mixer view draws them); the window's 4 are named F1-F4,
    // with ^ / v while a fader waits for pick-up (move it that way)
    for (i = 0; i < 8; i++) {
        var tk = bw.trackBank.getItemAt(i), vol = tk.volume(), name = '';
        if (i >= this.window && i < this.window + 4 && tk.exists().get()) {
            var f = this.fader[i - this.window];
            name = 'F' + (i - this.window + 1);
            if (this.prefs.softTakeover && !f.picked && f.pos >= 0)
                name += f.pos < vol.value().get() ? '^' : 'v';
        }
        this.link.send('cn' + (16 + i), OscEnc.cellName(16 + i, 0, null, name));
        this.link.send('cv' + (16 + i), OscEnc.cellValue(16 + i, tk.exists().get() ? vol.value().get() * 16383 : 0,
                                                         tk.exists().get() ? vol.displayedValue().get() : ''));
    }
};

// The Device view's page line: the remote-control pages left and right of the current one. Other views (and a key lane,
// or no device) send an empty set, which the device shows as the header's right text.
OscSurface.prototype.tabs = function () {
    var r = this.bw.remotes, mode = this.padMode();
    if (this.view !== OSC.MODE_DEVICE || mode === 'keys' || !this.bw.cursorDevice.exists().get())
        return OscEnc.tabs(0, 0, '', '', '');
    var n = r.pageCount().get(), p = r.selectedPageIndex().get(), names = r.pageNames().get() || [];
    if (!n || p < 0) return OscEnc.tabs(0, 0, '', '', '');
    return OscEnc.tabs(p, n, p > 0 ? names[p - 1] || '' : '', names[p] || '', p + 1 < n ? names[p + 1] || '' : '');
};

OscSurface.prototype.header = function () {
    var bw = this.bw;
    switch (this.view) {
    case OSC.MODE_DEVICE: {
        var dev = bw.cursorDevice, r = bw.remotes;
        if (this.padMode() === 'keys') return this.drums.header('');        // a key lane needs no device
        if (!dev.exists().get()) return OscEnc.header('No device', 'hold SEQ: browse');
        var n = r.pageCount().get(), p = r.selectedPageIndex().get(), names = r.pageNames().get();
        var text = n ? (p + 1) + '/' + n + ' ' + (names[p] || '') : 'no pages', mode = this.padMode();
        if (mode === 'drum' || mode === 'keys') return this.drums.header(text);
        return OscEnc.header(dev.name().get(), text + (mode === 'device' ? ' | pads' : ''));
    }
    case OSC.MODE_MIXER: {
        var first = bw.trackBank.scrollPosition().get();
        return OscEnc.header('Mixer', 'Tracks ' + (first + 1) + '-' + (first + 8));
    }
    case OSC.MODE_OVERVIEW:
        return OscEnc.header('Overview', bw.application.projectName().get());
    default:
        return OscEnc.header('Browser', bw.browser.title().get());
    }
};

OscSurface.prototype.renderBrowser = function () {
    var bw = this.bw, items = bw.browserItems, sel = -1, i;
    for (i = 0; i < 8; i++)
        if (items.getItemAt(i).isSelected().get()) sel = i;
    var first = items.scrollPosition().get();
    var total = bw.browser.resultsColumn().entryCount().get();
    if (sel >= 0) {
        this.browseIdx = first + sel;                        // the cursor is in the window: that is the truth
        this.browseJump = -1;
    } else if (total > 0) {
        // The cursor left the 8 rows (a fast turn on a long list). Go straight to where it should be: our count of
        // the turns since it was last seen. Paging 8 rows a flush (the old way) took seconds on a long list.
        var to = -1;
        if (this.browseIdx !== null && this.browseJump !== first) {
            to = Math.max(0, Math.min(total - 8, this.browseIdx - 2));
            this.browseJump = to;                            // when the window sits there and still shows no cursor, our count was off
        } else if (this.browseDir) {
            to = first + 8 * this.browseDir;                 // fall back: one page towards the cursor
            this.browseIdx = null;
        }
        if (to >= 0 && to < total && to !== first)
            items.scrollPosition().set(to);
    }
    this.link.send('list', OscEnc.list(1, total, sel >= 0 ? first + sel : (this.browseIdx !== null ? this.browseIdx : 0), bw.browser.title().get()));
    for (i = 0; i < 8; i++) {
        var it = items.getItemAt(i), ex = it.exists().get();
        this.link.send('row' + i, OscEnc.listRow(i, first + i, ex && i === sel ? OSC.ROW_SELECTED : 0, null, ex ? it.name().get() : ''));
    }
};

// The bottom row's functions in the current view (oscuro_pads.config.js), or null: the pads keep their sub-modes.
OscSurface.prototype.padRow = function () {
    return this.view === OSC.MODE_OVERVIEW && this.views() ? oscPadRow('overview') : null;
};

// Name the 16 pads of bank B (CELL_NAME 40-55) for the keyboard's Oct- hint: row 1 the tracks, row 2 the functions or the
// sub-mode. Dark names where the pads mean something else (device switches, drum lanes, key steps).
OscSurface.prototype.renderPadLabels = function () {
    var bw = this.bw, mode = this.padMode(), prow = this.padRow(), i, name, rgb, tr;
    for (i = 0; i < 16; i++) {
        name = ''; rgb = [0, 0, 0];
        if (!mode) {
            tr = bw.trackBank.getItemAt(i & 7);
            if (i < 8) {
                if (tr.exists().get()) { name = String(tr.name().get() || 'Track ' + (i + 1)).substr(0, 10); rgb = oscRgb7(tr.color()); }
            } else if (prow) {
                if (prow[i - 8]) { name = prow[i - 8].label; rgb = prow[i - 8].rgb; }
            } else if (tr.exists().get()) {
                name = this.sub.charAt(0).toUpperCase() + this.sub.substr(1); rgb = OSC_SUB_RGB[this.sub];
            }
        }
        this.link.send('pl' + i, OscEnc.cellName(OSC.CELL_PAD + 16 + i, name ? 1 : 0, rgb, name));
    }
};

OscSurface.prototype.renderPads = function () {
    this.renderPadLabels();
    var bw = this.bw, lights = [], i, ss = this.selectedSlot();
    this.syncPadPage();
    var mode = this.padMode();
    if (mode !== 'keys' && this.drums.keysOpen()) this.drums.closeKeys();   // left the Device view, changed track, a drum device won
    if (mode !== this.pmodeLast) {                          // tell the player once that the pads changed meaning
        if (mode === 'keys')
            this.notify(10, 'Steps: ' + bw.cursorTrack.name().get() + ' key ' + oscNoteName(this.drums.key) + ' (Oct- + Left/Right: key)');
        else if (mode)
            this.notify(10, mode === 'device' ? 'Pads: ' + bw.cursorDevice.name().get() + ' switches'
                                              : 'Pads: ' + bw.drumDevice.name().get() + ' drum pads (hold one: steps)');
        if (mode !== 'drum' && mode !== 'keys') this.drums.reset();
        this.pmodeLast = mode;
    }
    if (mode === 'drum' || mode === 'keys') {
        this.drums.sync();
        if (!this.shift) { this.link.send('pads', OscEnc.pads(16, this.drums.lights())); return; }
    }
    var dp = mode === 'device' ? this.devicePads() : null;
    if (dp && !this.shift) {                                // device pads in the accent: lit = on
        for (i = 0; i < 16; i++)
            lights.push({ rgb: dp[i] ? oscScale(OSC_ACCENT, dp[i].value().get() >= 0.5 ? 1 : 0.15) : [0, 0, 0], anim: OSC.SOLID });
        this.link.send('pads', OscEnc.pads(16, lights));
        return;
    }
    for (i = 0; i < 8; i++) {                               // row 1: the tracks, the selected one bright
        var t = bw.trackBank.getItemAt(i);
        lights.push(t.exists().get() ? { rgb: oscScale(oscRgb7(t.color()), i === ss ? 1 : 0.25), anim: OSC.SOLID }
                                     : { rgb: [0, 0, 0], anim: OSC.SOLID });
    }
    var prow = this.shift ? null : this.padRow();
    for (i = 0; i < 8; i++) {                               // row 2: the sub-mode's state, or (Shift held) the sub-modes
        var tr = bw.trackBank.getItemAt(i), rgb = [0, 0, 0], anim = OSC.SOLID;
        if (prow) {
            if (prow[i]) rgb = oscScale(prow[i].rgb, prow[i].lit(bw) ? 1 : 0.18);
        } else if (this.shift) {
            if (i < OSC_SUBS.length)
                rgb = oscScale(OSC_SUB_RGB[OSC_SUBS[i]], OSC_SUBS[i] === this.sub ? 1 : 0.2);
        } else if (tr.exists().get()) {
            var base = OSC_SUB_RGB[this.sub];
            switch (this.sub) {
            case 'mute': rgb = oscScale(base, tr.mute().get() ? 1 : 0.12); break;
            case 'solo': rgb = oscScale(base, tr.solo().get() ? 1 : 0.12); break;
            case 'arm': rgb = oscScale(base, tr.arm().get() ? 1 : 0.12); break;
            case 'stop':
                var playing = !tr.isStopped().get();
                rgb = oscScale(base, playing ? 1 : 0.12);
                anim = tr.isQueuedForStop().get() ? OSC.BLINK : playing ? OSC.PULSE : OSC.SOLID;
                break;
            case 'launch': {
                var s = tr.clipLauncherSlotBank().getItemAt(0);
                if (s.hasContent().get()) {
                    rgb = oscRgb7(s.color());
                    anim = s.isRecording().get() ? OSC.BLINK : (s.isPlaybackQueued().get() || s.isRecordingQueued().get()) ? OSC.PULSE : OSC.SOLID;
                    if (!s.isPlaying().get() && anim === OSC.SOLID) rgb = oscScale(rgb, 0.3);
                }
                break;
            }
            }
        }
        lights.push({ rgb: rgb, anim: anim });
    }
    this.link.send('pads', OscEnc.pads(16, lights));
};

OscSurface.prototype.renderButtons = function () {
    var tr = this.bw.transport, B = OSC.BTN;
    this.link.send('bl' + B.SEQ_PLAY, OscEnc.buttonLed(B.SEQ_PLAY, tr.isPlaying().get() ? 1 : 0));
    this.link.send('bl' + B.SEQ_REC, OscEnc.buttonLed(B.SEQ_REC, tr.isArrangerRecordEnabled().get() ? 1 :
                                                       tr.isClipLauncherOverdubEnabled().get() ? 2 : 0));
    if (this.prefs.seqViews)
        this.link.send('bl' + B.SEQ, OscEnc.buttonLed(B.SEQ, this.view === OSC.MODE_DEVICE ? 0 : 1));
    this.link.send('bl' + B.LEFT, OscEnc.buttonLed(B.LEFT, 1));
    this.link.send('bl' + B.RIGHT, OscEnc.buttonLed(B.RIGHT, 1));
};

if (typeof module !== 'undefined')
    module.exports = { OscSurface: OscSurface };
