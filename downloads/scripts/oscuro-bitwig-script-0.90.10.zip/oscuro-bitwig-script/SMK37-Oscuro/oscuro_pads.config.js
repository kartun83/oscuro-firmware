// Pad wiring for the SMK-37 Oscuro script: which function each bottom-row pad (bank B, row 2) has in a view.
// Edit the names, save, and restart the script in Bitwig (Settings > Controllers). Names come from OSC_PAD_FUNCS in
// oscuro_pads.js: Stop, Play, Rec, Loop, Metro, Punch in, Punch out, Overdub, Tap, Cue <, Cue >, Cue +, Undo, Redo.
// (Deleting a cue marker is not offered: Bitwig's controller API has no call for it.) An empty string leaves a pad dark. A view that is not listed keeps its own pads (the Mixer: row 1 selects tracks,
// row 2 mutes / solos / arms / stops / launches, picked with Oct- or Shift + pads 1-5). Row 1 always selects tracks.
var OSC_PAD_MAP = {
    overview: ['Stop', 'Play', 'Rec', 'Loop', 'Metro', 'Cue <', 'Cue >', 'Cue +']
};
