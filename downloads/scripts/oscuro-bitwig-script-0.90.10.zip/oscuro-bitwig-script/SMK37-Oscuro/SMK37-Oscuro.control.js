// SMK-37 under Oscuro firmware: Bitwig Studio controller script (Oscuro DAW protocol v1).
// Install: copy this folder to ~/Documents/Bitwig Studio/Controller Scripts/ (macOS; see README.md).
// Needs Oscuro firmware with the DAW protocol (the DAW / DAW BT builds draw the Mixer, Overview and Browser screens).
// On M-Vave's own firmware use the stock SMK37-Elite script instead; both can be installed side by side.
// Targets the newest controller API (Bitwig Studio 6.1). Older Bitwig versions are not supported: they get a message.
var OSC_API = 25;
try {
    loadAPI(OSC_API);
} catch (e) {
    var oscTooOld = 'SMK-37 Oscuro needs Bitwig Studio 6.1 or newer (controller API ' + OSC_API + ')';
    host.errorln(oscTooOld);
    host.showPopupNotification(oscTooOld);
    throw e;
}

load('oscuro_proto.js');
load('oscuro_link.js');
load('oscuro_drums.js');
load('oscuro_pads.config.js');
load('oscuro_pads.js');
load('oscuro_surface.js');

host.defineController('Oscuro', 'SMK-37 Oscuro', '1.0.3', '2f78209c-778a-4793-af87-0548bd09140a', 'Oscuro');
host.defineMidiPorts(1, 1);
host.addDeviceNameBasedDiscoveryPair(['SMK-37 Oscuro USB'], ['SMK-37 Oscuro USB']);
host.addDeviceNameBasedDiscoveryPair(['SMK-37 Oscuro USB DAW'], ['SMK-37 Oscuro USB DAW']);
host.addDeviceNameBasedDiscoveryPair(['SMK-37 Oscuro BLE'], ['SMK-37 Oscuro BLE']);
host.addDeviceNameBasedDiscoveryPair(['SMK-37 Oscuro BLE Bluetooth'], ['SMK-37 Oscuro BLE Bluetooth']);

var osc = { link: null, surface: null, bw: null, prefs: {} };

function oscNow() { return Date.now(); }

function oscMark(v) { v.markInterested(); return v; }

// Everything the renderer reads must be subscribed once, here.
function oscParam(p) {
    oscMark(p.exists()); oscMark(p.name()); oscMark(p.value()); oscMark(p.displayedValue()); oscMark(p.modulatedValue());
    oscMark(p.discreteValueCount());
    return p;
}

function oscTrack(t) {
    oscMark(t.exists()); oscMark(t.name()); oscMark(t.color()); oscMark(t.mute()); oscMark(t.solo()); oscMark(t.arm());
    oscMark(t.isStopped()); oscMark(t.isQueuedForStop()); oscMark(t.position()); oscMark(t.isGroup());
    oscParam(t.volume()); oscParam(t.pan());
    var sb = t.sendBank();
    for (var i = 0; i < sb.getSizeOfBank(); i++) oscParam(sb.getItemAt(i));
    return t;
}

function oscPrefs() {
    var p = host.getPreferences();
    var seq = p.getEnumSetting('SEQ button', 'Buttons', ['Screen views', 'Firmware sequencer'], 'Screen views');
    var mod = p.getEnumSetting('Show modulation', 'Screen', ['Yes', 'No'], 'Yes');
    // the accent stays put for the session; the selected track's colour shows as its bar and chips, never as the accent
    var acc = p.getEnumSetting('Accent colour', 'Screen', ['Bitwig orange', 'Keyboard setting'], 'Bitwig orange');
    var take = p.getEnumSetting('Fader pick-up', 'Faders', ['Soft takeover', 'Jump'], 'Soft takeover');
    var res = p.getEnumSetting('Knob steps', 'Knobs', ['Normal (128)', 'Fine (256)'], 'Normal (128)');
    var fol = p.getEnumSetting('Follow Bitwig panel', 'Screen', ['Yes', 'No'], 'Yes');   // the Mix panel opens the Mixer view
    var con = p.getEnumSetting('Connection', 'Link', ['USB', 'Bluetooth'], 'USB');     // how much to send per 100 ms
    var apply = function () {
        osc.prefs.seqViews = seq.get() === 'Screen views';
        osc.prefs.showMod = mod.get() === 'Yes';
        osc.prefs.accent = acc.get() === 'Bitwig orange' ? 'bitwig' : 'off';
        osc.prefs.softTakeover = take.get() === 'Soft takeover';
        osc.prefs.fine = res.get() !== 'Normal (128)';
        osc.prefs.followPanel = fol.get() === 'Yes';
        osc.prefs.budget = con.get() === 'USB' ? OSC_BUDGET : 120;
        if (osc.link) osc.link.budget = osc.prefs.budget;
        if (osc.link && osc.link.state === 'up') osc.surface.start();   // claims and cells follow the new settings
    };
    [seq, mod, acc, take, res, fol, con].forEach(function (s) { s.addValueObserver(apply); });
    apply();
}

function init() {
    oscPrefs();
    var midiIn = host.getMidiInPort(0), midiOut = host.getMidiOutPort(0);
    // keys, unclaimed pads (bank A, Harmony), wheels, pedal: plain MIDI into Bitwig
    var notes = midiIn.createNoteInput('SMK-37 Oscuro', '8?????', '9?????', 'A?????', 'B?????', 'D?????', 'E?????');
    // not consumed: the MIDI callback below also sees them (it only watches the mod wheel, CC 1); the note input still
    // gets every event
    notes.setShouldConsumeEvents(false);
    midiIn.setMidiCallback(function (status, d1, d2) {
        if ((status & 0xF0) === 0xB0 && d1 === 1 && osc.surface) osc.surface.modWheel(d2);
    });

    var bw = {};
    bw.application = host.createApplication();
    oscMark(bw.application.projectName());
    bw.transport = host.createTransport();
    var tr = bw.transport;
    [tr.isPlaying(), tr.isArrangerRecordEnabled(), tr.isArrangerLoopEnabled(), tr.isPunchInEnabled(), tr.isPunchOutEnabled(),
     tr.isMetronomeEnabled(), tr.isArrangerAutomationWriteEnabled(), tr.isClipLauncherOverdubEnabled(),
     tr.isArrangerOverdubEnabled(), tr.tempo().value(), tr.timeSignature().numerator(), tr.timeSignature().denominator(),
     tr.getPosition(), tr.metronomeVolume(), tr.arrangerLoopStart(), tr.arrangerLoopDuration()].forEach(oscMark);
    bw.groove = host.createGroove();
    oscParam(bw.groove.getShuffleAmount());
    bw.masterTrack = host.createMasterTrack(0);
    oscParam(bw.masterTrack.volume());

    bw.cursorTrack = host.createCursorTrack('OSC_TRACK', 'Oscuro', 2, 1, true);
    oscTrack(bw.cursorTrack);
    bw.cursorDevice = bw.cursorTrack.createCursorDevice('OSC_DEVICE', 'Oscuro', 0, CursorDeviceFollowMode.FOLLOW_SELECTION);
    oscMark(bw.cursorTrack.canHoldNoteData());        // key lanes: only a track that can hold notes
    oscMark(bw.cursorDevice.exists()); oscMark(bw.cursorDevice.name()); oscMark(bw.cursorDevice.hasDrumPads());
    // drum pads and steps (oscuro_drums.js): the track's first instrument, its 8-pad window, the editor's clip
    bw.drumDevice = bw.cursorTrack.createCursorDevice('OSC_DRUMS', 'Oscuro drums', 0, CursorDeviceFollowMode.FIRST_INSTRUMENT);
    oscMark(bw.drumDevice.exists()); oscMark(bw.drumDevice.name()); oscMark(bw.drumDevice.hasDrumPads());
    bw.drumPads = bw.drumDevice.createDrumPadBank(8);
    oscMark(bw.drumPads.scrollPosition());
    for (var di = 0; di < 8; di++) {
        var dp = bw.drumPads.getItemAt(di);
        oscMark(dp.exists()); oscMark(dp.name()); oscMark(dp.color()); oscMark(dp.mute()); oscMark(dp.solo());
    }
    // 128 steps wide and never scrolled in time: a step's x is its absolute position, like playingStep()
    bw.stepClip = host.createLauncherCursorClip(128, 1);
    bw.stepClip.setStepSize(0.25);
    bw.stepClip.scrollToStep(0);
    oscMark(bw.stepClip.exists()); oscMark(bw.stepClip.playingStep()); oscMark(bw.stepClip.getLoopLength());
    bw.stepClip.addNoteStepObserver(function (step) { if (osc.surface) osc.surface.drums.onStep(step); });
    bw.remotes = bw.cursorDevice.createCursorRemoteControlsPage(8);
    bw.padRemotes = bw.cursorDevice.createCursorRemoteControlsPage('OSC_PAD_REMOTES', 8, '');   // the next page, for device pads
    bw.trackRemotes = bw.cursorTrack.createCursorRemoteControlsPage('OSC_TRACK_REMOTES', 8, '');
    bw.projectRemotes = host.getProject().getRootTrackGroup().createCursorRemoteControlsPage('OSC_PROJECT_REMOTES', 8, '');
    [bw.remotes, bw.padRemotes, bw.trackRemotes, bw.projectRemotes].forEach(function (r) {
        oscMark(r.pageCount()); oscMark(r.selectedPageIndex()); oscMark(r.pageNames());
        for (var i = 0; i < 8; i++) oscParam(r.getParameter(i));
    });

    bw.trackBank = host.createMainTrackBank(8, 2, 1);
    bw.trackBank.followCursorTrack(bw.cursorTrack);
    oscMark(bw.trackBank.scrollPosition()); oscMark(bw.trackBank.canScrollForwards()); oscMark(bw.trackBank.canScrollBackwards());
    osc.meters = [0, 0, 0, 0, 0, 0, 0, 0];
    // Groups: the API has isGroup but no depth, so a track is "in a group" when its parent track is a group. Selection
    // is matched by identity (createEqualsValue), not by position: the cursor's position() and the bank's scroll
    // position need not count the same tracks once groups fold.
    bw.trackParents = []; bw.trackIsCursor = [];
    function oscParent(t) {
        var par = t.createParentTrack(0, 0);
        oscMark(par.exists()); oscMark(par.isGroup());
        return par;
    }
    for (var i = 0; i < 8; i++) {
        var t = oscTrack(bw.trackBank.getItemAt(i));
        bw.trackParents.push(oscParent(t));
        var eq = t.createEqualsValue(bw.cursorTrack);
        oscMark(eq);
        bw.trackIsCursor.push(eq);
        var slot = t.clipLauncherSlotBank().getItemAt(0);
        [slot.hasContent(), slot.color(), slot.isPlaying(), slot.isPlaybackQueued(), slot.isRecording(), slot.isRecordingQueued()].forEach(oscMark);
        (function (k) {
            t.addVuMeterObserver(128, -1, true, function (v) { if (osc.surface) osc.surface.meter[k] = v; });
            t.volume().value().addValueObserver(function (v) {
                var s = osc.surface;
                if (s && k >= s.window && k < s.window + 4) s.faderValueChanged(k - s.window, v);
            });
        })(i);
    }
    var ct = bw.cursorTrack, sends = ct.sendBank();
    bw.cursorParent = oscParent(ct);
    [ct.volume(), ct.pan(), sends.getItemAt(0), sends.getItemAt(1)].forEach(function (p, k) {
        p.value().addValueObserver(function (v) { if (osc.surface) osc.surface.faderValueChanged(4 + k, v); });
    });

    bw.browser = host.createPopupBrowser();
    oscMark(bw.browser.exists()); oscMark(bw.browser.title()); oscMark(bw.browser.resultsColumn().entryCount());
    bw.browserItems = bw.browser.resultsColumn().createItemBank(8);
    oscMark(bw.browserItems.scrollPosition());
    for (i = 0; i < 8; i++) {
        var it = bw.browserItems.getItemAt(i);
        oscMark(it.exists()); oscMark(it.name()); oscMark(it.isSelected());
    }
    bw.browserCursors = [bw.browser.resultsColumn().createCursorItem(), bw.browser.categoryColumn().createCursorItem(),
                         bw.browser.creatorColumn().createCursorItem(), bw.browser.fileTypeColumn().createCursorItem()];
    bw.browserCursors.forEach(function (c) { oscMark(c.name()); });

    osc.bw = bw;
    osc.link = new OscLink(midiOut, { name: 'Bitwig' });
    osc.link.budget = osc.prefs.budget;
    osc.surface = new OscSurface(bw, osc.link, osc.prefs, oscNow);
    osc.surface.meter = osc.meters;

    // Bitwig's panel (Arrange / Mix / Edit): opening the mixer panel shows the Mixer view, leaving it returns to Device
    bw.application.panelLayout().addValueObserver(function (v) {
        if (osc.surface && osc.prefs.followPanel) osc.surface.panelChanged(v);
    });

    // the browser closed in Bitwig (Esc, a click): leave the Browser view
    bw.browser.exists().addValueObserver(function (open) {
        var s = osc.surface;
        if (!open && s.view === OSC.MODE_BROWSER) s.setView(s.prevView);
    });

    midiIn.setSysexCallback(function (hex) {
        var now = oscNow(), m = osc.link.rx(oscFromHex(hex), now);
        if (!m) return;
        if (m.cmd === OSC.CONTROL) osc.surface.control(m);
        else if (m.cmd === OSC.TEMPO_TAP) osc.surface.tempoTap(m.tempoX100);
        host.requestFlush();
    });

    osc.link.hello(oscNow());
    oscTimer();
    println('SMK-37 Oscuro: waiting for Oscuro firmware (HELLO sent)');
}

function oscTimer() {
    var now = oscNow(), s = osc.surface;
    osc.link.tick(now);
    s.poll(now);
    if (osc.link.state === 'up') {
        s.renderPosition();
        s.renderMeters();
        osc.link.flush(now);
    }
    host.scheduleTask(oscTimer, 100);
}

// Bitwig calls this on every change (a modulated value changes all the time): render, but send only the cell of a knob
// just turned; everything else goes out from oscTimer in budgeted batches.
function flush() {
    if (!osc.link || osc.link.state !== 'up') return;
    osc.surface.render();
    var now = oscNow(), f = osc.surface.fast;                // a knob's cell stays "fast" for 300 ms: Bitwig applies the turn later
    osc.surface.fast = f = f.filter(function (e) { return e.until > now; });
    if (f.length)
        osc.link.flush(now, 1e9, f.map(function (e) { return e.k; }));
}

function exit() {
    if (osc.link) osc.link.bye();
}
