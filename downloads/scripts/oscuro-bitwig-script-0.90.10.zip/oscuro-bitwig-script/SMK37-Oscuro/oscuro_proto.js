// Oscuro DAW protocol v1 codec (docs/DAW_PROTOCOL.md; firmware/core/midi/ks_dawproto.c is the reference).
// Pure functions, no Bitwig API: the node tests load this file as it is.
//
// Framing: F0 7D 4B 53 01 <cmd> <payload> F7. u14 = low 7 bits first; str = length + printable ASCII.

var OSC = {
    HDR: [0x7D, 0x4B, 0x53, 0x01],
    VERSION: 1,
    // host -> device
    HELLO: 0x01, PING: 0x03, BYE: 0x05, CLAIM: 0x10, PAD: 0x20, PADS: 0x21, BUTTON_LED: 0x22,
    CELL_NAME: 0x30, CELL_VALUE: 0x31, TRACK: 0x32, CELL_MOD: 0x33,
    TRANSPORT: 0x40, SCALE: 0x41, PROJECT: 0x42, METERS: 0x44,
    NOTIFY: 0x50, MODE: 0x60, SET_ACCENT: 0x61, HEADER: 0x62, LIST: 0x63, LIST_ROW: 0x64, TABS: 0x65,
    // device -> host
    HELLO_ACK: 0x02, CONTROL: 0x70, TEMPO_TAP: 0x71, SCALE_CHANGED: 0x72, COMMAND: 0x73,
    // resource classes
    RES_PAD: 0, RES_KNOB: 1, RES_FADER: 2, RES_BUTTON: 3, RES_MOD: 4,
    MOD_SHIFT: 0x01, MOD_OCT: 0x02,
    // cells
    CELL_KNOB: 0, CELL_FADER: 16, CELL_PAD: 24,
    CELL_HAS_COLOR: 0x01, CELL_BAR_UNI: 0x02, CELL_BAR_BI: 0x04, CELL_DISABLED: 0x08, CELL_SHOW_MOD: 0x10,
    // TRACK flags
    TRK_EXISTS: 1, TRK_SELECTED: 2, TRK_MUTE: 4, TRK_SOLO: 8, TRK_ARMED: 16, TRK_GROUP: 32, TRK_IN_GROUP: 64,
    // TRANSPORT flags
    TR_PLAYING: 1, TR_RECORDING: 2, TR_LOOP: 4, TR_PUNCH_IN: 8, TR_PUNCH_OUT: 16, TR_METRONOME: 32,
    TR_AUTOMATION: 64, TR_OVERDUB: 128, TR_COUNT_IN: 256,
    // MODE ids
    MODE_DEVICE: 3, MODE_MIXER: 4, MODE_OVERVIEW: 6, MODE_BROWSER: 7,
    // pad animation
    SOLID: 0, PULSE: 1, BLINK: 2,
    // LIST_ROW flags
    ROW_COLOR: 1, ROW_SELECTED: 2,
    // HELLO_ACK caps
    CAP_RGB_PADS: 1 << 0, CAP_DISPLAY: 1 << 1, CAP_SCALE_SYNC: 1 << 3, CAP_NOTIFY: 1 << 4, CAP_SHIFT_PAD: 1 << 6,
    CAP_ACCENT: 1 << 7, CAP_HEADER: 1 << 8, CAP_VIEWS: 1 << 9, CAP_CELL_V1: 1 << 10, CAP_METERS: 1 << 11,
    CAP_LISTS: 1 << 12, CAP_PROJECT: 1 << 13, CAP_OCT_MOD: 1 << 14, CAP_TABS: 1 << 15,
    // ks_button_t order (firmware/core/control/ks_event.h)
    BTN: { KNOB_BANK: 0, FADER_BANK: 1, LEFT: 2, RIGHT: 3, OCT_DOWN: 4, OCT_UP: 5, ARP: 6, NOTE_REPEAT: 7, SCALE: 8,
           CHORD: 9, GLOBE: 10, BT: 11, PATCH: 12, PARA: 13, FX: 14, SEQ: 15, SEQ_PLAY: 16, SEQ_REC: 17 },
    NAME_LEN: 24, NOTIFY_LEN: 48
};

function oscClamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

function oscU7(v) { return oscClamp(Math.round(v), 0, 127) & 0x7F; }

function oscU14(v) { v = oscClamp(Math.round(v), 0, 16383); return [v & 0x7F, (v >> 7) & 0x7F]; }

function oscRgb(c) { return [oscU7(c[0]), oscU7(c[1]), oscU7(c[2])]; }

// Printable ASCII only: common accents lose their marks, anything else becomes '?' (the device does the same).
function oscAscii(s, max) {
    s = String(s === undefined || s === null ? '' : s);
    if (s.normalize)
        s = s.normalize('NFD').replace(/[̀-ͯ]/g, '');
    var out = [];
    for (var i = 0; i < s.length && out.length < max; i++) {
        var c = s.charCodeAt(i);
        if (c === 0x2013 || c === 0x2014) c = 0x2D;          // dashes
        else if (c === 0x2018 || c === 0x2019) c = 0x27;     // quotes
        else if (c === 0x00B0) c = 0x2A;                     // degree (no glyph): '*'
        out.push(c >= 0x20 && c <= 0x7E ? c : 0x3F);
    }
    return out;
}

function oscStr(s, max) { var b = oscAscii(s, max || OSC.NAME_LEN); return [b.length].concat(b); }

// A complete message as a byte array (with F0 / F7).
function oscMsg(cmd, payload) { return [0xF0].concat(OSC.HDR, [cmd], payload || [], [0xF7]); }

function oscHex(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++)
        s += (bytes[i] < 16 ? '0' : '') + bytes[i].toString(16).toUpperCase();
    return s;
}

var OscEnc = {
    hello: function (kind, name) { return oscMsg(OSC.HELLO, [OSC.VERSION, kind].concat(oscStr(name))); },
    ping: function () { return oscMsg(OSC.PING); },
    bye: function () { return oscMsg(OSC.BYE); },
    claim: function (cls, mask) {
        var p = [cls];
        for (var i = 0; i < 5; i++) p.push(Math.floor(mask / Math.pow(2, 7 * i)) & 0x7F);
        return oscMsg(OSC.CLAIM, p);
    },
    // lights: [{rgb:[r,g,b], anim}]; at most 16 per message
    pads: function (first, lights) {
        var p = [first, lights.length];
        for (var i = 0; i < lights.length; i++) p = p.concat(oscRgb(lights[i].rgb), [lights[i].anim & 0x7F]);
        return oscMsg(OSC.PADS, p);
    },
    buttonLed: function (button, state) { return oscMsg(OSC.BUTTON_LED, [button, state & 3]); },
    cellName: function (target, flags, rgb, name) {
        return oscMsg(OSC.CELL_NAME, [target, flags & 0x7F].concat(oscRgb(rgb || [0, 0, 0]), oscStr(name)));
    },
    cellValue: function (target, value14, text) { return oscMsg(OSC.CELL_VALUE, [target].concat(oscU14(value14), oscStr(text))); },
    cellMod: function (target, value14) { return oscMsg(OSC.CELL_MOD, [target].concat(oscU14(value14))); },
    track: function (slot, flags, rgb, name) {
        return oscMsg(OSC.TRACK, [slot, flags & 0x7F].concat(oscRgb(rgb || [0, 0, 0]), oscStr(name)));
    },
    transport: function (flags, tempoX100) {
        var t = oscClamp(Math.round(tempoX100), 0, 2097151);
        return oscMsg(OSC.TRANSPORT, oscU14(flags).concat([t & 0x7F, (t >> 7) & 0x7F, (t >> 14) & 0x7F]));
    },
    scale: function (flags, root, mask, name) { return oscMsg(OSC.SCALE, [flags, root % 12].concat(oscU14(mask & 0xFFF), oscStr(name))); },
    project: function (bar, beat, sixteenth, num, den, name) {
        return oscMsg(OSC.PROJECT, oscU14(bar).concat([oscU7(beat), oscU7(sixteenth), oscU7(num), oscU7(den)], oscStr(name)));
    },
    meters: function (first, levels) { return oscMsg(OSC.METERS, [first, levels.length].concat(levels.map(oscU7))); },
    notify: function (priority, timeout100ms, text) {
        return oscMsg(OSC.NOTIFY, [priority, oscU7(timeout100ms)].concat(oscStr(text, OSC.NOTIFY_LEN)));
    },
    mode: function (mode, title) { return oscMsg(OSC.MODE, [mode].concat(oscStr(title))); },
    accent: function (rgb) { return oscMsg(OSC.SET_ACCENT, oscRgb(rgb)); },
    header: function (left, right) { return oscMsg(OSC.HEADER, oscStr(left).concat(oscStr(right))); },
    // the remote-control pages either side of the current one (v1, caps bit 15); index 0-based, '' where there is none
    tabs: function (index, count, prev, cur, next) {
        return oscMsg(OSC.TABS, [oscU7(index), oscU7(count)].concat(oscStr(prev), oscStr(cur), oscStr(next)));
    },
    list: function (id, total, selected, title) { return oscMsg(OSC.LIST, [id].concat(oscU14(total), oscU14(selected), oscStr(title))); },
    listRow: function (row, index, flags, rgb, text) {
        return oscMsg(OSC.LIST_ROW, [row].concat(oscU14(index), [flags & 0x7F], oscRgb(rgb || [0, 0, 0]), oscStr(text)));
    }
};

// Device -> host. 'data' is the SysEx with or without F0/F7. Returns null if it is not ours.
function oscDecode(data) {
    var b = Array.prototype.slice.call(data);
    if (b[0] === 0xF0) b = b.slice(1);
    if (b[b.length - 1] === 0xF7) b = b.slice(0, -1);
    if (b.length < 5 || b[0] !== 0x7D || b[1] !== 0x4B || b[2] !== 0x53 || b[3] !== 0x01) return null;
    var cmd = b[4], p = b.slice(5);
    var u14 = function (i) { return p[i] | (p[i + 1] << 7); };
    switch (cmd) {
    case OSC.HELLO_ACK: {
        if (p.length < 15) return null;
        var caps = u14(4) + (p.length >= 17 ? u14(15) * 16384 : 0);
        return { cmd: cmd, ver: p[0], fw: [p[1], p[2], p[3]], caps: caps, pads: p[6], padBanks: p[7], knobs: p[8],
                 knobBanks: p[9], faders: p[10], faderBanks: p[11], width: p[12] * 8, height: p[13] * 8, shiftPad: p[14] };
    }
    case OSC.CONTROL: {
        if (p.length < 6) return null;
        var raw = u14(2);
        var signed = raw >= 8192 ? raw - 16384 : raw;
        return { cmd: cmd, cls: p[0], index: p[1], value: p[0] === OSC.RES_KNOB ? signed : raw, extra: p[4], mods: p[5] };
    }
    case OSC.TEMPO_TAP:
        return { cmd: cmd, tempoX100: p[0] | (p[1] << 7) | (p[2] << 14) };
    case OSC.SCALE_CHANGED:
        return { cmd: cmd, flags: p[0], root: p[1], mask: u14(2), scaleId: p[4] };
    case OSC.COMMAND:
        return { cmd: cmd, id: p[0] };
    default:
        return { cmd: cmd };
    }
}

// Hex string (Bitwig's SysEx callback) -> byte array.
function oscFromHex(hex) {
    var out = [];
    for (var i = 0; i + 1 < hex.length; i += 2) out.push(parseInt(hex.substr(i, 2), 16));
    return out;
}

if (typeof module !== 'undefined')
    module.exports = { OSC: OSC, OscEnc: OscEnc, oscDecode: oscDecode, oscHex: oscHex, oscFromHex: oscFromHex, oscAscii: oscAscii };
