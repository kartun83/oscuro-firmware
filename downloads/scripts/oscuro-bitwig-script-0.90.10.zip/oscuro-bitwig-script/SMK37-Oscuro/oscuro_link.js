// Oscuro DAW session: HELLO / HELLO_ACK, keepalive, and an outbox that sends the latest message per key.
// No Bitwig objects beyond the MIDI out port and the scheduler passed in, so node tests can drive it.
//
// Views render their whole state on every flush; send(key, bytes) drops a message that equals the last one sent
// under the same key, so only what changed goes out. On a new session (HELLO_ACK) the cache is cleared and the
// owner re-renders everything.
//
// Sending is paced: flush(now) sends at most 'budget' bytes (default OSC_BUDGET; Bluetooth wants less) and leaves the
// rest queued for the next call, so a burst of changes (a modulated parameter moves all the time) cannot flood the
// port and make the keepalive late. Order: session, names, header and lights of the structure first (priority 0), then
// values (1), then modulation ticks (2). Raw messages (HELLO, PING, claims, notices) bypass the budget.

var OSC_BUDGET = 300;           // bytes per flush (the script flushes every 100 ms)
var OSC_MOD_MS = 100;           // least time between two ticks of one modulated cell

// 0 = structure (names, header, mode, tracks, lists, notices), 1 = values and lights, 2 = modulation ticks
function oscPriority(key) {
    if (key.indexOf('cm') === 0) return 2;
    if (key.indexOf('cv') === 0 || key.indexOf('bl') === 0 || key === 'pads' || key === 'meters' || key === 'transport' || key === 'project')
        return 1;
    return 0;
}

function OscLink(out, opts) {
    this.out = out;                  // { sendSysex(hexString) }
    this.opts = opts || {};
    this.state = 'idle';             // idle -> hello -> up
    this.caps = 0;
    this.info = null;                // the decoded HELLO_ACK
    this.sent = {};                  // key -> hex of the last message sent
    this.queue = [];                 // [key, hex] in order, waiting for flush()
    this.queued = {};                // key -> index in queue
    this.budget = OSC_BUDGET;
    this.modV = {};                  // 'cm' key -> the 7-bit value last queued
    this.modT = {};                  // 'cm' key -> when a tick last went out
    this.lastHello = -1e9;
    this.lastTx = 0;
    this.onSession = null;           // called with the HELLO_ACK info when a session starts (or restarts)
    this.onLost = null;
}

OscLink.prototype.has = function (cap) { return this.state === 'up' && (this.caps & cap) !== 0; };

OscLink.prototype.hello = function (now) {
    this.state = 'hello';
    this.lastHello = now;
    this.raw(OscEnc.hello(1, this.opts.name || 'Bitwig'));
};

// Send at once, outside the outbox (session messages).
OscLink.prototype.raw = function (bytes) {
    this.out.sendSysex(oscHex(bytes));
};

// Queue 'bytes' under 'key'; a later send with the same key before flush() replaces it.
OscLink.prototype.send = function (key, bytes) {
    if (this.state !== 'up')
        return;
    var hex = oscHex(bytes);
    if (key.indexOf('cn') === 0 && this.sent[key] !== hex)
        delete this.modV['cm' + key.substr(2)];             // a new parameter in the cell: its first tick goes out
    if (this.sent[key] === hex && !(key in this.queued))
        return;
    if (key in this.queued) {
        this.queue[this.queued[key]][1] = hex;
        return;
    }
    this.queued[key] = this.queue.length;
    this.queue.push([key, hex]);
};

// A modulation tick for a cell: queued only when the 7-bit value differs from the last one queued (the device draws
// a tick on a short arc, finer values change nothing it can show).
OscLink.prototype.sendMod = function (key, target, value14) {
    if (this.state !== 'up')
        return;
    var v = Math.max(0, Math.min(16383, Math.round(value14))), v7 = v >> 7;
    if (this.modV[key] === v7)
        return;
    this.modV[key] = v7;
    this.send(key, OscEnc.cellMod(target, v));
};

// Forget what was sent under keys starting with 'prefix' (they go out again on the next render).
OscLink.prototype.forget = function (prefix) {
    for (var k in this.sent)
        if (k.indexOf(prefix) === 0)
            delete this.sent[k];
};

// Send what changed, within 'budget' bytes (default this.budget), in priority order; the rest stays queued. 'only' (a
// list of keys) limits the pass to those keys: a knob's own cell, sent at once without waiting for the timer.
OscLink.prototype.flush = function (now, budget, only) {
    var q = this.queue, left = budget === undefined ? this.budget : budget, full = left, i, p;
    var done = {};
    for (p = 0; p < 3; p++)
        for (i = 0; i < q.length; i++) {
            var key = q[i][0], hex = q[i][1];
            if (oscPriority(key) !== p || (only && only.indexOf(key) < 0))
                continue;
            if (this.sent[key] === hex) { done[i] = 1; continue; }
            if (left < hex.length / 2 && !(left === full && full > 0))   // does not fit this time (but one bigger than the whole budget goes alone)
                continue;
            if (p === 2 && now - (this.modT[key] === undefined ? -1e9 : this.modT[key]) < OSC_MOD_MS)
                continue;
            this.out.sendSysex(hex);
            this.sent[key] = hex;
            this.lastTx = now;
            if (p === 2) this.modT[key] = now;
            left -= hex.length / 2;
            done[i] = 1;
        }
    this.queue = [];
    this.queued = {};
    for (i = 0; i < q.length; i++)
        if (!done[i]) {
            this.queued[q[i][0]] = this.queue.length;
            this.queue.push(q[i]);
        }
};

// Every ~250 ms: HELLO again while unanswered (1 s), PING while up (500 ms; the device drops us after 2 s).
OscLink.prototype.tick = function (now) {
    if (this.state === 'hello' && now - this.lastHello >= 1000)
        this.hello(now);
    else if (this.state === 'up' && now - this.lastTx >= 500) {
        this.raw(OscEnc.ping());
        this.lastTx = now;
    }
};

// A SysEx from the device. Returns the decoded message (or null).
OscLink.prototype.rx = function (bytes, now) {
    var m = oscDecode(bytes);
    if (!m)
        return null;
    if (m.cmd === OSC.HELLO_ACK) {
        if (this.state !== 'hello') {
            // the device answered a PING without a session (it restarted): start a new one
            this.hello(now);
            return m;
        }
        this.state = 'up';
        this.info = m;
        this.caps = m.caps;
        this.sent = {};
        this.modV = {};
        this.modT = {};
        this.queue = [];
        this.queued = {};
        this.lastTx = now;
        if (this.onSession)
            this.onSession(m);
    }
    return m;
};

OscLink.prototype.bye = function () {
    if (this.state === 'up')
        this.raw(OscEnc.bye());
    this.state = 'idle';
};

if (typeof module !== 'undefined')
    module.exports = { OscLink: OscLink };
