# SMK-37 Oscuro: Bitwig Studio controller script

For an M-Vave SMK-37 Elite (or its twins) running **Oscuro firmware** with the DAW protocol. The DAW and DAW BT builds draw the Mixer, Overview and Browser screens; the other Oscuro builds get the knob names, values and pad lights.

On **M-Vave's own firmware** keep using the stock `SMK37-Elite` script (M-Vave repository). Both scripts can be installed side by side; this one does nothing until Oscuro firmware answers.

Status: tested against a fake Bitwig API and the firmware's protocol decoder (`make check-bitwig` in the repository root); **not yet run in Bitwig with a keyboard.**

## Install

1. Copy this folder (`SMK37-Oscuro`, without `tests/`) to `~/Documents/Bitwig Studio/Controller Scripts/` (macOS), `%USERPROFILE%\Documents\Bitwig Studio\Controller Scripts\` (Windows) or `~/Bitwig Studio/Controller Scripts/` (Linux).
2. Bitwig: *Settings → Controllers → Add controller → Oscuro → SMK-37 Oscuro*. Input and output: **SMK-37 Oscuro USB** (with *USB ports: Split* on the keyboard, use the **DAW** port here and add the Keys / Pads ports as ordinary MIDI keyboards), or **SMK-37 Oscuro BLE** over Bluetooth.
3. Needs **Bitwig Studio 6.1 or newer** (controller API 25). Older versions are not supported; Bitwig shows "SMK-37 Oscuro needs Bitwig Studio 6.1 or newer" and the script does not start.

## Using it

| Control | Device view | Mixer view | Overview | Browser |
|---|---|---|---|---|
| K1–K8 | the selected device's remote page | pan of 8 tracks | project remotes | K1 results, K2 category, K3 creator, K4 type |
| K9–K16 (Knob Bank B) | the track's remote page | send 1 of 8 tracks | tempo, shuffle, click, loop start, loop length, position, —, master | — |
| Left / Right | remote page | move the 4-fader window (then the bank) | one bar back / forward | cancel / confirm |
| Oct- + Left / Right | previous / next device | track bank by 8 | 4 bars | — |

Everywhere:

- **SEQ** tap: Device → Mixer → Overview. **Hold SEQ**: the browser (replace the device; with Oct- held, insert after it).
- **Faders 1–4**: volumes of the 4 tracks in the window (labelled F1–F4 on the Mixer screen). **Fader Bank B**: the selected track's volume, pan, send 1, send 2. Soft takeover: a fader does nothing until it reaches the value; an arrow beside the fader on the Mixer screen says which way to move it (up or down). The Mixer follows the track you select in Bitwig: the bank scrolls to it and the fader window is the half it sits in.
- **Mixer screen:** the selected track has a white frame and its name inverted; a group track has a taller colour bar, and a line in the group's colour runs over the group and the tracks inside it, whose colour bars are short and inset. Squares under each strip: mute yellow, solo blue, arm red.
- **Mod wheel drift:** if CC 1 keeps flipping by one step with nobody on the wheel (8 times in 30 s), the keyboard says once "Mod wheel 125/126 jitters: calibrate Wheels" (Settings → Physical Controls → Wheels). It works only when the wheel's CC 1 reaches the script's MIDI in port, that is when that port also carries the keys (always on Bluetooth).
- **Pad bank B**, top row: select a track (lit in its colour). **In the Overview view the bottom row is the transport instead**: Stop, Play, Rec, Loop, Metronome, previous cue marker, next cue marker, add a cue marker at the playhead; the switches (Play, Rec, Loop, Metro) are bright while on. Which function sits on which pad is a plain list in `oscuro_pads.config.js` (names from `oscuro_pads.js`: Stop, Play, Rec, Loop, Metro, Punch in, Punch out, Overdub, Tap, Cue <, Cue >, Cue +, Undo, Redo); edit it and restart the script. Hold **Oct-** (Settings → Display → Hints on) and the keyboard shows all 16 pad names in the pads' colours. Bottom row: mute, solo, arm, stop or launch for the same 8 tracks; **Oct- + bottom pad 1–5** picks which (hold the Shift pad to see the choice lit). **Oct- + top pad** 1 / 2 track bank back / forward, 3 / 4 scene up / down, 8 launch the scene. Pad bank A stays notes (and the Harmony Helper).
- **Device pads** (Device view only): when the selected device has on/off parameters on its current remote page or the next, pad bank B toggles them instead of the tracks: top row = this page's 8 controls, bottom row = the next page's, lit in Bitwig orange (bright = on); other slots stay dark. The header adds "| pads" and the screen says "Pads: <device> switches" once when they appear. The Mixer and Overview views, and devices without switches, keep the track pads; Oct- / Shift chords keep their meaning everywhere. Turning a switch on writes automation like a knob.
- **Drum pads and steps** (Device view only): a selected Drum Machine takes pad bank B; so does the track's first instrument if it is a Drum Machine when the selected device has no switches for device pads. **Drum pads**: top row = 8 pads from C1 in their colours, the selected one bright; a tap selects the pad, **hold one half a second for its steps**. Bottom row = mute of those pads (solo when the track sub-mode is solo). **Oct- + Left / Right** moves the 8-pad window. **Steps**: both rows are the 16 sixteenths of that pad in the launcher clip shown in the editor (a 1-bar clip is made if there is none); the playing step is white. Press an empty step: a note. Press a note and let go: removed, unless you turned a knob while holding it: **K1 velocity, K2 length, K3 chance, K4 repeats, K5 occurrence** (Always, First, Not first, Prev, Not prev, Prev channel, Not prev channel, Prev key, Not prev key, Fill, Not fill; one entry per click, anything but Always switches it on), **K6 recurrence** (off, 2 to 8 cycles; plays on the first cycle only), **K7 timbre, K8 pressure** (Oct- + K8 stays the tempo; turns on a note Bitwig has not shown yet are ignored). Left / Right: the next 16 steps (the step grid is never scrolled, so long clips up to 128 steps stay in step with the playhead; a first step with no clip to write to says "No clip to write to: select a slot" after 2 seconds); Oct- + Left / Right: the previous / next pad; **Shift pad + Left**: back to the pads. The screen says "Pads: <device> drum pads (hold one: steps)" once; the header shows the pad range or "Steps 1-16/16".
- **Key lanes** (Device view, any track that holds notes, track pads showing): **Shift pad + Right** opens the same 16 steps for one key, C3 at first (the last key is remembered). Notes light in the track's colour; the header shows the note and "Steps 1-16/16"; the screen says "Steps: <track> key C3 (Oct- + Left/Right: key)" once. Edit steps and K1-K8 exactly as with drums. **Oct- + Left / Right** moves the key by a semitone; **Shift pad + Left** closes it, as do changing track and leaving the Device view. A selected Drum Machine keeps the drum pads.
- **SEQ PLAY** play / stop (Oct-: stop and back to the start). **SEQ REC** record (Oct-: launcher overdub). **Oct- + SEQ** tap metronome (Oct- + hold SEQ: the browser, inserting after the device). **Oct- + K8** tempo.
- Turning a knob "touches" its parameter, so Bitwig records automation in Touch mode. Holding Oct- (or the Shift pad) while turning gives fine steps.
- Globe, PATCH (Harmony Helper), ARP, SCALE, CHORD, Note Repeat, the octave and bank buttons stay the keyboard's. While one of its pages is open, the knobs and Left / Right belong to that page.

## Preferences

SEQ button (screen views or the keyboard's sequencer), show modulation, accent colour (Bitwig orange or the keyboard's setting), follow Bitwig panel (opening Bitwig's Mix panel shows the Mixer view, leaving it returns to Device), fader pick-up (soft takeover or jump), knob steps, connection (USB or Bluetooth: how many bytes the script sends per 100 ms, about 300 or 120). The script sends only from a 100 ms timer within that budget (names and header first, values next, modulation ticks last), so a fast knob turn or an LFO cannot flood the port; a knob you turn still updates its own cell at once.

## Files

`SMK37-Oscuro.control.js` (Bitwig objects, preferences), `oscuro_proto.js` (the protocol, `docs/DAW_PROTOCOL.md`), `oscuro_link.js` (session, paced outbox), `oscuro_drums.js` (drum pads, steps), `oscuro_surface.js` (views and controls). Tests: `tests/` (`node tests/test_surface.js`).
