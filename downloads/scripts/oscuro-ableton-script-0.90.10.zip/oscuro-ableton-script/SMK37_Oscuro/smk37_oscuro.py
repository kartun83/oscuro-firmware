# Live glue: the raw MIDI Remote Script interface Live calls (c_instance), the 100 ms display timer, and the
# Application object. Everything else lives in oscuro_link / oscuro_surface, which the host tests run without Live.
from __future__ import absolute_import, division, print_function, unicode_literals

import time

from . import oscuro_proto as P
from .oscuro_link import OscLink
from .oscuro_surface import OscSurface
from . import user_settings

NOT_FOUND_MS = 3000
MIN_LIVE = 12                   # the script targets the current Live; older versions get a message and nothing else
TOO_OLD = 'SMK37 Oscuro needs Live %d or newer' % MIN_LIVE


def _application():
    try:
        import Live  # noqa: F401 - only inside Live
        return Live.Application.get_application()
    except Exception:  # noqa: BLE001 - outside Live (tests) or an API change
        return None


class SMK37Oscuro(object):
    """One instance per control-surface slot in Live's settings."""

    def __init__(self, c_instance, app=None, clock=None):
        self._c = c_instance
        self._clock = clock or (lambda: int(time.time() * 1000))
        self._told = False
        self._errors = set()
        app = app if app is not None else _application()
        self.too_old = app is not None and app.get_major_version() < MIN_LIVE
        self.link = OscLink(self._send, 'Live', user_settings.SETTINGS.get('flush_budget', 300))
        self.surface = OscSurface(c_instance.song(), app, self.link, user_settings.SETTINGS, self._clock, self._log)
        if self.too_old:
            c_instance.show_message(TOO_OLD)
            self._log(TOO_OLD)
            return
        self.link.hello(self._clock())

    # ---- what Live calls --------------------------------------------------------------------------------------

    def disconnect(self):
        if self.too_old:
            return
        self.surface.disconnect()
        self.link.bye()

    def connect_script_instances(self, instances):
        pass

    def can_lock_to_devices(self):
        return False

    def suggest_input_port(self):
        return ''

    def suggest_output_port(self):
        return ''

    def suggest_map_mode(self, cc_no, channel):
        return -1

    def request_rebuild_midi_map(self):
        self._c.request_rebuild_midi_map()

    def build_midi_map(self, midi_map_handle):
        pass                                                # SysEx reaches receive_midi without a map

    def refresh_state(self):
        if self.link.state == 'up':
            self.link.sent = {}                             # Live asks for a full refresh: send everything again
            self._pass()

    def update_display(self):
        """Live's timer, about every 100 ms."""
        if self.too_old:
            return
        now = self._clock()
        self.link.tick(now)
        if self.link.state == 'hello' and not self._told and now - self.link.first_hello >= NOT_FOUND_MS:
            self._told = True
            self._c.show_message('SMK37 Oscuro: Oscuro firmware not found - use the stock SMK37 script')
        try:
            self.surface.poll(now)
            self.surface.render_position()
            self.surface.render_meters()
        except Exception as e:  # noqa: BLE001 - logged once; the timer keeps running
            self._error('update', e)
        self._pass()

    def receive_midi(self, midi_bytes):
        if self.too_old or not midi_bytes or midi_bytes[0] != 0xF0:
            return
        now = self._clock()
        m = self.link.rx(midi_bytes, now)
        if m is None:
            return
        cmd = m['cmd']
        try:
            if cmd == P.CONTROL:
                self.surface.control(m)
            elif cmd == P.TEMPO_TAP:
                self.surface.tempo_tap(m['tempo_x100'])
            elif cmd == P.COMMAND:
                self.surface.command(m['id'])
        except Exception as e:  # noqa: BLE001 - one bad event must not stop the script
            self._error('while handling %r' % (m,), e)
        self._pass()

    # ---- helpers ----------------------------------------------------------------------------------------------

    def _pass(self):
        try:
            self.surface.render()
        except Exception as e:  # noqa: BLE001 - what was queued still goes out
            self._error('render', e)
        self.link.flush(self._clock())

    def _error(self, where, e):
        """Log an error once per kind (Live's timer would otherwise repeat it ten times a second)."""
        key = '%s %s' % (where.split(' ')[0], type(e).__name__)
        if key not in self._errors:
            self._errors.add(key)
            self._log('SMK37 Oscuro: %r %s' % (e, where))

    def _send(self, m):
        self._c.send_midi(tuple(m))

    def _log(self, s):
        try:
            self._c.log_message(s)
        except Exception:  # noqa: BLE001
            pass
