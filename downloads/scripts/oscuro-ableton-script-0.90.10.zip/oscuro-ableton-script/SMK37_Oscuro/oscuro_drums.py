# Drum pads and the 16-step sequencer on pad bank B (docs/design/2026-11-25-daw-device-integration.md, items 2-3).
#
# Active in the Device view when the selected device is a Drum Rack, or (when the selected device has no switches
# for device pads) when the selected track has one. Two pages:
#   pads   top row = 8 drum pads of the window (from C1), lit in their chain colour, the lane bright; a tap selects the
#          pad (Live follows), a hold (half a second) opens its steps. Bottom row = mute of those pads (solo when the
#          track sub-mode is solo). Oct- + Left / Right moves the window by 8; plain Left / Right stay the knob banks.
#   steps  (a key lane, 'keys' source: the same page for one key of the selected MIDI track, opened with Shift pad +
#          Right while the track pads show; Oct- + Left / Right moves the key by a semitone; Shift pad + Left closes)
#          both rows = 16 sixteenths of the lane in the clip of the selected track and scene (a 1-bar clip is made on
#          the first step). Press an empty step: a note; press a note and let go: removed, unless a knob turned while
#          it was held: K1 velocity, K2 length, K3 probability, K4 velocity range, K5 mute, K6 release velocity. Left / Right: the 16-step page;
#          Oct- + Left / Right: the previous / next drum pad; Shift pad + Left: back to the pads.
from __future__ import absolute_import, division, print_function, unicode_literals

from . import oscuro_proto as P

try:  # pragma: no cover - only inside Live
    import Live
except ImportError:  # the host tests
    Live = None

STEP = 0.25                     # a sixteenth, in beats
STEPS = 16
HOLD_MS = 500
FIRST_NOTE = 36                 # C1: where Drum Racks start
NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
MUTE_RGB, SOLO_RGB = (127, 100, 0), (20, 70, 127)


def note_name(n):
    return '%s%d' % (NOTE_NAMES[n % 12], n // 12 - 2)


def note_spec(pitch, start, duration, velocity):
    if Live is not None:
        return Live.Clip.MidiNoteSpecification(pitch=pitch, start_time=start, duration=duration, velocity=velocity,
                                               mute=False)
    return dict(pitch=pitch, start_time=start, duration=duration, velocity=velocity, mute=False)


def _rgb7(color):
    return ((color >> 16 & 0xFF) >> 1, (color >> 8 & 0xFF) >> 1, (color & 0xFF) >> 1)


def _dim(c, f):
    return (c[0] * f, c[1] * f, c[2] * f)


class Drums(object):
    def __init__(self, surface):
        self.s = surface
        self.page = 'pads'
        self.source = 'drum'        # 'drum' (a Drum Rack lane) or 'keys' (a key of the selected MIDI track)
        self.key = 60               # the last key lane (C3), kept for the session
        self.track = None           # the track the key lane belongs to
        self.base = FIRST_NOTE      # first note of the 8-pad window
        self.lane = None            # the note the steps edit
        self.step_page = 0
        self.hold = None            # a top pad held on the pads page: {idx, t, opened}
        self.held = None            # a step held: {idx, step, had, edited}

    # ---- what is shown -----------------------------------------------------------------------------------------

    def rack(self):
        d = self.s.device()
        if d is not None and d.can_have_drum_pads:
            return d
        t = self.s.sel_track()
        for x in (t.devices if t is not None else []):
            if x.can_have_drum_pads:
                return x
        return None

    def reset(self):
        if self.source == 'keys':
            self.lane = None                                # the drum lane is picked again from the rack
        self.page, self.source, self.track, self.hold, self.held = 'pads', 'drum', None, None, None

    def open_keys(self):
        """Shift pad + Right with track pads showing: the steps of a key on the selected MIDI track."""
        t = self.s.sel_track()
        if t is None or not t.has_midi_input:
            return False
        self.source, self.track, self.page = 'keys', t, 'steps'
        self.lane, self.step_page, self.hold, self.held = self.key, 0, None, None
        return True

    def keys_open(self):
        """True while the key lane is open for the selected track; closes it otherwise (track changed, no MIDI)."""
        if self.source != 'keys':
            return False
        t = self.s.sel_track()
        if t is self.track and t is not None and t.has_midi_input:
            return True
        self.reset()
        return False

    def lane_note(self, rack):
        if self.source == 'keys':
            return self.lane
        if self.lane is None:
            p = rack.view.selected_drum_pad
            self.lane = p.note if p is not None else self.base
        return self.lane

    def lane_rgb(self, rack):
        if self.source == 'keys':
            return _rgb7(self.s.sel_track().color)
        p = rack.drum_pads[self.lane_note(rack)]
        return _rgb7(p.chains[0].color) if p.chains else self.s.accent_rgb()

    def clip(self, create=False):
        t = self.s.sel_track()
        if t is None or not t.has_midi_input:
            return None
        slot = t.clip_slots[self.s.scene_index()]
        if not slot.has_clip:
            if not create:
                return None
            slot.create_clip(self.s.bar_beats())
        c = slot.clip
        return c if c.is_midi_clip else None

    def step_time(self, c, step):
        return c.loop_start + step * STEP

    def n_steps(self, c):
        return max(1, int(round((c.loop_end - c.loop_start) / STEP))) if c is not None else STEPS

    def notes_at(self, c, step):
        return c.get_notes_extended(self.lane, 1, self.step_time(c, step), STEP)

    # ---- input -------------------------------------------------------------------------------------------------

    def press(self, idx, rack):
        i = idx - 16
        if self.page == 'pads':
            n = self.base + (i & 7)
            if n > 127:
                return
            pad = rack.drum_pads[n]
            if i < 8:
                rack.view.selected_drum_pad = pad
                self.lane = n
                self.hold = {'idx': idx, 't': self.s.clock(), 'opened': False}
            elif self.s.sub == 'solo':
                pad.solo = not pad.solo
            else:
                pad.mute = not pad.mute
            return
        self.lane_note(rack)
        c = self.clip(create=True)
        if c is None:
            self.s.notify('Steps need a MIDI track', 1, 10)
            return
        step = self.step_page * STEPS + i
        if step >= self.n_steps(c):
            return
        had = len(self.notes_at(c, step)) > 0
        if not had:
            c.add_new_notes((note_spec(self.lane, self.step_time(c, step), STEP, 100),))
        self.held = {'idx': idx, 'step': step, 'had': had, 'edited': False}

    def release(self, idx):
        """True when the release belonged to the drums."""
        if self.hold is not None and self.hold['idx'] == idx:
            self.hold = None
            return True
        h = self.held
        if h is not None and h['idx'] == idx:
            self.held = None
            if h['had'] and not h['edited']:
                c = self.clip()
                if c is not None:
                    c.remove_notes_extended(self.lane, 1, self.step_time(c, h['step']), STEP)
            return True
        return False

    def poll(self, now):
        h = self.hold
        if h is not None and not h['opened'] and now - h['t'] >= HOLD_MS:
            h['opened'] = True
            self.page, self.step_page = 'steps', 0

    def nav(self, direction, oct_, rack):
        """Left / Right on drum pages; False leaves them to the knob banks."""
        if self.page == 'pads':
            if not oct_:
                return False
            self.base = P.clamp(self.base + 8 * direction, 0, 120)
            return True
        if self.s.shift and direction < 0:
            self.reset()
            return True
        if oct_ and self.source == 'keys':
            self.lane = self.key = P.clamp(self.lane + direction, 0, 127)
            return True
        if oct_:
            self.lane = P.clamp(self.lane_note(rack) + direction, 0, 127)
            rack.view.selected_drum_pad = rack.drum_pads[self.lane]
            if not self.base <= self.lane < self.base + 8:
                self.base = P.clamp(self.lane - self.lane % 8, 0, 120)
            return True
        pages = max(1, (self.n_steps(self.clip()) + STEPS - 1) // STEPS)
        self.step_page = P.clamp(self.step_page + direction, 0, pages - 1)
        return True

    def knob(self, k, d, fine):
        """K1-K6 edit the held step's notes (K7, K8 are blank and do nothing); False when no step is held (the knobs
        stay the device's)."""
        h = self.held
        if self.page != 'steps' or h is None:
            return False
        c = self.clip()
        if c is None or k > 5:
            return True
        notes = self.notes_at(c, h['step'])
        for n in notes:
            if k == 0:
                n.velocity = P.clamp(n.velocity + d * (1 if fine else 2), 1, 127)
            elif k == 1:
                n.duration = max(STEP / 4, n.duration + d * (STEP / 4 if fine else STEP))
            elif k == 2:
                n.probability = P.clamp(n.probability + d * (0.01 if fine else 0.05), 0.0, 1.0)
            elif k == 4:
                n.mute = d > 0                              # right = muted, left = unmuted
            elif k == 5:
                n.release_velocity = P.clamp(n.release_velocity + d * (1 if fine else 2), 0, 127)
            else:
                n.velocity_deviation = P.clamp(n.velocity_deviation + d, -127, 127)
        c.apply_note_modifications(notes)
        h['edited'] = True
        return True

    # ---- render ------------------------------------------------------------------------------------------------

    def lights(self, rack):
        out = []
        lane = self.lane_note(rack)
        if self.page == 'pads':
            pads = [rack.drum_pads[n] if n <= 127 else None for n in range(self.base, self.base + 8)]
            for p in pads:
                if p is None:
                    out.append(((0, 0, 0), P.SOLID))
                elif p.chains:
                    out.append((_dim(_rgb7(p.chains[0].color), 1 if p.note == lane else 0.3), P.SOLID))
                else:
                    out.append(((30, 30, 30) if p.note == lane else (6, 6, 6), P.SOLID))
            solo = self.s.sub == 'solo'
            for p in pads:
                if p is None or not p.chains:
                    out.append(((0, 0, 0), P.SOLID))
                elif solo:
                    out.append((_dim(SOLO_RGB, 1 if p.solo else 0.12), P.SOLID))
                else:
                    out.append((_dim(MUTE_RGB, 1 if p.mute else 0.12), P.SOLID))
            return out
        c = self.clip()
        col = self.lane_rgb(rack)
        first = self.step_page * STEPS
        on, playing = {}, -1
        if c is not None:
            for n in c.get_notes_extended(lane, 1, self.step_time(c, first), STEPS * STEP):
                on[int((n.start_time - c.loop_start) / STEP + 1e-6) - first] = n.mute
            if c.is_playing:
                playing = int((c.playing_position - c.loop_start) / STEP) - first
        total = self.n_steps(c)
        for i in range(STEPS):
            if first + i >= total:
                out.append(((0, 0, 0), P.SOLID))
            elif i == playing:
                out.append(((100, 100, 100), P.SOLID))
            elif i in on:
                out.append((_dim(col, 0.3 if on[i] else 1), P.SOLID))
            else:
                out.append(((10, 10, 10), P.SOLID))
        return out

    def header(self, rack, bank_text):
        if self.source == 'keys':
            total = self.n_steps(self.clip())
            first = self.step_page * STEPS
            return P.header(note_name(self.lane), 'Steps %d-%d/%d' % (first + 1, min(first + STEPS, total), total))
        if self.page == 'pads':
            return P.header(rack.name, '%s-%s | %s' % (note_name(self.base), note_name(self.base + 7), bank_text))
        pad = rack.drum_pads[self.lane_note(rack)]
        total = self.n_steps(self.clip())
        first = self.step_page * STEPS
        return P.header(pad.name or note_name(pad.note),
                        'Steps %d-%d/%d' % (first + 1, min(first + STEPS, total), total))

    def cells(self):
        """[(name, 0..1, text)] for K1-K8 (K7, K8 blank) while a step is held, else None."""
        h = self.held
        if self.page != 'steps' or h is None:
            return None
        c = self.clip()
        notes = list(self.notes_at(c, h['step'])) if c is not None else []
        if not notes:
            return None
        n = notes[0]
        return [('Velocity', n.velocity / 127.0, '%d' % n.velocity),
                ('Length', min(1.0, n.duration / (STEPS * STEP)), '%.2g st' % (n.duration / STEP)),
                ('Chance', n.probability, '%d %%' % round(n.probability * 100)),
                ('Vel range', (n.velocity_deviation + 127) / 254.0, '%+d' % n.velocity_deviation),
                ('Mute', 1.0 if n.mute else 0.0, 'muted' if n.mute else 'on'),
                ('Rel vel', n.release_velocity / 127.0, '%d' % n.release_velocity),
                ('', 0, ''), ('', 0, '')]
