# SMK37_Oscuro: Ableton Live MIDI Remote Script for the M-Vave SMK-37 running Oscuro firmware (DAW protocol v1).
# Install: copy this folder into the User Library's "Remote Scripts" folder (see README.md).
from __future__ import absolute_import, division, print_function, unicode_literals


def create_instance(c_instance):
    from .smk37_oscuro import SMK37Oscuro
    return SMK37Oscuro(c_instance)
