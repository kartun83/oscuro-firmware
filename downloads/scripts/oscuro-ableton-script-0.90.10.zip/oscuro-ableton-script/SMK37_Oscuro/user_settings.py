# Settings of the SMK37_Oscuro script (Live has no preference panel for Remote Scripts).
# Edit and restart Live (or re-select the control surface) to apply.
SETTINGS = {
    # True: SEQ cycles Device / Mixer / Overview, hold SEQ opens the browser.
    # False: SEQ stays the keyboard's own sequencer button.
    'seq_views': True,
    # True: a fader does nothing until it reaches the value (soft takeover). False: the value jumps to the fader.
    'soft_takeover': True,
    # 'live': the screen's accent is the script's amber for the session. 'off': the keyboard's own accent.
    'accent': 'live',
    # True: 256 knob steps per range instead of 128 (holding Oct- or the Shift pad always gives 1024).
    'fine': False,
    # Bytes sent to the keyboard per pass (every 100 ms and per received message); the rest waits for the next pass.
    # The keyboard's MIDI input is small: a flood makes it answer "Host lost". Raise it only if the screen lags.
    'flush_budget': 300,
}
