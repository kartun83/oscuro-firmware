# The SMK-37 under Oscuro firmware as an Ableton Live surface (docs/design/2026-11-25-daw-ableton.md).
#
# Views (SEQ tap cycles, SEQ hold opens the browser):
#   Device    K1-K8 the appointed device's bank, K9-K16 (Knob Bank B) the selected track's Volume / Pan / Sends A-F;
#             Left/Right bank, Oct- + Left/Right previous/next device.
#   Mixer     8 track strips; K1-K8 pan, K9-K16 send A; Left/Right move the 4-fader window (then the bank).
#   Overview  tempo, position, switches; K1-K8 tempo / swing / groove / loop start / loop length / position /
#             master / cue, K9-K16 return track volumes.
#   Browser   presets of the device (hold SEQ) or the whole browser tree (Oct- + hold SEQ); also the clip actions list.
# Always: faders 1-4 = the window's 4 volumes (soft takeover), Fader Bank B = selected track volume / pan / send A / B;
# pad bank B row 1 selects tracks, row 2 = mute / solo / arm / stop / launch, or both rows a 8x2 clip launcher
# (Clips); Oct- + row-2 pads 1-6 pick, 7 stop all clips, 8 Session / Arrangement; Oct- + row-1 pads: bank, scene,
# Capture MIDI, Undo, Redo, launch scene. SEQ PLAY play/stop (Oct-: stop and back to the start), SEQ REC arrangement
# record (Oct-: session record), Oct- + SEQ metronome, Oct- + K8 tempo.
#
# Only Live objects are touched (song, application); the session is an OscLink, the clock returns ms.
from __future__ import absolute_import, division, print_function, unicode_literals

import math

from . import oscuro_proto as P
from . import live_banks
from .oscuro_devpads import DevPads, MODES as DEV_MODES
from .oscuro_drums import Drums, note_name

VIEWS = [P.MODE_DEVICE, P.MODE_MIXER, P.MODE_OVERVIEW]
TITLES = {P.MODE_DEVICE: 'Device', P.MODE_MIXER: 'Mixer', P.MODE_OVERVIEW: 'Overview', P.MODE_BROWSER: 'Browser'}
SUBS = ['mute', 'solo', 'arm', 'stop', 'launch', 'clips']
SUB_RGB = {'mute': (127, 100, 0), 'solo': (20, 70, 127), 'arm': (127, 10, 10), 'stop': (110, 110, 110),
           'launch': (20, 127, 40), 'clips': (90, 40, 127)}
ACCENT_LIVE = (127, 104, 20)   # amber: the script's fixed accent (preference accent='live')
TOUCH_MS = 500                 # a knob is "touched" (automation gesture open) until this long without movement
SEQ_HOLD_MS = 500
PAD_HOLD_MS = 500
TEMPO_MIN, TEMPO_MAX = 20.0, 999.0
LIST_MAX = 512                 # browser rows kept (big libraries are slow to walk)
LIST_BROWSER, LIST_CLIP = 1, 2
QUANT_16TH = 5                 # Live.Song.RecordingQuantization.rec_q_sixtenth

CLIP_ACTIONS = [('rec4', 'Record 4 bars'), ('rec8', 'Record 8 bars'), ('dup', 'Duplicate'), ('quant', 'Quantize'),
                ('double', 'Double loop'), ('halve', 'Halve loop'), ('delete', 'Delete')]

DEFAULT_PREFS = {
    'seq_views': True,      # SEQ cycles the screen views (False: the firmware's sequencer keeps SEQ)
    'soft_takeover': True,  # faders pick up the value (False: jump)
    'accent': 'live',       # 'live': the script's amber accent; 'off': the keyboard's own
    'fine': False,          # 256 knob steps per range instead of 128 (a modifier always gives 1024)
}


def rgb7(color):
    """Live colour (0xRRGGBB int) -> 0..127 triplet."""
    c = int(color or 0)
    return (round(((c >> 16) & 255) * 127 / 255.0), round(((c >> 8) & 255) * 127 / 255.0), round((c & 255) * 127 / 255.0))


def dim(c, f):
    return (c[0] * f, c[1] * f, c[2] * f)


def norm(p):
    """A DeviceParameter's value as 0..1."""
    span = p.max - p.min
    return (p.value - p.min) / span if span else 0.0


def ptext(p):
    try:
        return p.str_for_value(p.value)
    except Exception:  # noqa: BLE001 - older parameters only have __str__
        return '%s' % (p,)


def is_switch(p):
    """A two-state parameter (on / off, or a list of two): what device pads toggle."""
    return (p is not None and getattr(p, 'is_enabled', True) and getattr(p, 'is_quantized', False)
            and abs((p.max - p.min) - 1.0) < 1e-6)


def _index(seq, item):
    for i, x in enumerate(seq):
        if x == item:
            return i
    return -1


class OscSurface(object):
    def __init__(self, song, app, link, prefs=None, clock=None, log=None):
        self.song = song
        self.app = app               # Live.Application (browser, view); may be None in old Lives
        self.link = link
        self.prefs = dict(DEFAULT_PREFS)
        self.prefs.update(prefs or {})
        self.clock = clock
        self.log = log or (lambda s: None)
        self.view = P.MODE_DEVICE
        self.prev_view = P.MODE_DEVICE
        self.sub = 'mute'
        self.shift = False           # the Shift pad is down (CONTROL class 4)
        self.window = 0              # first strip of the fader window: 0 or 4
        self.offset = 0              # first track of the bank of 8
        self.seq_down = 0
        self.seq_oct = False
        self.seq_used = False
        self.touch = {}              # key -> [param, until]
        self.fader = [{'pos': -1.0, 'picked': False, 'val': None} for _ in range(8)]
        self.fader_toast = None
        self.dev = None              # the device the bank index belongs to
        self.bank = 0
        self.browse = None           # browser state (see open_browser)
        self.clip_menu = None        # clip actions state (see open_clip_menu)
        self.pad_hold = None         # a clip pad held down: {idx, t, track, scene}
        self._bcache = None
        self._rendering = False
        self.pmode_last = None       # the pad mode shown last pass (to tell the player once when it changes)
        self.drums = Drums(self)
        self.devpads = DevPads(self)
        link.on_session = lambda info: self.start()

    # ---- session ----------------------------------------------------------------------------------------------

    def start(self):
        L, B = self.link, P.BTN
        buttons = (1 << B.LEFT) | (1 << B.RIGHT) | (1 << B.SEQ_PLAY) | (1 << B.SEQ_REC)
        if self.prefs['seq_views']:
            buttons |= 1 << B.SEQ
        L.raw(P.claim(P.RES_KNOB, 0xFFFF))
        L.raw(P.claim(P.RES_FADER, 0xFF))
        L.raw(P.claim(P.RES_PAD, 0xFFFF0000))               # pad bank B; bank A stays notes / Harmony
        L.raw(P.claim(P.RES_BUTTON, buttons))
        L.raw(self.scale_msg())                             # the song scale
        if self.prefs['accent'] == 'off' and L.has(P.CAP_ACCENT):
            L.raw(P.accent((0, 0, 0)))                      # back to the player's own accent
        for f in self.fader:
            f['picked'] = False
        self.render()                                       # receive_midi's pass sends it, within the byte budget

    def views(self):
        return self.link.has(P.CAP_VIEWS)

    def notify(self, text, priority=1, timeout=12):
        if self.link.has(P.CAP_NOTIFY):
            self.link.raw(P.notify(priority, timeout, text))

    # ---- Live helpers -----------------------------------------------------------------------------------------

    def tracks(self):
        return list(self.song.visible_tracks)

    def bank_track(self, slot):
        t = self.tracks()
        i = self.offset + slot
        return t[i] if 0 <= slot < 8 and i < len(t) else None

    def selected_slot(self):
        i = _index(self.tracks(), self.song.view.selected_track)
        return i - self.offset if self.offset <= i < self.offset + 8 else -1

    def scene_index(self):
        i = _index(list(self.song.scenes), self.song.view.selected_scene)
        return max(i, 0)

    def bar_beats(self):
        den = self.song.signature_denominator or 4
        return self.song.signature_numerator * 4.0 / den

    def device(self):
        d = self.song.appointed_device
        if d is None:
            t = self.song.view.selected_track
            d = getattr(t.view, 'selected_device', None) if t is not None else None
        if d != self.dev or (d is None) != (self.dev is None):
            self.dev = d
            self.bank = 0
        return d

    def device_banks(self):
        d = self.device()
        c = self._bcache
        if c is not None and c[0] == d:
            return c[1]
        b = live_banks.banks(d)
        if self._rendering:
            self._bcache = (d, b)                           # one walk of the parameters per render pass
        return b

    def device_param(self, k):
        bs = self.device_banks()
        if not bs:
            return None
        self.bank = min(self.bank, len(bs) - 1)
        return bs[self.bank][1][k]

    def device_pads(self):
        """Device pads: in the Device view, pad bank B toggles the two-state parameters of the current bank (row 1)
        and the next bank (row 2). The 16 parameters (None where a slot is not a switch), or None when the device has
        no switches there and the pads stay track pads."""
        if self.view != P.MODE_DEVICE:
            return None
        bs = self.device_banks()
        if not bs:
            return None
        b = min(self.bank, len(bs) - 1)
        ps = list(bs[b][1]) + (list(bs[b + 1][1]) if b + 1 < len(bs) else [None] * 8)
        ps = [p if is_switch(p) else None for p in ps]
        return ps if any(p is not None for p in ps) else None

    def pad_mode(self):
        """What pad bank B is in the Device view, first match wins:
        'drum'       a selected Drum Rack (pads, then the steps of a pad);
        'keys'       an open key lane (Shift pad + Right on track pads: the steps of one key of the MIDI track);
        'slices'     a Simpler in Slicing mode (16 slices of a page);
        'looper'     a Looper (record / overdub / play / stop ... pads);
        'variations' a rack that is not a Drum Rack (macro variations);
        'device'     device pads (the device's on/off parameters);
        'drum'       a Drum Rack on the track (when the selected device has nothing above);
        None         track pads (always outside the Device view)."""
        if self.view != P.MODE_DEVICE:
            if self.drums.source == 'keys':
                self.drums.reset()                          # leaving the Device view closes the key lane
            return None
        d = self.device()
        if d is not None and d.can_have_drum_pads:
            if self.drums.source == 'keys':
                self.drums.reset()
            return 'drum'
        if self.drums.keys_open():
            return 'keys'
        dm = self.devpads.mode(d)
        if dm is not None:
            return dm
        if self.device_pads() is not None:
            return 'device'
        return 'drum' if self.drums.rack() is not None else None

    def accent_rgb(self):
        return ACCENT_LIVE

    def track_param(self, t, k):
        """Knob Bank B in the Device view: Volume, Pan, Sends A-F of a track."""
        if t is None:
            return None
        m = t.mixer_device
        if k == 0:
            return m.volume
        if k == 1:
            return m.panning
        sends = list(m.sends)
        return sends[k - 2] if k - 2 < len(sends) else None

    def sel_track(self):
        return self.song.view.selected_track

    # ---- input ------------------------------------------------------------------------------------------------

    def control(self, m):
        oct_ = (m['mods'] & P.MOD_OCT) != 0
        mod = oct_ or (m['mods'] & P.MOD_SHIFT) != 0
        cls = m['cls']
        if cls == P.RES_KNOB:
            self.knob(m['index'], m['value'], oct_, mod)
        elif cls == P.RES_FADER:
            self.fader_move(m['index'], m['value'] / 16383.0)
        elif cls == P.RES_PAD:
            self.pad(m['index'], m['value'], mod)
        elif cls == P.RES_BUTTON:
            self.button(m['index'], m['value'] != 0, oct_)
        elif cls == P.RES_MOD:
            self.shift = m['value'] != 0

    def tempo_tap(self, x100):
        self.song.tempo = P.clamp(x100 / 100.0, TEMPO_MIN, TEMPO_MAX)

    def command(self, cid):
        s = self.song
        if cid == P.CMD_UNDO and s.can_undo:
            s.undo()
        elif cid == P.CMD_REDO and s.can_redo:
            s.redo()
        elif cid == P.CMD_METRONOME:
            s.metronome = not s.metronome
        elif cid == P.CMD_LOOP:
            s.loop = not s.loop
        elif cid == P.CMD_PUNCH_IN:
            s.punch_in = not s.punch_in
        elif cid == P.CMD_PUNCH_OUT:
            s.punch_out = not s.punch_out
        elif cid == P.CMD_CAPTURE:
            self.capture()
        elif cid in (P.CMD_DUPLICATE, P.CMD_QUANTIZE, P.CMD_NEW_CLIP):
            t = self.sel_track()
            if t is None:
                return
            i = self.scene_index()
            if cid == P.CMD_NEW_CLIP:
                cs = t.clip_slots[i] if i < len(t.clip_slots) else None
                if cs is not None and not cs.has_clip and getattr(t, 'has_midi_input', False):
                    cs.create_clip(4 * self.bar_beats())
            else:
                self.clip_action('dup' if cid == P.CMD_DUPLICATE else 'quant', t, i)

    def capture(self):
        if getattr(self.song, 'can_capture_midi', True):
            self.song.capture_midi()
            self.notify('Capture MIDI')
        else:
            self.notify('Nothing to capture')

    def step(self, param, d, fine, key):
        """Detents -> a value step: 128 per range (256 with the 'fine' preference), 1024 with a modifier;
        quantized parameters (switches, lists) one step a detent."""
        if param is None or not getattr(param, 'is_enabled', True):
            return
        if param.is_quantized:
            v = param.value + d
        else:
            v = param.value + d * (param.max - param.min) / (1024.0 if fine else (256.0 if self.prefs['fine'] else 128.0))
        param.value = P.clamp(v, param.min, param.max)
        self.touch_param(param, key)

    def touch_param(self, param, key):
        """Open an automation gesture (Live's 'touch'); untouch() closes it TOUCH_MS after the last movement."""
        t = self.touch.get(key)
        if t is None or t[0] != param:
            if t is not None:
                self._end_gesture(t[0])
            if hasattr(param, 'begin_gesture'):
                param.begin_gesture()
            t = self.touch[key] = [param, 0]
        t[1] = self.clock() + TOUCH_MS

    def _end_gesture(self, p):
        if hasattr(p, 'end_gesture'):
            p.end_gesture()

    def untouch(self, now, everything=False):
        for k in list(self.touch):
            if everything or now >= self.touch[k][1]:
                self._end_gesture(self.touch[k][0])
                del self.touch[k]

    def knob(self, idx, d, oct_, fine):
        bank_b, k = idx >= 8, idx & 7
        if oct_ and k == 7:                                 # Oct- + K8: tempo, 1 BPM a detent (0.1 with the Shift pad)
            self.song.tempo = P.clamp(self.song.tempo + d * (0.1 if self.shift else 1.0), TEMPO_MIN, TEMPO_MAX)
            self.notify('Tempo %.2f' % self.song.tempo, 1, 8)
            return
        v = self.view
        if v == P.MODE_DEVICE:
            if not bank_b and self.pad_mode() in ('drum', 'keys') and self.drums.knob(k, d, fine):
                return
            p = self.track_param(self.sel_track(), k) if bank_b else self.device_param(k)
            self.step(p, d, fine, 'k%d' % idx)
        elif v == P.MODE_MIXER:
            t = self.bank_track(k)
            if t is not None:
                sends = list(t.mixer_device.sends)
                p = (sends[0] if sends else None) if bank_b else t.mixer_device.panning
                self.step(p, d, fine, 'm%d' % idx)
        elif v == P.MODE_OVERVIEW:
            if bank_b:
                r = list(self.song.return_tracks)
                if k < len(r):
                    self.step(r[k].mixer_device.volume, d, fine, 'r%d' % k)
            else:
                self.overview_knob(k, d, fine)
        elif v == P.MODE_BROWSER:
            self.list_knob(k, d)

    def overview_knob(self, k, d, fine):
        s = self.song
        bar = self.bar_beats()
        if k == 0:
            s.tempo = P.clamp(s.tempo + d * (0.1 if fine else 1.0), TEMPO_MIN, TEMPO_MAX)
        elif k == 1:
            s.swing_amount = P.clamp(s.swing_amount + d * (0.001 if fine else 0.01), 0.0, 1.0)
        elif k == 2:
            s.groove_amount = P.clamp(s.groove_amount + d * (0.001 if fine else 0.01), 0.0, 1.3125)
        elif k == 3:
            s.loop_start = max(0.0, s.loop_start + d * (1.0 if fine else bar))
        elif k == 4:
            s.loop_length = max(1.0, s.loop_length + d * (1.0 if fine else bar))
        elif k == 5:
            s.current_song_time = max(0.0, s.current_song_time + d * (1.0 if fine else bar))
        elif k == 6:
            self.step(s.master_track.mixer_device.volume, d, fine, 'master')
        elif k == 7:
            self.step(s.master_track.mixer_device.cue_volume, d, fine, 'cue')

    def button(self, bid, down, oct_):
        B, s = P.BTN, self.song
        if bid == B.SEQ:
            if down:
                self.seq_down = self.clock() or 1
                self.seq_oct = oct_
                self.seq_used = False
            else:
                if self.seq_down and not self.seq_used:
                    if self.seq_oct:                        # Oct- + SEQ tap: the metronome (a hold browses)
                        s.metronome = not s.metronome
                    else:
                        self.cycle_view()
                self.seq_down = 0
            return
        if not down:
            return
        if bid == B.SEQ_PLAY:
            if oct_:
                s.stop_playing()
                s.current_song_time = 0.0
            elif s.is_playing:
                s.stop_playing()
            else:
                s.start_playing()
        elif bid == B.SEQ_REC:
            if oct_:
                s.session_record = not s.session_record
            else:
                s.record_mode = not s.record_mode
        elif bid in (B.LEFT, B.RIGHT):
            self.nav(1 if bid == B.RIGHT else -1, oct_)

    def poll(self, now):
        """Called every ~100 ms: a held SEQ becomes the browser, a held clip pad the clip actions; gestures close;
        a fader whose target moved without it needs pick-up again."""
        if self.seq_down and not self.seq_used and now - self.seq_down >= SEQ_HOLD_MS:
            self.seq_used = True
            self.open_browser(self.seq_oct)
        h = self.pad_hold
        if h and not h.get('opened') and now - h['t'] >= PAD_HOLD_MS:
            h['opened'] = True
            self.open_clip_menu(h['track'], h['scene'])
        self.drums.poll(now)
        self.devpads.poll(now)
        self.untouch(now)
        for i in range(8):
            f = self.fader[i]
            p = self.fader_target(i)
            if p is None:
                continue
            v = norm(p)
            if f['picked'] and f['pos'] >= 0 and abs(f['pos'] - v) > 0.02 and ('f%d' % i) not in self.touch:
                f['picked'] = False

    def cycle_view(self):
        if self.view == P.MODE_BROWSER:
            self.close_list(False)
            return
        i = VIEWS.index(self.view) if self.view in VIEWS else -1
        self.set_view(VIEWS[(i + 1) % len(VIEWS)])

    def set_view(self, v):
        if v == self.view:
            return
        if v == P.MODE_BROWSER:
            self.prev_view = self.view
        self.view = v

    def nav(self, direction, oct_):
        s = self.song
        v = self.view
        if v == P.MODE_DEVICE:
            mode = self.pad_mode()
            if mode == 'drum' and self.drums.nav(direction, oct_, self.drums.rack()):
                return
            if mode == 'keys' and self.drums.nav(direction, oct_, None):
                return
            if mode is None and self.shift and direction > 0 and self.drums.open_keys():
                return                                      # Shift pad + Right: the steps of a key on this MIDI track
            if mode in DEV_MODES and self.devpads.nav(direction, oct_, mode):
                return
            if oct_:
                d = self.device()
                t = self.sel_track()
                devs = list(t.devices) if t is not None else []
                i = _index(devs, d)
                j = i + direction
                if i >= 0 and 0 <= j < len(devs):
                    s.view.select_device(devs[j])
            else:
                n = len(self.device_banks())
                self.bank = P.clamp(self.bank + direction, 0, max(n - 1, 0))
        elif v == P.MODE_MIXER:
            n = len(self.tracks())
            if oct_:
                self.scroll_bank(direction)
            elif direction > 0 and self.window == 0:
                self.window = 4
            elif direction < 0 and self.window == 4:
                self.window = 0
            elif direction > 0 and self.offset + 8 < n:
                self.offset += 8
                self.window = 0
            elif direction < 0 and self.offset > 0:
                self.offset = max(0, self.offset - 8)
                self.window = 4
            for i in range(4):
                self.fader[i]['picked'] = False
        elif v == P.MODE_OVERVIEW:
            s.current_song_time = max(0.0, s.current_song_time + direction * self.bar_beats() * (4 if oct_ else 1))
        elif v == P.MODE_BROWSER:
            if direction > 0:
                self.list_confirm()
            else:
                self.list_back()

    def scroll_bank(self, direction):
        n = len(self.tracks())
        to = self.offset + 8 * direction
        if 0 <= to < max(n, 1):
            self.offset = to
            for i in range(4):
                self.fader[i]['picked'] = False

    # ---- lists: the browser and the clip actions (v1 LIST in the Browser view) ---------------------------------

    def open_browser(self, insert):
        br = getattr(self.app, 'browser', None) if self.app is not None else None
        if br is None:
            self.notify('No browser in this Live version')
            return
        d = self.device()
        items = None
        if not insert and d is not None:
            items = self.preset_items(br, d)
            if items:
                br.hotswap_target = d
                self.browse = {'mode': 'presets', 'title': d.name, 'stack': [], 'items': items, 'cursor': 0}
            else:
                self.notify('No presets for %s: browsing all' % d.name)
        if not items:
            self.browse = {'mode': 'tree', 'title': 'Browser', 'stack': [], 'items': self.top_items(br), 'cursor': 0}
        self.clip_menu = None
        self.set_view(P.MODE_BROWSER)

    def top_items(self, br):
        out = []
        for attr, name in (('sounds', 'Sounds'), ('drums', 'Drums'), ('instruments', 'Instruments'),
                           ('audio_effects', 'Audio Effects'), ('midi_effects', 'MIDI Effects'),
                           ('plugins', 'Plugins'), ('user_library', 'User Library')):
            it = getattr(br, attr, None)
            if it is not None:
                out.append({'name': name, 'item': it, 'folder': True})
        return out

    def child_items(self, item):
        out = []
        for c in item.children:
            if len(out) >= LIST_MAX:
                break
            if c.is_folder or c.is_loadable:
                out.append({'name': c.name, 'item': c, 'folder': bool(c.is_folder and not c.is_loadable)})
        return out

    def preset_items(self, br, d):
        """The device's own folder in the browser (Instruments / Audio Effects / MIDI Effects / Drums), flattened."""
        want = getattr(d, 'class_display_name', None) or d.name
        for attr in ('instruments', 'audio_effects', 'midi_effects', 'drums'):
            root = getattr(br, attr, None)
            if root is None:
                continue
            for c in root.children:
                if c.name == want:
                    out = []
                    self._flatten(c, out, 0)
                    return out
        return []

    def _flatten(self, item, out, depth):
        for c in item.children:
            if len(out) >= LIST_MAX:
                return
            if c.is_loadable and not c.is_folder:
                out.append({'name': c.name, 'item': c, 'folder': False})
            elif c.is_folder and depth < 3:
                self._flatten(c, out, depth + 1)

    def open_clip_menu(self, slot, scene):
        t = self.bank_track(slot)
        if t is None or scene >= len(t.clip_slots):
            return
        self.clip_menu = {'slot': slot, 'scene': scene, 'cursor': 0, 'confirm': False}
        self.browse = None
        self.set_view(P.MODE_BROWSER)

    def list_items(self):
        if self.clip_menu is not None:
            return [{'name': n} for _, n in CLIP_ACTIONS]
        return self.browse['items'] if self.browse else []

    def list_knob(self, k, d):
        st = self.clip_menu if self.clip_menu is not None else self.browse
        if st is None or k > 1:
            return
        n = len(self.list_items())
        if n:
            st['cursor'] = P.clamp(st['cursor'] + d * (8 if k == 1 else 1), 0, n - 1)
        if self.clip_menu is not None:
            self.clip_menu['confirm'] = False

    def list_confirm(self):
        if self.clip_menu is not None:
            cm = self.clip_menu
            action = CLIP_ACTIONS[cm['cursor']][0]
            if action == 'delete' and not cm['confirm']:
                cm['confirm'] = True
                self.notify('Delete clip? Right again', 2, 20)
                return
            t = self.bank_track(cm['slot'])
            if t is not None:
                self.clip_action(action, t, cm['scene'])
            self.close_list(True)
            return
        b = self.browse
        if b is None or not b['items']:
            return
        it = b['items'][b['cursor']]
        if it['folder']:
            b['stack'].append((b['items'], b['cursor'], b['title']))
            b['items'], b['cursor'], b['title'] = self.child_items(it['item']), 0, it['name']
            return
        self.app.browser.load_item(it['item'])
        self.notify('Loaded %s' % it['name'])
        self.close_list(True)

    def list_back(self):
        b = self.browse
        if self.clip_menu is None and b is not None and b['stack']:
            b['items'], b['cursor'], b['title'] = b['stack'].pop()
            return
        self.close_list(False)

    def close_list(self, done):
        if self.browse is not None and self.browse['mode'] == 'presets' and self.app is not None:
            try:
                self.app.browser.hotswap_target = None
            except Exception:  # noqa: BLE001 - Live refuses None in some versions; nothing to undo then
                pass
        self.browse = None
        self.clip_menu = None
        self.view = self.prev_view if self.prev_view != P.MODE_BROWSER else P.MODE_DEVICE

    # ---- clips ------------------------------------------------------------------------------------------------

    def clip_action(self, action, t, scene):
        s = self.song
        if scene >= len(t.clip_slots):
            return
        cs = t.clip_slots[scene]
        clip = cs.clip if cs.has_clip else None
        if action in ('rec4', 'rec8'):
            if cs.has_clip:
                self.notify('Slot not empty')
                return
            if not getattr(t, 'can_be_armed', False):
                self.notify('This track cannot record')
                return
            if not t.arm:
                self.arm(t, True)
            cs.fire(record_length=(4 if action == 'rec4' else 8) * self.bar_beats())
        elif clip is None:
            self.notify('Empty slot')
        elif action == 'dup':
            t.duplicate_clip_slot(scene)
        elif action == 'quant':
            q = getattr(s, 'midi_recording_quantization', 0) or QUANT_16TH
            clip.quantize(q, 1.0)
        elif action == 'double':
            if clip.is_midi_clip:
                clip.duplicate_loop()
            else:
                self.notify('Double loop: MIDI clips only')
        elif action == 'halve':
            length = clip.loop_end - clip.loop_start
            if length > 1.0:
                clip.loop_end = clip.loop_start + length / 2.0
        elif action == 'delete':
            cs.delete_clip()
            self.notify('Clip deleted')

    def launch_slot(self, t, scene):
        if scene >= len(t.clip_slots):
            return
        cs = t.clip_slots[scene]
        if cs.has_clip or t.arm:
            cs.fire()                                       # an empty slot on an armed track records
        else:
            self.notify('Empty slot (arm the track to record)', 0, 10)

    # ---- faders: soft takeover --------------------------------------------------------------------------------

    def fader_target(self, i):
        if i < 4:
            t = self.bank_track(self.window + i)
            return t.mixer_device.volume if t is not None else None
        t = self.sel_track()
        if t is None:
            return None
        m = t.mixer_device
        sends = list(m.sends)
        return [m.volume, m.panning, sends[0] if sends else None, sends[1] if len(sends) > 1 else None][i - 4]

    def fader_move(self, i, pos):
        if i > 7:
            return
        f, p = self.fader[i], self.fader_target(i)
        if p is None:
            return
        v = norm(p)
        crossed = f['pos'] >= 0 and (f['pos'] - v) * (pos - v) <= 0
        if not self.prefs['soft_takeover'] or f['picked'] or abs(pos - v) < 0.02 or crossed:
            f['picked'] = True
            p.value = p.min + pos * (p.max - p.min)
            self.touch_param(p, 'f%d' % i)
        f['pos'] = pos
        self.fader_toast = {'i': i, 'until': self.clock() + 1200}

    # ---- pads (bank B: indices 16-31) -------------------------------------------------------------------------

    def arm(self, t, on):
        if on and self.song.exclusive_arm and not self.shift:
            for o in self.tracks():
                if o != t and getattr(o, 'can_be_armed', False) and o.arm:
                    o.arm = False
        t.arm = on

    def solo(self, t, on):
        if on and self.song.exclusive_solo and not self.shift:
            for o in self.tracks() + list(self.song.return_tracks):
                if o != t and o.solo:
                    o.solo = False
        t.solo = on

    def pad(self, idx, value, mod):
        if idx < 16:
            return
        s = self.song
        slot, row2 = (idx - 16) & 7, idx >= 24
        if value == 0:                                      # release: a short tap on a clip pad launches it
            if self.drums.release(idx) or self.devpads.release(idx):
                return
            h = self.pad_hold
            if h and h['idx'] == idx:
                self.pad_hold = None
                if not h.get('opened'):
                    t = self.bank_track(h['track'])
                    if t is not None:
                        self.launch_slot(t, h['scene'])
            return
        if mod and row2:
            if slot < len(SUBS):
                self.sub = SUBS[slot]
            elif slot == 6:
                s.stop_all_clips()
            elif slot == 7:
                self.toggle_main_view()
            return
        if mod:                                             # Oct- / Shift + row 1: bank, scenes, edit commands
            if slot in (0, 1):
                self.scroll_bank(-1 if slot == 0 else 1)
            elif slot in (2, 3):
                sc = list(s.scenes)
                j = self.scene_index() + (-1 if slot == 2 else 1)
                if 0 <= j < len(sc):
                    s.view.selected_scene = sc[j]
            elif slot == 4:
                self.capture()
            elif slot == 5:
                if s.can_undo:
                    s.undo()
            elif slot == 6:
                if s.can_redo:
                    s.redo()
            elif slot == 7:
                s.view.selected_scene.fire()
            return
        mode = self.pad_mode()
        if mode == 'drum':
            self.drums.press(idx, self.drums.rack())
            return
        if mode == 'keys':
            self.drums.press(idx, None)
            return
        if mode in DEV_MODES:
            self.devpads.press(idx, mode)
            return
        dp = self.device_pads() if mode == 'device' else None
        if dp is not None:                                  # device pads: toggle the switch (a dark pad does nothing)
            p = dp[idx - 16]
            if p is not None:
                p.value = p.max if p.value < (p.min + p.max) / 2.0 else p.min
                self.touch_param(p, 'p%d' % (idx - 16))
            return
        t = self.bank_track(slot)
        if t is None:
            return
        if self.sub == 'clips':
            s.view.selected_track = t
            self.pad_hold = {'idx': idx, 't': self.clock(), 'track': slot, 'scene': self.scene_index() + (1 if row2 else 0)}
            return
        if not row2:
            s.view.selected_track = t
            return
        sub = self.sub
        if sub == 'mute':
            if t != s.master_track:
                t.mute = not t.mute
        elif sub == 'solo':
            self.solo(t, not t.solo)
        elif sub == 'arm':
            if getattr(t, 'can_be_armed', False):
                self.arm(t, not t.arm)
        elif sub == 'stop':
            t.stop_all_clips()
        elif sub == 'launch':
            self.launch_slot(t, self.scene_index())

    def toggle_main_view(self):
        if self.app is None:
            return
        v = self.app.view
        v.show_view('Arranger' if v.is_view_visible('Session') else 'Session')

    def main_view_name(self):
        if self.app is None:
            return 'Live'
        return 'Session' if self.app.view.is_view_visible('Session') else 'Arrangement'

    # ---- render: the whole state; OscLink sends only what changed ---------------------------------------------

    def render(self):
        if self.link.state != 'up':
            return
        self._rendering = True
        try:
            self._render()
        finally:
            self._rendering = False
            self._bcache = None

    def _render(self):
        L = self.link
        views = self.views()
        L.send('mode', P.mode(self.view if views else P.MODE_DEVICE, TITLES[self.view]))
        self.render_transport()
        self.render_tracks()
        self.render_cells()
        self.render_pads()
        self.render_buttons()
        if L.has(P.CAP_HEADER):
            L.send('header', self.header())
        ft = self.fader_toast
        if ft and self.clock() < ft['until'] and not (views and self.view == P.MODE_MIXER) and L.has(P.CAP_NOTIFY):
            p = self.fader_target(ft['i'])
            if p is not None:
                if ft['i'] < 4:
                    t = self.bank_track(self.window + ft['i'])
                    who = t.name if t is not None else ''
                else:
                    who = '%s %s' % (self.sel_track().name, ['Vol', 'Pan', 'Send A', 'Send B'][ft['i'] - 4])
                txt = ptext(p)
                f = self.fader[ft['i']]
                if self.prefs['soft_takeover'] and not f['picked']:
                    txt += '  (move up)' if f['pos'] < norm(p) else '  (move down)'
                L.send('ftoast', P.notify(0, 12, '%s: %s' % (who, txt)))
        if L.has(P.CAP_ACCENT) and self.prefs['accent'] != 'off':
            L.send('accent', P.accent(ACCENT_LIVE))         # once per session (the link drops repeats)
        if views and self.view == P.MODE_BROWSER:
            self.render_list()
        if L.has(P.CAP_SCALE_SYNC):
            L.send('scale', self.scale_msg())

    def scale_msg(self):
        """SCALE from the song scale (Live 12)."""
        s = self.song
        mask = 0
        for i in s.scale_intervals:
            mask |= 1 << (int(i) % 12)
        return P.scale(2 | (1 if s.scale_mode else 0), int(s.root_note), mask, s.scale_name)

    def render_transport(self):
        s, f = self.song, 0
        if s.is_playing:
            f |= P.TR_PLAYING
        if s.record_mode:
            f |= P.TR_RECORDING
        if s.loop:
            f |= P.TR_LOOP
        if s.punch_in:
            f |= P.TR_PUNCH_IN
        if s.punch_out:
            f |= P.TR_PUNCH_OUT
        if s.metronome:
            f |= P.TR_METRONOME
        if s.session_automation_record:
            f |= P.TR_AUTOMATION
        if s.session_record or getattr(s, 'arrangement_overdub', False):
            f |= P.TR_OVERDUB
        if getattr(s, 'is_counting_in', False):
            f |= P.TR_COUNT_IN
        self.link.send('transport', P.transport(f, s.tempo * 100))

    def render_position(self):
        """Position and time signature (the caller's 10 Hz timer)."""
        L = self.link
        if not L.has(P.CAP_PROJECT):
            return
        s = self.song
        num, den = s.signature_numerator or 4, s.signature_denominator or 4
        beat_len = 4.0 / den
        pos = max(0.0, s.current_song_time)
        bar_len = num * beat_len
        bar = int(math.floor(pos / bar_len + 1e-9))
        in_bar = pos - bar * bar_len
        beat = int(math.floor(in_bar / beat_len + 1e-9))
        six = int(math.floor((in_bar - beat * beat_len) / 0.25 + 1e-9))
        L.send('project', P.project(bar + 1, beat + 1, six + 1, num, den, self.main_view_name()))

    def render_meters(self):
        if self.view == P.MODE_MIXER and self.link.has(P.CAP_METERS):
            lv = []
            for i in range(8):
                t = self.bank_track(i)
                lv.append(t.output_meter_level * 127 if t is not None and getattr(t, 'has_audio_output', True) else 0)
            self.link.send('meters', P.meters(0, lv))

    def track_flags(self, t):
        if t is None:
            return 0
        f = P.TRK_EXISTS
        if t.mute:
            f |= P.TRK_MUTE
        if t.solo:
            f |= P.TRK_SOLO
        if getattr(t, 'can_be_armed', False) and t.arm:
            f |= P.TRK_ARMED
        if getattr(t, 'is_foldable', False):
            f |= P.TRK_GROUP
        if getattr(t, 'is_grouped', False):
            f |= P.TRK_IN_GROUP
        return f

    def render_tracks(self):
        ss = self.selected_slot()
        for i in range(8):
            t = self.bank_track(i)
            f = self.track_flags(t)
            if f and i == ss:
                f |= P.TRK_SELECTED
            self.link.send('trk%d' % i, P.track(i, f, rgb7(t.color) if t is not None else None, t.name if t is not None else ''))
        c = self.sel_track()
        cf = self.track_flags(c) | (P.TRK_SELECTED if c is not None else 0)
        self.link.send('trk8', P.track(8, cf, rgb7(getattr(c, 'color', 0)) if c is not None else None,
                                       c.name if c is not None else ''))

    def param_cell(self, target, p, bipolar=False):
        """A parameter as a cell; a slot without one is disabled (v1) or blank (v0). Live's modulation is not
        readable, so the modulation marker is never used."""
        L, v1 = self.link, self.link.has(P.CAP_CELL_V1)
        if p is None or not getattr(p, 'is_enabled', True):
            L.send('cn%d' % target, P.cell_name(target, P.CELL_DISABLED if v1 else 0, None, p.name if p is not None else ''))
            L.send('cv%d' % target, P.cell_value(target, norm(p) * 16383 if p is not None else 0, ''))
            return
        L.send('cn%d' % target, P.cell_name(target, P.CELL_BAR_BI if bipolar else P.CELL_BAR_UNI, None, p.name))
        L.send('cv%d' % target, P.cell_value(target, norm(p) * 16383, ptext(p)))

    def text_cell(self, target, name, value01=0.0, text=''):
        L, v1 = self.link, self.link.has(P.CAP_CELL_V1)
        L.send('cn%d' % target, P.cell_name(target, P.CELL_BAR_UNI if name else (P.CELL_DISABLED if v1 else 0), None, name or ''))
        L.send('cv%d' % target, P.cell_value(target, P.clamp(value01, 0.0, 1.0) * 16383, text or ''))

    def render_cells(self):
        s, v = self.song, self.view
        if v == P.MODE_DEVICE:
            t = self.sel_track()
            step = self.drums.cells() if self.pad_mode() in ('drum', 'keys') else None
            for i in range(8):
                if step is not None and i < len(step):
                    self.text_cell(i, *step[i])
                else:
                    self.param_cell(i, self.device_param(i))
                self.param_cell(8 + i, self.track_param(t, i), i == 1)
        elif v == P.MODE_MIXER:
            for i in range(8):
                t = self.bank_track(i)
                sends = list(t.mixer_device.sends) if t is not None else []
                self.param_cell(i, t.mixer_device.panning if t is not None else None, True)
                self.param_cell(8 + i, sends[0] if sends else None)
        elif v == P.MODE_OVERVIEW:
            self.text_cell(0, 'Tempo', (s.tempo - TEMPO_MIN) / (TEMPO_MAX - TEMPO_MIN), '%.2f' % s.tempo)
            self.text_cell(1, 'Swing', s.swing_amount, '%d %%' % round(s.swing_amount * 100))
            self.text_cell(2, 'Groove', s.groove_amount / 1.3125, '%d %%' % round(s.groove_amount * 100))
            self.text_cell(3, 'Loop at', 0, self.beats_text(s.loop_start))
            self.text_cell(4, 'Loop len', 0, self.length_text(s.loop_length))
            self.text_cell(5, 'Position', 0, self.beats_text(s.current_song_time))
            mv = s.master_track.mixer_device
            self.param_cell(6, mv.volume)
            self.param_cell(7, getattr(mv, 'cue_volume', None))
            rt = list(s.return_tracks)
            for i in range(8):
                self.param_cell(8 + i, rt[i].mixer_device.volume if i < len(rt) else None)
        elif v == P.MODE_BROWSER:
            names = ['Scroll', 'Page'] if self.clip_menu is None else ['Action', '']
            for i in range(16):
                self.text_cell(i, names[i] if i < 2 else '', 0, '')
        # faders: cells 16-23 are the 8 strips' volumes (the Mixer view draws them); the window's 4 are named F1-F4,
        # with ^ / v while a fader waits for pick-up (move it that way)
        for i in range(8):
            t = self.bank_track(i)
            name = ''
            if t is not None and self.window <= i < self.window + 4:
                f = self.fader[i - self.window]
                name = 'F%d' % (i - self.window + 1)
                if self.prefs['soft_takeover'] and not f['picked'] and f['pos'] >= 0:
                    name += '^' if f['pos'] < norm(t.mixer_device.volume) else 'v'
            self.link.send('cn%d' % (16 + i), P.cell_name(16 + i, 0, None, name))
            vol = t.mixer_device.volume if t is not None else None
            self.link.send('cv%d' % (16 + i), P.cell_value(16 + i, norm(vol) * 16383 if vol is not None else 0,
                                                           ptext(vol) if vol is not None else ''))

    def beats_text(self, beats):
        """Song time in beats as bar.beat (1-based)."""
        num, den = self.song.signature_numerator or 4, self.song.signature_denominator or 4
        bl = 4.0 / den
        bar = int(math.floor(beats / (num * bl) + 1e-9))
        beat = int(math.floor((beats - bar * num * bl) / bl + 1e-9))
        return '%d.%d' % (bar + 1, beat + 1)

    def length_text(self, beats):
        bars = beats / self.bar_beats()
        return ('%d bars' % bars) if abs(bars - round(bars)) < 1e-6 else ('%.2f beats' % beats)

    def header(self):
        v = self.view
        if v == P.MODE_DEVICE:
            d = self.device()
            if d is None:
                return P.header('No device', 'hold SEQ: browse')
            bs = self.device_banks()
            if not bs:
                return P.header(d.name, 'no parameters')
            self.bank = min(self.bank, len(bs) - 1)
            text = '%d/%d %s' % (self.bank + 1, len(bs), bs[self.bank][0])
            mode = self.pad_mode()
            if mode == 'drum':
                return self.drums.header(self.drums.rack(), text)
            if mode == 'keys':
                return self.drums.header(None, text)
            if mode in DEV_MODES:
                return self.devpads.header(mode, text)
            return P.header(d.name, text + (' | pads' if mode == 'device' else ''))
        if v == P.MODE_MIXER:
            return P.header('Mixer', 'Tracks %d-%d' % (self.offset + 1, self.offset + 8))
        if v == P.MODE_OVERVIEW:
            return P.header('Overview', self.main_view_name())
        if self.clip_menu is not None:
            return P.header('Clip', 'Right: do it  Left: close')
        return P.header('Browser', self.browse['title'] if self.browse else '')

    def render_list(self):
        if self.clip_menu is not None:
            cm = self.clip_menu
            t = self.bank_track(cm['slot'])
            cs = t.clip_slots[cm['scene']] if t is not None and cm['scene'] < len(t.clip_slots) else None
            title = ('Clip: %s' % cs.clip.name) if cs is not None and cs.has_clip else 'Empty slot'
            lid, cursor = LIST_CLIP, cm['cursor']
        else:
            b = self.browse
            title, lid, cursor = (b['title'] if b else ''), LIST_BROWSER, (b['cursor'] if b else 0)
        items = self.list_items()
        self.link.send('list', P.list_(lid, len(items), cursor, title))
        first = cursor // 8 * 8
        for r in range(8):
            i = first + r
            if i < len(items):
                text = items[i]['name'] + (' >' if items[i].get('folder') else '')
                self.link.send('row%d' % r, P.list_row(r, i, P.ROW_SELECTED if i == cursor else 0, None, text))
            else:
                self.link.send('row%d' % r, P.list_row(r, i, 0, None, ''))

    def clip_light(self, t, scene):
        if t is None or scene >= len(t.clip_slots):
            return ((0, 0, 0), P.SOLID)
        cs = t.clip_slots[scene]
        if cs.has_clip:
            c = cs.clip
            col = rgb7(c.color)
            if c.is_recording:
                return (col, P.BLINK)
            if c.is_triggered:
                return (col, P.PULSE)
            return (col if c.is_playing else dim(col, 0.3), P.SOLID)
        armed = getattr(t, 'can_be_armed', False) and t.arm
        if cs.is_triggered:
            return ((127, 10, 10), P.PULSE)
        return ((40, 0, 0) if armed else (0, 0, 0), P.SOLID)

    def render_pads(self):
        lights = []
        ss = self.selected_slot()
        sc = self.scene_index()
        mode = self.pad_mode()
        if mode != self.pmode_last:                         # tell the player once that the pads changed meaning
            if mode == 'device':
                self.notify('Pads: %s switches' % self.device().name, 1, 10)
            elif mode == 'drum':
                self.notify('Pads: %s drum pads (hold one: steps)' % self.drums.rack().name, 1, 10)
            elif mode == 'keys':
                self.notify('Steps: %s key %s (Oct- + Left/Right: key)' % (self.sel_track().name,
                                                                         note_name(self.drums.lane)), 1, 10)
            elif mode in DEV_MODES:
                self.notify('Pads: %s %s' % (self.device().name, mode), 1, 10)
            if mode not in ('drum', 'keys'):
                self.drums.reset()
            self.pmode_last = mode
        if mode == 'drum' and not self.shift:
            self.link.send('pads', P.pads(16, self.drums.lights(self.drums.rack())))
            return
        if mode == 'keys' and not self.shift:
            self.link.send('pads', P.pads(16, self.drums.lights(None)))
            return
        if mode in DEV_MODES and not self.shift:
            self.link.send('pads', P.pads(16, self.devpads.lights(mode)))
            return
        dp = self.device_pads() if mode == 'device' else None
        if dp is not None and not self.shift:               # device pads in the script's accent: lit = on
            for p in dp:
                if p is None:
                    lights.append(((0, 0, 0), P.SOLID))
                else:
                    lights.append((dim(ACCENT_LIVE, 1 if norm(p) >= 0.5 else 0.15), P.SOLID))
            self.link.send('pads', P.pads(16, lights))
            return
        if self.sub == 'clips' and not self.shift:
            for row in range(2):
                for i in range(8):
                    lights.append(self.clip_light(self.bank_track(i), sc + row))
            self.link.send('pads', P.pads(16, lights))
            return
        for i in range(8):                                  # row 1: the tracks, the selected one bright
            t = self.bank_track(i)
            if self.shift:
                lights.append(((40, 40, 40), P.SOLID))      # the Oct- / Shift row-1 actions
            elif t is not None:
                lights.append((dim(rgb7(t.color), 1 if i == ss else 0.25), P.SOLID))
            else:
                lights.append(((0, 0, 0), P.SOLID))
        for i in range(8):                                  # row 2: the sub-mode's state, or (Shift held) the choices
            t = self.bank_track(i)
            col, anim = (0, 0, 0), P.SOLID
            if self.shift:
                if i < len(SUBS):
                    col = dim(SUB_RGB[SUBS[i]], 1 if SUBS[i] == self.sub else 0.2)
                else:
                    col = (40, 40, 40)
            elif t is not None:
                base = SUB_RGB[self.sub]
                if self.sub == 'mute':
                    col = dim(base, 1 if t.mute else 0.12)
                elif self.sub == 'solo':
                    col = dim(base, 1 if t.solo else 0.12)
                elif self.sub == 'arm':
                    if getattr(t, 'can_be_armed', False):
                        col = dim(base, 1 if t.arm else 0.12)
                elif self.sub == 'stop':
                    playing = t.playing_slot_index >= 0
                    col = dim(base, 1 if playing else 0.12)
                    anim = P.BLINK if t.fired_slot_index == -2 else P.PULSE if playing else P.SOLID
                elif self.sub == 'launch':
                    col, anim = self.clip_light(t, sc)
            lights.append((col, anim))
        self.link.send('pads', P.pads(16, lights))

    def render_buttons(self):
        s, B, L = self.song, P.BTN, self.link
        L.send('bl%d' % B.SEQ_PLAY, P.button_led(B.SEQ_PLAY, 1 if s.is_playing else 0))
        L.send('bl%d' % B.SEQ_REC, P.button_led(B.SEQ_REC, 1 if s.record_mode else 2 if s.session_record else 0))
        if self.prefs['seq_views']:
            L.send('bl%d' % B.SEQ, P.button_led(B.SEQ, 0 if self.view == P.MODE_DEVICE else 1))
        L.send('bl%d' % B.LEFT, P.button_led(B.LEFT, 1))
        L.send('bl%d' % B.RIGHT, P.button_led(B.RIGHT, 1))

    def disconnect(self):
        self.untouch(0, True)
