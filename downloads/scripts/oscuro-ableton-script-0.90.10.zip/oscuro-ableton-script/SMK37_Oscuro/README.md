# SMK-37 Oscuro: Ableton Live Remote Script

For an M-Vave SMK-37 Elite (or its twins) running **Oscuro firmware** with the DAW protocol. The DAW and DAW BT builds draw the Mixer, Overview and Browser screens; the other Oscuro builds get the knob names, values and pad lights.

On **M-Vave's own firmware** keep using a stock-firmware script. This one has its own name (`SMK37_Oscuro`), can be installed beside them, and does nothing until Oscuro firmware answers (Live's status bar then says "Oscuro firmware not found").

Status: tested against a fake Live API and the firmware's protocol decoder (`make check-ableton` in the repository root); **not yet run in Live with a keyboard.** Design: `docs/design/2026-11-25-daw-ableton.md`; run spec: `docs/test-specs/DAW2_daw_ableton.md`.

## Install

1. Needs **Live 12 or newer**. Older versions are not supported: Live's status bar shows "SMK37 Oscuro needs Live 12 or newer" and the script does nothing.
2. Quit Live. Copy this folder (`SMK37_Oscuro`, without `tests/`) into the **Remote Scripts** folder of your User Library: `~/Music/Ableton/User Library/Remote Scripts/` (macOS) or `%USERPROFILE%\Documents\Ableton\User Library\Remote Scripts\` (Windows). Create `Remote Scripts` if it is missing; if your User Library is elsewhere, use the path Live shows under *Settings → Library*. The `.py` files must sit directly in `Remote Scripts/SMK37_Oscuro/`.
3. Start Live: *Settings → Link, Tempo & MIDI*. In a free Control Surface row choose **SMK37_Oscuro**, Input and Output the keyboard's **DAW port** (with *USB Ports: Split* on the keyboard that is its third port; with *One* the only port). Over Bluetooth use the *SMK-37 Oscuro BLE* port.
4. In the MIDI port list below: the keys / pads ports **Track: On** (they play notes), **Remote: Off**. Sync off.

Settings (Live has no preference panel for scripts): edit `user_settings.py` and re-select the control surface: SEQ button (screen views or the keyboard's sequencer), fader soft takeover, accent (the script's amber or the keyboard's own), knob steps, `flush_budget` (bytes sent to the keyboard per pass, 300 by default: the keyboard's MIDI input is small, a flood makes it say "Host lost"; the script sends structure first, values next, meters last, and the rest waits for the next pass).

## Using it

| Control | Device view | Mixer view | Overview | Browser / clip actions |
|---|---|---|---|---|
| K1–K8 | the selected device's bank (Live's best-of banks, a Max for Live device's own banks, rack macros, or the parameters in order) | pan of 8 tracks | tempo, swing, groove, loop start, loop length, position, master, cue | K1 scroll, K2 by 8 |
| K9–K16 (Knob Bank B) | the selected track's volume, pan, sends A–F | send A of 8 tracks | return track volumes | — |
| Left / Right | bank | move the 4-fader window (then the bank) | one bar back / forward | back / cancel, open / load / do it |
| Oct- + Left / Right | previous / next device | track bank by 8 | 4 bars | — |

Everywhere:

- **Oct- hint:** the script sends no pad names, so holding Oct- (Settings > Display > Hints) shows the plain Oct- shortcut rows, not the pad-name card the Bitwig script gets (firmware 0.90.9).
- **SEQ** tap: Device → Mixer → Overview. **Hold SEQ**: presets of the selected device (Live hot-swaps the one you load). **Oct- + hold SEQ**: the whole browser (Sounds, Drums, Instruments, …); what you load goes after the selected device. **Oct- + SEQ** tap: metronome.
- **Faders 1–4**: volumes of the 4 tracks in the window (F1–F4 on the Mixer screen). **Fader Bank B**: the selected track's volume, pan, send A, send B. Soft takeover: a fader does nothing until it reaches the value (`F2^` = move up).
- **Mixer screen:** the selected track has a white frame and its name inverted; a group track has a taller colour bar, and a line in the group's colour runs over the group and the tracks inside it, whose colour bars are short and inset. Squares under each strip: mute yellow, solo blue, arm red.
- **Pad bank B**, top row: select a track (lit in its colour). Bottom row: mute, solo, arm, stop or launch for the same 8 tracks, or **Clips**: both rows an 8 × 2 clip launcher (selected scene and the next). **Oct- + bottom pad** 1–6 picks (hold the Shift pad to see the choice lit), 7 stops all clips, 8 switches Session / Arrangement. **Oct- + top pad** 1 / 2 track bank, 3 / 4 scene, 5 Capture MIDI, 6 Undo, 7 Redo, 8 launch the scene. Pad bank A stays notes (Drum Rack, instruments, the Harmony Helper).
- **Device pads** (Device view only): when the selected device has on/off parameters on its current bank or the next, pad bank B toggles them instead of the tracks: top row = this bank's 8 controls, bottom row = the next bank's, lit in the script's amber (bright = on); other slots stay dark. The header adds "| pads" and the screen says "Pads: <device> switches" once when they appear. The Mixer and Overview views, and devices without switches, keep the track pads; Oct- / Shift chords keep their meaning everywhere. Turning a switch on writes automation like a knob.
- **Drum pads and steps** (Device view only): a selected Drum Rack takes pad bank B; so does the track's Drum Rack when the selected device has no switches for device pads. **Drum pads**: top row = 8 pads from C1 in their colours, the selected one bright; a tap selects the pad, **hold one half a second for its steps**. Bottom row = mute of those pads (solo when the track sub-mode is solo). **Oct- + Left / Right** moves the 8-pad window. **Steps**: both rows are the 16 sixteenths of that pad in the clip of the selected track and scene (a 1-bar clip is made if there is none); the playing step is white. Press an empty step: a note. Press a note and let go: removed, unless you turned a knob while holding it: **K1 velocity, K2 length, K3 probability, K4 velocity range, K5 mute (right = muted), K6 release velocity** (K7, K8 stay blank while a step is held). Left / Right: the next 16 steps; Oct- + Left / Right: the previous / next pad; **Shift pad + Left**: back to the pads. The screen says "Pads: <device> drum pads (hold one: steps)" once; the header shows the pad range or "Steps 1-16/16".
- **Key lanes** (Device view, track pads showing, a MIDI track): **Shift pad + Right** opens the same 16-step page for one key of the track (C3 the first time, then the last key you used). Lit in the track's colour; header = the note name and "Steps 1-16/16"; the screen says "Steps: <track> key C3 (Oct- + Left/Right: key)" once. **Oct- + Left / Right** moves the key by a semitone, Left / Right the step pages, K1-K6 edit a held step as above. **Shift pad + Left**, another track, or another view closes it. A selected Drum Rack still wins.
- **More device pads** (Device view; what the selected device is decides, after a Drum Rack and an open key lane):
  - **Simpler in Slicing mode**: 16 slices of a page, lit in the track colour, the selected one bright, dark beyond the last. A tap selects the slice in Live (it plays on pad bank A as note 36 + slice). **Oct- + Left / Right** pages by 16; header "Slices 1-16/n | bank". Screen: "Pads: <device> slices".
  - **Looper**: top row Record, Overdub, Play, Stop, Undo, Clear, Half speed, Double speed; bottom row Half length, Double length. The pad of the current state is bright, the others dim. **Clear needs a half-second hold** ("Looper cleared"). Screen: "Pads: <device> looper".
  - **Instrument / Effect Rack with macro variations**: top row = 8 variations of a window (existing ones dim, the selected one bright); a tap selects and recalls it. **Oct- + Left / Right** moves the window by 8. Bottom row: pad 1 Store (a new variation), pad 2 Randomize macros, pad 8 Delete the selected variation (red; half-second hold). Screen: "Pads: <rack> variations".
  Shift still shows the usual choices, and Oct- / Shift chords keep their meaning. Plain Left / Right stay the knob banks.
- **Clips**: a tap launches on release (an empty slot of an armed track records); **hold a clip pad** for the actions: record 4 / 8 bars, duplicate, quantize, double loop, halve loop, delete (Right twice).
- **SEQ PLAY** play / stop (Oct-: stop and back to the start). **SEQ REC** arrangement record (Oct-: session record). **Oct- + K8** tempo (0.1 BPM with the Shift pad). TAP taps Live's tempo.
- Turning a knob opens an automation gesture, so Live records automation while you turn. Oct- or the Shift pad while turning: fine steps.
- Globe, PATCH (Harmony Helper), ARP, SCALE, CHORD, Note Repeat, the octave and bank buttons stay the keyboard's; while one of its pages is open, the knobs and Left / Right belong to it.
- Live 12's song scale is sent to the keyboard when it changes.

What Live does not offer, so the script does not either: modulation markers on the knobs, per-track or project macros like Bitwig's, the project name, metronome volume, browser preview.

## Files

`__init__.py` (entry point), `smk37_oscuro.py` (what Live calls), `oscuro_proto.py` (the protocol, `docs/DAW_PROTOCOL.md`), `oscuro_link.py` (session), `oscuro_drums.py` (drum pads, steps, key lanes), `oscuro_devpads.py` (Simpler slices, Looper, rack variations), `oscuro_surface.py` (views and controls), `live_banks.py` (device banks), `user_settings.py`. Tests: `tests/` (`python3 tests/test_surface.py`; `gen_vectors.py` + `vectors.c` check every message against the firmware decoder).
