# Device parameter banks of 8 (Live has no remote-control pages).
#
# Order of preference:
#  1. Live's own "best of" bank table for its built-in devices, imported at run time from the MIDI Remote Scripts
#     that ship with Live (_Generic/Devices.py). Nothing of it is copied here; outside Live (tests) it is absent.
#  2. Max for Live devices that define parameter banks (live.banks / the Inspector's bank editor): the device's own
#     banks via MaxDevice.get_bank_count / get_bank_name / get_bank_parameters (indices, -1 = empty slot).
#  3. Racks: the visible macros.
#  4. Anything else: the parameters in order, skipping "Device On", 8 at a time.
from __future__ import absolute_import, division, print_function, unicode_literals

try:  # pragma: no cover - only inside Live
    from _Generic.Devices import DEVICE_DICT as _LIVE_DICT, parameter_banks as _live_banks, \
        parameter_bank_names as _live_names
except Exception:  # noqa: BLE001 - any failure means "not available"
    _LIVE_DICT, _live_banks, _live_names = {}, None, None


def _chunks(params, name):
    out = []
    for i in range(0, len(params), 8):
        part = list(params[i:i + 8])
        out.append(('%s %d' % (name, i // 8 + 1), part + [None] * (8 - len(part))))
    return out


def _max_banks(device, params):
    """A Max for Live device's own banks; [] when it defines none or the calls are missing."""
    if not hasattr(device, 'get_bank_count'):
        return []
    try:
        out = []
        for b in range(int(device.get_bank_count())):
            idx = list(device.get_bank_parameters(b))[:8]
            slots = [params[i] if 0 <= i < len(params) else None for i in idx]
            name = device.get_bank_name(b) or 'Bank %d' % (b + 1)
            out.append((name, slots + [None] * (8 - len(slots))))
        return [x for x in out if any(x[1])]
    except Exception:  # noqa: BLE001 - a device that answers oddly: use the next rule
        return []


def banks(device):
    """[(bank name, [8 parameters or None])] for a Live device; [] for none."""
    if device is None:
        return []
    params = list(getattr(device, 'parameters', []) or [])
    if _live_banks is not None and getattr(device, 'class_name', None) in _LIVE_DICT:
        try:
            got = _live_banks(device)
            names = _live_names(device)
            out = []
            for i, b in enumerate(got):
                b = list(b)[:8]
                out.append((names[i] if i < len(names) else 'Bank %d' % (i + 1), b + [None] * (8 - len(b))))
            if out:
                return out
        except Exception:  # noqa: BLE001 - fall back to the plain order
            pass
    out = _max_banks(device, params)
    if out:
        return out
    if getattr(device, 'can_have_chains', False) and len(params) > 1:
        n = getattr(device, 'visible_macro_count', 8) or 8
        return _chunks(params[1:1 + n], 'Macros')
    return _chunks(params[1:], 'Page') or [('Page 1', [None] * 8)]
