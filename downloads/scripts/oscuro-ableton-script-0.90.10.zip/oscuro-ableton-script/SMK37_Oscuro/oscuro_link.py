# Oscuro DAW session: HELLO / HELLO_ACK, keepalive, and an outbox that sends the latest message per key
# (the twin of host/bitwig/SMK37-Oscuro/oscuro_link.js). Only the send function is passed in, so tests drive it.
#
# The surface renders its whole state on every pass; send(key, msg) drops a message equal to the last one sent
# under the same key, so only what changed goes out. On a new session (HELLO_ACK) the cache is cleared and the
# owner re-renders everything.
#
# flush() sends at most a byte budget per pass (the keyboard's MIDI input is small; Bitwig's script flooded it and the
# keyboard answered "Host lost"). Messages go out in priority order: session / names / header first, then values
# (pads, cells, LEDs, transport), meters last; what does not fit stays queued with the latest value per key winning and
# goes out on the next pass. PING is sent outside the outbox, so a backlog never starves it.
from __future__ import absolute_import, division, print_function, unicode_literals

from . import oscuro_proto as P


BUDGET = 300                    # bytes per flush


def priority(key):
    """0 = structure (mode, header, names, tracks, lists), 1 = values, 2 = meters."""
    if key == 'meters':
        return 2
    if key in ('mode', 'header', 'accent', 'scale', 'list', 'ftoast') or key.startswith(('cn', 'trk', 'row')):
        return 0
    return 1


class OscLink(object):
    def __init__(self, out, name='Live', budget=BUDGET):
        self.budget = budget        # bytes sent per flush (at least one message goes out each time)
        self.out = out              # out(tuple_of_bytes): one complete SysEx
        self.name = name
        self.state = 'idle'         # idle -> hello -> up
        self.caps = 0
        self.info = None            # the decoded HELLO_ACK
        self.sent = {}              # key -> the last message sent (tuple)
        self.queue = []             # keys in order, waiting for flush()
        self.queued = {}            # key -> message
        self.last_hello = -1e9
        self.first_hello = None     # when this attempt started (for the "firmware not found" message)
        self.last_tx = 0
        self.on_session = None      # called with the HELLO_ACK info when a session starts (or restarts)

    def has(self, cap):
        return self.state == 'up' and (self.caps & cap) != 0

    def hello(self, now):
        if self.state != 'hello':
            self.first_hello = now
        self.state = 'hello'
        self.last_hello = now
        self.raw(P.hello(P.KIND_ABLETON, self.name))

    def raw(self, m):
        """Send at once, outside the outbox (session messages)."""
        self.out(tuple(m))

    def send(self, key, m):
        """Queue 'm' under 'key'; a later send with the same key before flush() replaces it."""
        if self.state != 'up':
            return
        m = tuple(m)
        if key not in self.queued:
            if self.sent.get(key) == m:
                return
            self.queue.append(key)
        self.queued[key] = m

    def forget(self, prefix):
        """Forget what was sent under keys starting with 'prefix' (they go out again on the next render)."""
        for k in [k for k in self.sent if k.startswith(prefix)]:
            del self.sent[k]

    def flush(self, now, budget=None):
        """Send the queued messages, best priority first (queue order within a priority), until the byte budget is
        used; the rest stays queued."""
        left = self.budget if budget is None else budget
        order = sorted(range(len(self.queue)), key=lambda i: (priority(self.queue[i]), i))
        kept, full, any_sent = [], False, False
        for i in order:
            key = self.queue[i]
            m = self.queued[key]
            if self.sent.get(key) == m:
                del self.queued[key]
                continue
            if full or (any_sent and len(m) > left):
                full = True                                 # strict priority: nothing lower jumps the queue
                kept.append(key)
                continue
            self.out(m)
            self.sent[key] = m
            self.last_tx = now
            any_sent = True
            left -= len(m)
            del self.queued[key]
        self.queue = kept

    def tick(self, now):
        """Every ~100 ms: HELLO again while unanswered (1 s), PING while up (500 ms; the device drops us after 2 s)."""
        if self.state == 'hello' and now - self.last_hello >= 1000:
            self.hello(now)
        elif self.state == 'up' and now - self.last_tx >= 500:
            self.raw(P.ping())
            self.last_tx = now

    def rx(self, data, now):
        """A SysEx from the device. Returns the decoded message (or None)."""
        m = P.decode(data)
        if m is None:
            return None
        if m['cmd'] == P.HELLO_ACK:
            if self.state != 'hello':
                # the device answered a PING without a session (it restarted): start a new one
                self.hello(now)
                return m
            self.state = 'up'
            self.info = m
            self.caps = m['caps']
            self.sent = {}
            self.queue = []
            self.queued = {}
            self.last_tx = now
            if self.on_session:
                self.on_session(m)
        return m

    def bye(self):
        if self.state == 'up':
            self.raw(P.bye())
        self.state = 'idle'
