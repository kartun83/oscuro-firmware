# Device-specific pads on pad bank B (Device view): the selected device decides what the 16 pads are.
#   slices      a Simpler in Slicing mode: 16 slices of a page (slice k plays note 36 + k on pad bank A), lit in the
#               track colour, the selected one bright. A tap selects the slice in Live; Oct- + Left / Right pages by 16.
#   looper      Looper: top row Record, Overdub, Play, Stop, Undo, Clear (hold), Half speed, Double speed; bottom row
#               Half length, Double length. The pad of the current state is bright, the others dim in the accent.
#   variations  a non-drum rack: top row = variations of a window of 8 (tap = select + recall; Oct- + Left / Right
#               moves the window), bottom row 1 Store, 2 Randomize macros, 8 Delete (hold).
# The mode is picked by OscSurface.pad_mode (precedence is documented there); this module only knows the device.
from __future__ import absolute_import, division, print_function, unicode_literals

from . import oscuro_proto as P
from .oscuro_drums import HOLD_MS, _dim, _rgb7

try:  # pragma: no cover - only inside Live
    import Live
except ImportError:  # the host tests
    Live = None

# Simpler's playback_mode is Live.SimplerDevice.PlaybackMode (classic 0, one_shot 1, slicing 2)
SLICING = Live.SimplerDevice.PlaybackMode.slicing if Live is not None else 2
SLICE_PAGE = 16
RED = (70, 0, 0)

LOOPER_TOP = ('record', 'overdub', 'play', 'stop', 'undo', 'clear', 'half_speed', 'double_speed')
LOOPER_BOTTOM = ('half_length', 'double_length')
LOOPER_STATE_PAD = {'stop': 3, 'record': 0, 'play': 2, 'overdub': 1}      # the Looper "State" item -> its pad
MODES = ('slices', 'looper', 'variations')


class DevPads(object):
    def __init__(self, surface):
        self.s = surface
        self.dev = None
        self.reset()

    def reset(self):
        self.slice_page = 0
        self.var_base = 0
        self.hold = None            # a pad held for a destructive action: {idx, t, done}

    # ---- which mode ---------------------------------------------------------------------------------------------

    def mode(self, d):
        """'slices', 'looper', 'variations' or None for the selected device."""
        if d is not self.dev:
            self.dev = d
            self.reset()
        if d is None:
            return None
        cn = getattr(d, 'class_name', '')
        if cn == 'OriginalSimpler':
            if getattr(d, 'playback_mode', None) == SLICING and getattr(d, 'sample', None) is not None:
                return 'slices'
            return None
        if cn == 'Looper':
            return 'looper'
        if getattr(d, 'can_have_chains', False) and not getattr(d, 'can_have_drum_pads', False) \
                and getattr(d, 'variation_count', None) is not None:
            return 'variations'
        return None

    # ---- helpers --------------------------------------------------------------------------------------------------

    def slices(self, d):
        return list(d.sample.slices)

    def selected_slice(self, d):
        sl = self.slices(d)
        try:
            return sl.index(d.view.selected_slice)
        except ValueError:
            return -1

    def looper_state(self, d):
        """The Looper's state as a lower-case word (stop / record / play / overdub), from its "State" parameter."""
        for p in d.parameters:
            if p.name == 'State':
                items = list(getattr(p, 'value_items', []) or [])
                i = int(round(p.value))
                return items[i].lower() if 0 <= i < len(items) else ''
        return ''

    # ---- input ----------------------------------------------------------------------------------------------------

    def press(self, idx, mode):
        d = self.s.device()
        i = idx - 16
        if mode == 'slices':
            n = self.slice_page * SLICE_PAGE + i
            sl = self.slices(d)
            if n < len(sl):
                d.view.selected_slice = sl[n]
        elif mode == 'looper':
            if i < 8:
                a = LOOPER_TOP[i]
            elif i - 8 < len(LOOPER_BOTTOM):
                a = LOOPER_BOTTOM[i - 8]
            else:
                return
            if a == 'clear':
                self.hold = {'idx': idx, 't': self.s.clock(), 'done': False, 'what': 'clear'}
            else:
                getattr(d, a)()
        elif mode == 'variations':
            if i < 8:
                n = self.var_base + i
                if n < d.variation_count:
                    d.selected_variation_index = n
                    d.recall_selected_variation()
            elif i == 8:
                d.store_variation()
            elif i == 9:
                d.randomize_macros()
            elif i == 15:
                self.hold = {'idx': idx, 't': self.s.clock(), 'done': False, 'what': 'delete'}

    def release(self, idx):
        h = self.hold
        if h is not None and h['idx'] == idx:
            self.hold = None
            return True
        return False

    def poll(self, now):
        h = self.hold
        if h is None or h['done'] or now - h['t'] < HOLD_MS:
            return
        h['done'] = True
        d = self.s.device()
        mode = self.mode(d)
        if h['what'] == 'clear' and mode == 'looper':
            d.clear()
            self.s.notify('Looper cleared', 1, 8)
        elif h['what'] == 'delete' and mode == 'variations' and d.variation_count > 0:
            d.delete_selected_variation()
            self.s.notify('Variation deleted', 1, 8)

    def nav(self, direction, oct_, mode):
        """Oct- + Left / Right pages slices and variations; plain Left / Right stay the knob banks."""
        if not oct_ or mode == 'looper':
            return False
        d = self.s.device()
        if mode == 'slices':
            pages = max(1, (len(self.slices(d)) + SLICE_PAGE - 1) // SLICE_PAGE)
            self.slice_page = P.clamp(self.slice_page + direction, 0, pages - 1)
        else:
            top = max(0, (d.variation_count - 1) // 8 * 8)
            self.var_base = P.clamp(self.var_base + 8 * direction, 0, top)
        return True

    # ---- render ---------------------------------------------------------------------------------------------------

    def lights(self, mode):
        d = self.s.device()
        acc = self.s.accent_rgb()
        out = []
        if mode == 'slices':
            col = _rgb7(self.s.sel_track().color)
            n_all, sel = len(self.slices(d)), self.selected_slice(d)
            for i in range(16):
                n = self.slice_page * SLICE_PAGE + i
                out.append(((0, 0, 0) if n >= n_all else _dim(col, 1 if n == sel else 0.25), P.SOLID))
        elif mode == 'looper':
            lit = LOOPER_STATE_PAD.get(self.looper_state(d), -1)
            for i in range(16):
                if i < 8 or i - 8 < len(LOOPER_BOTTOM):
                    out.append((_dim(acc, 1 if i == lit else 0.15), P.SOLID))
                else:
                    out.append(((0, 0, 0), P.SOLID))
        else:
            count, sel = d.variation_count, d.selected_variation_index
            for i in range(8):
                n = self.var_base + i
                out.append(((0, 0, 0) if n >= count else _dim(acc, 1 if n == sel else 0.2), P.SOLID))
            for i in range(8):
                if i < 2:
                    out.append((_dim(acc, 0.35), P.SOLID))
                elif i == 7:
                    out.append((RED, P.SOLID))
                else:
                    out.append(((0, 0, 0), P.SOLID))
        return out

    def header(self, mode, bank_text):
        d = self.s.device()
        bank = bank_text.split(' ')[0]                      # "2/3": the name would not fit beside the page anyway
        if mode == 'slices':
            n = len(self.slices(d))
            first = self.slice_page * SLICE_PAGE
            return P.header(d.name, 'Slices %d-%d/%d | %s' % (first + 1, min(first + SLICE_PAGE, n), n, bank))
        if mode == 'looper':
            return P.header(d.name, '%s | %s' % (self.looper_state(d).capitalize() or 'Looper', bank))
        count = d.variation_count
        return P.header(d.name, 'Var %d-%d/%d | %s' % (min(self.var_base + 1, count), min(self.var_base + 8, count),
                                                     count, bank))
